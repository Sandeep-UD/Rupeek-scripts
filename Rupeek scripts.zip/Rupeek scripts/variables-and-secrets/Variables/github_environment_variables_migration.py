#!/usr/bin/env python3
"""Migrate GitHub Actions environment variables between organizations."""

import csv
import logging
from typing import Dict, List, Tuple
from urllib.parse import quote

from github_variables_migration import GitHubVariablesMigrator


class GitHubEnvironmentVariablesMigrator(GitHubVariablesMigrator):
    """Migrate variables while leaving existing target environment settings unchanged."""

    def __init__(self) -> None:
        super().__init__()
        self.target_environment_cache: Dict[Tuple[str, str], bool] = {}

    def _repository_path(self, org: str, repository: str) -> str:
        return f'{quote(org, safe="")}/{quote(repository, safe="")}'

    def get_environments(self, org: str, repository: str, session) -> List[Dict]:
        url = f'{self.base_url}/repos/{self._repository_path(org, repository)}/environments'
        return self._get_paginated_data(session, url)

    def ensure_target_environment(self, repository: str, environment: str) -> bool:
        cache_key = (repository, environment)
        if cache_key in self.target_environment_cache:
            return self.target_environment_cache[cache_key]

        url = (
            f'{self.base_url}/repos/{self._repository_path(self.target_org, repository)}'
            f'/environments/{quote(environment, safe="")}'
        )
        response = self._make_request(self.target_session, 'GET', url)
        if response.status_code == 200:
            self.logger.info(
                'Target environment %s/%s already exists; leaving it unchanged',
                repository, environment
            )
            self.target_environment_cache[cache_key] = True
            return True
        if response.status_code != 404:
            self.logger.error(
                'Could not verify target environment %s/%s: HTTP %s',
                repository, environment, response.status_code
            )
            self.target_environment_cache[cache_key] = False
            return False

        response = self._make_request(self.target_session, 'PUT', url, json={})
        if response.status_code in (200, 201):
            self.logger.info('Created target environment %s/%s', repository, environment)
            self.target_environment_cache[cache_key] = True
            return True

        try:
            detail = response.json().get('message', 'Unknown error')
        except (ValueError, AttributeError):
            detail = response.text
        self.logger.error(
            'Failed to create target environment %s/%s: HTTP %s - %s',
            repository, environment, response.status_code, detail
        )
        self.target_environment_cache[cache_key] = False
        return False

    def get_environment_variables(
        self, org: str, repository: str, environment: str, session
    ) -> List[Dict]:
        path = self._repository_path(org, repository)
        url = (
            f'{self.base_url}/repos/{path}/environments/'
            f'{quote(environment, safe="")}/variables'
        )
        return self._get_paginated_data(session, url)

    def fetch_all_variables(self) -> List[Dict]:
        source_repositories = self.get_organization_repositories(
            self.source_org, self.source_session
        )
        target_repositories = self.get_organization_repositories(
            self.target_org, self.target_session
        )
        target_names = {
            repository['name']
            for repository in target_repositories
            if isinstance(repository, dict) and repository.get('name')
        }

        variables = []
        for repository in source_repositories:
            if not isinstance(repository, dict) or not repository.get('name'):
                continue
            repository_name = repository['name']
            if repository_name not in target_names:
                self.logger.warning(
                    'Repository %s is missing from target organization; skipping its environments',
                    repository_name
                )
                continue

            source_environments = self.get_environments(
                self.source_org, repository_name, self.source_session
            )
            for environment in source_environments:
                if not isinstance(environment, dict) or not environment.get('name'):
                    continue
                environment_name = environment['name']
                if not self.ensure_target_environment(repository_name, environment_name):
                    continue

                for variable in self.get_environment_variables(
                    self.source_org, repository_name, environment_name, self.source_session
                ):
                    if not isinstance(variable, dict) or not variable.get('name'):
                        continue
                    variables.append({
                        'repository': repository_name,
                        'environment': environment_name,
                        'name': variable['name'],
                        'value': variable.get('value', ''),
                        'created_at': variable.get('created_at', ''),
                        'updated_at': variable.get('updated_at', '')
                    })

        return variables

    def write_environment_variable(self, variable: Dict) -> bool:
        path = self._repository_path(self.target_org, variable['repository'])
        environment = quote(variable['environment'], safe='')
        name = quote(variable['name'], safe='')
        base_url = f'{self.base_url}/repos/{path}/environments/{environment}/variables'
        data = {'name': variable['name'], 'value': variable['value']}
        response = self._make_request(self.target_session, 'POST', base_url, json=data)

        if response.status_code == 201:
            self.logger.info(
                'Created environment variable: %s/%s/%s',
                variable['repository'], variable['environment'], variable['name']
            )
            return True
        if response.status_code == 409:
            response = self._make_request(
                self.target_session, 'PATCH', f'{base_url}/{name}',
                json={'value': variable['value']}
            )
            if response.status_code == 204:
                self.logger.info(
                    'Updated environment variable: %s/%s/%s',
                    variable['repository'], variable['environment'], variable['name']
                )
                return True

        try:
            detail = response.json().get('message', 'Unknown error')
        except (ValueError, AttributeError):
            detail = response.text
        self.logger.error(
            'Failed to migrate %s/%s/%s: HTTP %s - %s',
            variable['repository'], variable['environment'], variable['name'],
            response.status_code, detail
        )
        return False

    def export_environment_variables(self, variables: List[Dict], filename: str) -> None:
        fields = ['repository', 'environment', 'name', 'value', 'created_at', 'updated_at']
        with open(filename, 'w', newline='', encoding='utf-8') as output:
            writer = csv.DictWriter(output, fieldnames=fields)
            writer.writeheader()
            writer.writerows(variables)

    def migrate_environment_variables(self, variables: List[Dict]) -> Tuple[int, int]:
        succeeded = 0
        failed = 0
        for variable in variables:
            if self.write_environment_variable(variable):
                succeeded += 1
            else:
                failed += 1
        return succeeded, failed

    def run_migration(self) -> None:
        variables = self.fetch_all_variables()
        if not variables:
            self.logger.warning('No environment variables found to migrate')
            return

        filename = 'github_environment_variables_export.csv'
        self.export_environment_variables(variables, filename)
        succeeded, failed = self.migrate_environment_variables(variables)
        self.logger.info(
            'Environment variable migration completed. Success: %s, Errors: %s. Export: %s',
            succeeded, failed, filename
        )


def main() -> int:
    try:
        GitHubEnvironmentVariablesMigrator().run_migration()
    except Exception as error:
        logging.error('Environment variable migration failed: %s', error)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())