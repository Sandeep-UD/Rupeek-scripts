#!/usr/bin/env python3
"""Migrate organization-level GitHub Actions variables only."""

import logging
from typing import Dict, List

from github_variables_migration import GitHubVariablesMigrator


class GitHubOrganizationVariablesMigrator(GitHubVariablesMigrator):
    """Use the shared migration behavior for organization variables only."""

    def fetch_all_variables(self) -> List[Dict]:
        variables = self.get_organization_variables(self.source_org, self.source_session)
        return [
            {
                'scope': 'organization',
                'repository': '',
                'name': variable.get('name', ''),
                'value': variable.get('value', ''),
                'visibility': variable.get('visibility', 'all'),
                'selected_repositories': ','.join(variable.get('selected_repository_names', [])),
                'created_at': variable.get('created_at', ''),
                'updated_at': variable.get('updated_at', '')
            }
            for variable in variables
            if isinstance(variable, dict)
        ]

    def run_migration(self) -> None:
        variables = self.fetch_all_variables()
        if not variables:
            self.logger.warning('No organization variables found to migrate')
            return

        filename = 'github_organization_variables_export.csv'
        self.export_variables_to_csv(variables, filename)
        success, errors, skipped = self.migrate_variables(variables)
        self.logger.info(
            'Organization variable migration completed. '
            f'Success: {success}, Errors: {errors}, Skipped: {skipped}. Export: {filename}'
        )


def main() -> int:
    try:
        GitHubOrganizationVariablesMigrator().run_migration()
    except Exception as error:
        logging.error('Organization variable migration failed: %s', error)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())