#!/usr/bin/env python3
"""Export and migrate GitHub Actions environment secrets."""

import argparse
import csv
import logging
from typing import Dict, List, Optional, Tuple
from urllib.parse import quote

import requests

from github_secrets_migration import GitHubSecretsMigrator


class GitHubEnvironmentSecretsMigrator(GitHubSecretsMigrator):
    """Migrate environment secrets for same-named repositories/environments."""

    def __init__(self) -> None:
        super().__init__()
        self.environment_public_key_cache: Dict[Tuple[str, str, str], Dict] = {}
        self.target_environment_cache: Dict[Tuple[str, str], bool] = {}

    def _repository_path(self, org: str, repository: str) -> str:
        return f'{quote(org, safe="")}/{quote(repository, safe="")}'

    def get_environments(
        self, org: str, repository: str, session: requests.Session
    ) -> List[Dict]:
        url = f'{self.base_url}/repos/{self._repository_path(org, repository)}/environments'
        return self._get_paginated_data(session, url)

    def get_environment_secrets(
        self, org: str, repository: str, environment: str, session: requests.Session
    ) -> List[Dict]:
        url = (
            f'{self.base_url}/repos/{self._repository_path(org, repository)}/environments/'
            f'{quote(environment, safe="")}/secrets'
        )
        return self._get_paginated_data(session, url)

    def get_environment_public_key(
        self, org: str, repository: str, environment: str, session: requests.Session
    ) -> Optional[Dict]:
        cache_key = (org, repository, environment)
        if cache_key in self.environment_public_key_cache:
            return self.environment_public_key_cache[cache_key]

        url = (
            f'{self.base_url}/repos/{self._repository_path(org, repository)}/environments/'
            f'{quote(environment, safe="")}/secrets/public-key'
        )
        response = self._make_request(session, 'GET', url)
        if response.status_code != 200:
            self.logger.error(
                'Failed to get public key for %s/%s environment %s: HTTP %s',
                org, repository, environment, response.status_code
            )
            return None
        key = response.json()
        self.environment_public_key_cache[cache_key] = key
        return key

    def fetch_all_secrets(self) -> List[Dict]:
        secrets = []
        repositories = self.get_organization_repositories(self.source_org, self.source_session)
        for repository in repositories:
            if not isinstance(repository, dict) or not repository.get('name'):
                continue
            repository_name = repository['name']
            environments = self.get_environments(
                self.source_org, repository_name, self.source_session
            )
            for environment in environments:
                if not isinstance(environment, dict) or not environment.get('name'):
                    continue
                environment_name = environment['name']
                for secret in self.get_environment_secrets(
                    self.source_org, repository_name, environment_name, self.source_session
                ):
                    if not isinstance(secret, dict) or not secret.get('name'):
                        continue
                    secrets.append({
                        'repository': repository_name,
                        'environment': environment_name,
                        'name': secret['name'],
                        'value': '[ENCRYPTED_SECRET_VALUE]',
                        'created_at': secret.get('created_at', ''),
                        'updated_at': secret.get('updated_at', '')
                    })
        return secrets

    def export_environment_secrets(self, secrets: List[Dict], filename: str) -> None:
        fields = ['repository', 'environment', 'name', 'value', 'created_at', 'updated_at']
        with open(filename, 'w', newline='', encoding='utf-8') as output:
            writer = csv.DictWriter(output, fieldnames=fields)
            writer.writeheader()
            writer.writerows(secrets)

    def ensure_target_environment(self, repository: str, environment: str) -> bool:
        cache_key = (repository, environment)
        if cache_key in self.target_environment_cache:
            return self.target_environment_cache[cache_key]

        url = (
            f'{self.base_url}/repos/{self._repository_path(self.target_org, repository)}'
            f'/environments/{quote(environment, safe="")}'
        )
        response = self._make_request(self.target_session, 'GET', url)
        if response.status_code == 200:
            self.logger.info(
                'Target environment %s/%s already exists; leaving it unchanged',
                repository, environment
            )
            self.target_environment_cache[cache_key] = True
            return True
        if response.status_code != 404:
            self.logger.error(
                'Could not verify target environment %s/%s: HTTP %s',
                repository, environment, response.status_code
            )
            self.target_environment_cache[cache_key] = False
            return False

        response = self._make_request(self.target_session, 'PUT', url, json={})
        if response.status_code in (200, 201):
            self.logger.info('Created target environment %s/%s', repository, environment)
            self.target_environment_cache[cache_key] = True
            return True

        try:
            detail = response.json().get('message', 'Unknown error')
        except (ValueError, AttributeError):
            detail = response.text
        self.logger.error(
            'Failed to create target environment %s/%s: HTTP %s - %s',
            repository, environment, response.status_code, detail
        )
        self.target_environment_cache[cache_key] = False
        return False

    def write_environment_secret(self, secret: Dict, value: str) -> Optional[bool]:
        repository = secret['repository']
        environment = secret['environment']
        name = secret['name']
        if not self.ensure_target_environment(repository, environment):
            return False

        path = (
            f'{self.base_url}/repos/{self._repository_path(self.target_org, repository)}'
            f'/environments/{quote(environment, safe="")}/secrets/{quote(name, safe="")}'
        )
        existing = self._make_request(self.target_session, 'GET', path)
        if existing.status_code == 200:
            self.logger.info(
                'Environment secret %s/%s/%s already exists; skipping',
                repository, environment, name
            )
            return None
        if existing.status_code != 404:
            self.logger.error(
                'Cannot confirm whether environment secret %s/%s/%s exists (HTTP %s); skipping',
                repository, environment, name, existing.status_code
            )
            return False

        key = self.get_environment_public_key(
            self.target_org, repository, environment, self.target_session
        )
        if not key:
            return False
        try:
            encrypted_value = self.encrypt_secret(value, key['key'])
        except Exception as error:
            self.logger.error('Failed to encrypt environment secret %s: %s', name, error)
            return False

        response = self._make_request(
            self.target_session,
            'PUT',
            path,
            json={
                'encrypted_value': encrypted_value,
                'key_id': key['key_id']
            }
        )
        if response.status_code in (201, 204):
            self.logger.info('Created environment secret: %s/%s/%s', repository, environment, name)
            return True
        try:
            detail = response.json().get('message', 'Unknown error')
        except (ValueError, AttributeError):
            detail = response.text
        self.logger.error(
            'Failed to create environment secret %s/%s/%s: HTTP %s - %s',
            repository, environment, name, response.status_code, detail
        )
        return False

    def migrate_environment_secrets(
        self, secrets: List[Dict], create_placeholders: bool = False
    ) -> Tuple[int, int, int]:
        succeeded = 0
        failed = 0
        skipped = 0
        for secret in secrets:
            repository = secret.get('repository', '')
            environment = secret.get('environment', '')
            name = secret.get('name', '')
            value = secret.get('value', '')
            if not repository or not environment or not name:
                self.logger.error('Invalid environment secret row; skipping')
                failed += 1
                continue
            if value in ('', '[ENCRYPTED_SECRET_VALUE]'):
                if create_placeholders:
                    value = 'PLACEHOLDER_VALUE_SET_MANUALLY'
                else:
                    self.logger.error(
                        'No source value is available for %s/%s/%s; enter it in the CSV',
                        repository, environment, name
                    )
                    failed += 1
                    continue

            result = self.write_environment_secret(secret, value)
            if result is True:
                succeeded += 1
            elif result is None:
                skipped += 1
            else:
                failed += 1
        return succeeded, failed, skipped

    def run_export(self) -> None:
        secrets = self.fetch_all_secrets()
        filename = 'github_environment_secrets_export.csv'
        self.export_environment_secrets(secrets, filename)
        self.logger.info('Exported %s environment secrets to %s', len(secrets), filename)
        self.logger.info('Secret values are not available through GitHub; fill the value column before migrating')

    def run_csv_migration(self, filename: str, create_placeholders: bool = False) -> None:
        with open(filename, 'r', newline='', encoding='utf-8') as source:
            secrets = list(csv.DictReader(source))
        succeeded, failed, skipped = self.migrate_environment_secrets(
            secrets, create_placeholders
        )
        self.logger.info(
            'Environment secret migration completed. Success: %s, Errors: %s, Skipped: %s',
            succeeded, failed, skipped
        )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--migrate-from-csv', metavar='FILE')
    parser.add_argument(
        '--create-placeholders', action='store_true',
        help='explicitly create PLACEHOLDER_VALUE_SET_MANUALLY for rows without values'
    )
    args = parser.parse_args()
    if args.create_placeholders and not args.migrate_from_csv:
        parser.error('--create-placeholders requires --migrate-from-csv')

    try:
        migrator = GitHubEnvironmentSecretsMigrator()
        if args.migrate_from_csv:
            migrator.run_csv_migration(args.migrate_from_csv, args.create_placeholders)
        else:
            migrator.run_export()
    except Exception as error:
        logging.error('Environment secret migration failed: %s', error)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())