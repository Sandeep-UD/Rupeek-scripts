#!/usr/bin/env python3
"""Export and migrate organization-level GitHub Actions secrets."""

import argparse
import csv
import logging
from typing import Dict, List, Tuple

from github_secrets_migration import GitHubSecretsMigrator


class GitHubOrganizationSecretsMigrator(GitHubSecretsMigrator):
    """Migrate organization secrets without processing repository secrets."""

    def fetch_all_secrets(self) -> List[Dict]:
        secrets = self.get_organization_secrets(self.source_org, self.source_session)
        return [
            {
                'scope': 'organization',
                'repository': '',
                'name': secret.get('name', ''),
                'value': '[ENCRYPTED_SECRET_VALUE]',
                'visibility': secret.get('visibility', 'all'),
                'selected_repositories': ','.join(secret.get('selected_repository_names', [])),
                'created_at': secret.get('created_at', ''),
                'updated_at': secret.get('updated_at', '')
            }
            for secret in secrets
            if isinstance(secret, dict) and secret.get('name')
        ]

    def check_organization_secret_exists(self, org: str, secret_name: str, session) -> bool:
        url = f'{self.base_url}/orgs/{org}/actions/secrets/{secret_name}'
        response = self._make_request(session, 'GET', url)
        if response.status_code == 200:
            self.logger.info('Organization secret %s already exists; skipping', secret_name)
            return True
        if response.status_code == 404:
            return False
        self.logger.error(
            'Cannot confirm whether organization secret %s exists (HTTP %s); skipping to avoid overwrite',
            secret_name, response.status_code
        )
        return True

    def export_org_secrets(self, secrets: List[Dict], filename: str) -> None:
        fields = [
            'scope', 'repository', 'name', 'value', 'visibility',
            'selected_repositories', 'created_at', 'updated_at'
        ]
        with open(filename, 'w', newline='', encoding='utf-8') as output:
            writer = csv.DictWriter(output, fieldnames=fields)
            writer.writeheader()
            writer.writerows(secrets)

    def migrate_org_secrets(
        self, secrets: List[Dict], create_placeholders: bool = False
    ) -> Tuple[int, int, int]:
        succeeded = 0
        failed = 0
        skipped = 0
        for secret in secrets:
            if secret.get('scope') != 'organization' or not secret.get('name'):
                self.logger.error('Invalid organization secret row; skipping')
                failed += 1
                continue

            value = secret.get('value', '')
            if value in ('', '[ENCRYPTED_SECRET_VALUE]'):
                if create_placeholders:
                    value = 'PLACEHOLDER_VALUE_SET_MANUALLY'
                else:
                    self.logger.error(
                        'No source value is available for organization secret %s; enter it in the CSV',
                        secret['name']
                    )
                    failed += 1
                    continue

            selected_repositories = [
                repository.strip()
                for repository in secret.get('selected_repositories', '').split(',')
                if repository.strip()
            ]
            result = self.create_organization_secret(
                self.target_org,
                secret['name'],
                value,
                secret.get('visibility') or 'all',
                selected_repositories,
                self.target_session,
                create_placeholder=False
            )
            if result is True:
                succeeded += 1
            elif result is None:
                skipped += 1
            else:
                failed += 1
        return succeeded, failed, skipped

    def run_export(self) -> None:
        secrets = self.fetch_all_secrets()
        filename = 'github_organization_secrets_export.csv'
        self.export_org_secrets(secrets, filename)
        self.logger.info('Exported %s organization secrets to %s', len(secrets), filename)
        self.logger.info('Secret values are not available through GitHub; fill the value column before migrating')

    def run_csv_migration(self, filename: str, create_placeholders: bool = False) -> None:
        with open(filename, 'r', newline='', encoding='utf-8') as source:
            secrets = list(csv.DictReader(source))
        succeeded, failed, skipped = self.migrate_org_secrets(secrets, create_placeholders)
        self.logger.info(
            'Organization secret migration completed. Success: %s, Errors: %s, Skipped: %s',
            succeeded, failed, skipped
        )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--migrate-from-csv', metavar='FILE')
    parser.add_argument(
        '--create-placeholders', action='store_true',
        help='explicitly create PLACEHOLDER_VALUE_SET_MANUALLY for rows without values'
    )
    args = parser.parse_args()
    if args.create_placeholders and not args.migrate_from_csv:
        parser.error('--create-placeholders requires --migrate-from-csv')

    try:
        migrator = GitHubOrganizationSecretsMigrator()
        if args.migrate_from_csv:
            migrator.run_csv_migration(args.migrate_from_csv, args.create_placeholders)
        else:
            migrator.run_export()
    except Exception as error:
        logging.error('Organization secret migration failed: %s', error)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())