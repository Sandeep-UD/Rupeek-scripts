#!/usr/bin/env python3
"""
Reclaim Mannequins Script
Step 2: Reclaims mannequins from prepared CSV file

This script reads the CSV file that you manually updated with target users
and sends reclaim invitations to those users.

Usage:
    python reclaim_mannequins.py
"""

import os
import sys
import subprocess
import csv
import logging
from datetime import datetime
from pathlib import Path
from typing import Tuple
from dotenv import load_dotenv

# ==================== SETUP ====================
# Load environment variables from .env file
load_dotenv()

# Create logs directory if it doesn't exist
LOG_DIR = Path("logs")
LOG_DIR.mkdir(exist_ok=True)

# Configure logging
log_filename = LOG_DIR / f"reclaim_mannequins_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_filename),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# ==================== CONFIGURATION ====================
class Config:
    """Configuration class to read from environment variables"""
    
    def __init__(self):
        self.github_target_org = os.getenv('GITHUB_TARGET_ORG', '').strip()
        self.github_target_pat = os.getenv('GITHUB_TARGET_PAT', '').strip()
        self.github_api_url = os.getenv('GITHUB_API_URL', '').strip()
        self.reclaim_csv_filename = os.getenv('RECLAIM_CSV_FILENAME', 'mannequins_reclaim')
    
    def validate(self) -> Tuple[bool, str]:
        """Validate configuration"""
        if not self.github_target_org:
            return False, "GITHUB_TARGET_ORG not set in .env file"
        if not self.github_target_pat:
            return False, "GITHUB_TARGET_PAT not set in .env file"
        return True, "Configuration valid"


# ==================== RECLAIM OPERATIONS ====================
class ReclaimOperations:
    """Class to handle mannequin reclaim operations"""
    
    def __init__(self, config: Config):
        self.config = config
    
    def validate_csv(self, csv_file: str) -> Tuple[bool, str]:
        """
        Validate the CSV file before reclaiming
        
        Args:
            csv_file: Path to the CSV file
        
        Returns:
            Tuple of (success: bool, message: str)
        """
        logger.info("=" * 70)
        logger.info("STEP 1: Validating CSV File")
        logger.info("=" * 70)
        
        try:
            if not os.path.exists(csv_file):
                error_msg = f"CSV file not found: {csv_file}"
                logger.error(f"✗ {error_msg}")
                return False, error_msg
            
            file_size = os.path.getsize(csv_file)
            logger.info(f"CSV file: {csv_file} ({file_size} bytes)")
            
            # Read and validate CSV
            valid_rows = 0
            invalid_rows = 0
            missing_target_user = 0
            
            with open(csv_file, 'r', newline='', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                
                if not reader.fieldnames:
                    return False, "CSV file is empty"
                
                logger.info(f"CSV columns: {', '.join(reader.fieldnames)}")
                
                # Check for required columns
                if 'target-user' not in reader.fieldnames:
                    error_msg = "Missing 'target-user' column in CSV"
                    logger.error(f"✗ {error_msg}")
                    return False, error_msg
                
                # Validate rows
                for idx, row in enumerate(reader, start=2):  # Start from 2 (after header)
                    target_user = row.get('target-user', '').strip()
                    
                    if not target_user:
                        missing_target_user += 1
                        logger.warning(f"Row {idx}: Missing target-user value")
                    else:
                        valid_rows += 1
                        logger.debug(f"Row {idx}: target-user = {target_user}")
                    
                    invalid_rows = idx - 2 - valid_rows
            
            logger.info("")
            logger.info(f"✓ CSV Validation Results:")
            logger.info(f"  Valid rows (with target-user): {valid_rows}")
            logger.info(f"  Rows missing target-user: {missing_target_user}")
            logger.info(f"  Total rows: {valid_rows + missing_target_user}")
            
            if valid_rows == 0:
                error_msg = "No valid rows with target-user values found"
                logger.error(f"✗ {error_msg}")
                return False, error_msg
            
            if missing_target_user > 0:
                logger.warning(f"⚠ {missing_target_user} rows will be skipped (no target-user)")
            
            return True, f"CSV validated: {valid_rows} valid row(s)"
        
        except csv.Error as e:
            error_msg = f"CSV format error: {str(e)}"
            logger.error(f"✗ {error_msg}")
            return False, error_msg
        except Exception as e:
            error_msg = f"Unexpected error validating CSV: {str(e)}"
            logger.error(f"✗ {error_msg}")
            return False, error_msg
    
    def reclaim_mannequins(self, csv_file: str) -> Tuple[bool, str]:
        """
        Reclaim mannequins using gh gei command
        
        Args:
            csv_file: Path to the CSV file with mannequin mappings
        
        Returns:
            Tuple of (success: bool, message: str)
        """
        logger.info("")
        logger.info("=" * 70)
        logger.info("STEP 2: Reclaiming Mannequins")
        logger.info("=" * 70)
        
        try:
            # Construct the command
            command = [
                'gh', 'gei', 'reclaim-mannequin',
                '--github-target-org', self.config.github_target_org,
                '--csv', csv_file,
                '--github-target-pat', self.config.github_target_pat
            ]
            
            # Add API URL if provided (for self-hosted GitHub Enterprise)
            if self.config.github_api_url:
                command.extend(['--github-target-url', self.config.github_api_url])
                logger.info(f"Using custom API URL: {self.config.github_api_url}")
            
            logger.info(f"Organization: {self.config.github_target_org}")
            logger.info(f"CSV file: {csv_file}")
            logger.info(f"Running: gh gei reclaim-mannequin ... (token hidden)")
            logger.info("")
            logger.info("This may take a few moments depending on the number of mannequins...")
            logger.info("")
            
            # Execute the command
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=600  # 10 minute timeout for reclaim
            )
            
            if result.returncode == 0:
                logger.info(f"✓ Successfully reclaimed mannequins")
                
                if result.stdout:
                    logger.info(f"Output: {result.stdout.strip()}")
                
                return True, "Mannequins reclaimed successfully"
            else:
                error_msg = f"Command failed with return code {result.returncode}"
                logger.error(f"✗ {error_msg}")
                
                if result.stderr:
                    logger.error(f"Error: {result.stderr}")
                if result.stdout:
                    logger.error(f"Output: {result.stdout}")
                
                return False, error_msg
        
        except subprocess.TimeoutExpired:
            error_msg = "Command timed out after 10 minutes"
            logger.error(f"✗ {error_msg}")
            return False, error_msg
        except FileNotFoundError:
            error_msg = "gh command not found. Please install GitHub CLI"
            logger.error(f"✗ {error_msg}")
            logger.error("Install from: https://cli.github.com/")
            logger.error("Then install GEI extension: gh extension install github/gh-gei")
            return False, error_msg
        except Exception as e:
            error_msg = f"Unexpected error: {str(e)}"
            logger.error(f"✗ {error_msg}")
            return False, error_msg


# ==================== MAIN ====================
def main():
    """Main function to orchestrate reclaim"""
    
    logger.info("=" * 70)
    logger.info("GitHub Mannequin Reclaim Script Started")
    logger.info(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info(f"Log file: {log_filename}")
    logger.info("=" * 70)
    logger.info("")
    
    # Load and validate configuration
    config = Config()
    is_valid, validation_msg = config.validate()
    
    if not is_valid:
        logger.error(f"✗ Configuration validation failed: {validation_msg}")
        logger.error("")
        logger.error("Required settings in .env:")
        logger.error("  - GITHUB_TARGET_ORG     (Your GitHub organization)")
        logger.error("  - GITHUB_TARGET_PAT     (Personal Access Token with admin:org scope)")
        logger.error("")
        logger.error("Optional settings:")
        logger.error("  - GITHUB_API_URL        (For self-hosted GitHub Enterprise)")
        sys.exit(1)
    
    logger.info(f"✓ Configuration loaded successfully")
    logger.info(f"  Organization: {config.github_target_org}")
    logger.info(f"  API URL: {config.github_api_url or 'GitHub.com (default)'}")
    logger.info(f"  CSV file: {config.reclaim_csv_filename}.csv")
    logger.info("")
    
    # Initialize operations handler
    operations = ReclaimOperations(config)
    
    try:
        csv_file = f"{config.reclaim_csv_filename}.csv"
        
        # Validate CSV
        success, message = operations.validate_csv(csv_file)
        if not success:
            logger.error(f"✗ Validation failed: {message}")
            logger.info("")
            logger.info("Please ensure:")
            logger.info(f"1. The CSV file exists: {csv_file}")
            logger.info("2. The CSV has a 'target-user' column")
            logger.info("3. The 'target-user' column is populated with usernames")
            sys.exit(1)
        
        logger.info(f"✓ {message}")
        
        # Reclaim mannequins
        success, message = operations.reclaim_mannequins(csv_file)
        if not success:
            logger.error(f"✗ Reclaim failed: {message}")
            logger.info("")
            logger.info("Troubleshooting:")
            logger.info("1. Verify GitHub CLI is installed: gh --version")
            logger.info("2. Verify GEI extension is installed: gh extension list")
            logger.info("3. Check your token has admin:org scope")
            logger.info("4. Verify organization name is correct")
            logger.info("5. Check that target-user values are valid EMU usernames")
            sys.exit(1)
        
        logger.info(f"✓ {message}")
        
        logger.info("")
        logger.info("=" * 70)
        logger.info("✓ RECLAIM COMPLETE!")
        logger.info("=" * 70)
        logger.info("")
        logger.info("NEXT STEPS:")
        logger.info("1. Invitations have been sent to users")
        logger.info("2. Users must accept the invitation via email")
        logger.info("3. Mannequin accounts will be transferred upon acceptance")
        logger.info("")
        logger.info("Invitations sent to:")
        
        # Read and display who was invited
        try:
            with open(csv_file, 'r', newline='', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    target_user = row.get('target-user', '').strip()
                    if target_user:
                        logger.info(f"  - {target_user}")
        except Exception as e:
            logger.debug(f"Could not read invited users: {str(e)}")
        
        logger.info("")
        logger.info(f"Log file: {log_filename}")
        logger.info("=" * 70)
        
    except KeyboardInterrupt:
        logger.warning("✗ Script interrupted by user")
        sys.exit(1)
    except Exception as e:
        logger.error(f"✗ Unexpected error: {str(e)}", exc_info=True)
        sys.exit(1)


if __name__ == '__main__':
    main()
