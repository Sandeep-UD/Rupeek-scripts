#!/usr/bin/env python3
"""
Generate Mannequin CSV Script
Step 1: Generates mannequin CSV from GitHub Enterprise organization

This script queries the GitHub organization for all mannequins and creates
a CSV file that you can then manually update with target users.

Usage:
    python generate_mannequins.py
"""

import os
import sys
import subprocess
import logging
from datetime import datetime
from pathlib import Path
from typing import Tuple
from dotenv import load_dotenv

# ==================== SETUP ====================
# Load environment variables from .env file
load_dotenv()

# Create logs directory if it doesn't exist
LOG_DIR = Path("logs")
LOG_DIR.mkdir(exist_ok=True)

# Configure logging
log_filename = LOG_DIR / f"generate_mannequins_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_filename),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# ==================== CONFIGURATION ====================
class Config:
    """Configuration class to read from environment variables"""
    
    def __init__(self):
        self.github_target_org = os.getenv('GITHUB_TARGET_ORG', '').strip()
        self.github_target_pat = os.getenv('GITHUB_TARGET_PAT', '').strip()
        self.github_api_url = os.getenv('GITHUB_API_URL', '').strip()
        self.output_csv_filename = os.getenv('OUTPUT_CSV_FILENAME', 'mannequins')
        self.reclaim_csv_filename = os.getenv('RECLAIM_CSV_FILENAME', 'mannequins_reclaim')
    
    def validate(self) -> Tuple[bool, str]:
        """Validate configuration"""
        if not self.github_target_org:
            return False, "GITHUB_TARGET_ORG not set in .env file"
        if not self.github_target_pat:
            return False, "GITHUB_TARGET_PAT not set in .env file"
        return True, "Configuration valid"


# ==================== GENERATE OPERATIONS ====================
class GenerateOperations:
    """Class to handle mannequin generation"""
    
    def __init__(self, config: Config):
        self.config = config
    
    def generate_mannequin_csv(self) -> Tuple[bool, str, str]:
        """
        Generate mannequin CSV using gh gei command
        
        Returns:
            Tuple of (success: bool, message: str, output_file: str)
        """
        logger.info("=" * 70)
        logger.info("STEP 1: Generating Mannequin CSV from GitHub Enterprise")
        logger.info("=" * 70)
        
        try:
            output_file = f"{self.config.output_csv_filename}.csv"
            
            # Construct the command
            command = [
                'gh', 'gei', 'generate-mannequin-csv',
                '--github-target-org', self.config.github_target_org,
                '--output', output_file,
                '--github-target-pat', self.config.github_target_pat
            ]
            
            # Add API URL if provided (for self-hosted GitHub Enterprise)
            if self.config.github_api_url:
                command.extend(['--github-target-url', self.config.github_api_url])
                logger.info(f"Using custom API URL: {self.config.github_api_url}")
            
            logger.info(f"Organization: {self.config.github_target_org}")
            logger.info(f"Output file: {output_file}")
            logger.info(f"Running: gh gei generate-mannequin-csv ... (token hidden)")
            
            # Execute the command
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=300  # 5 minute timeout
            )
            
            if result.returncode == 0:
                logger.info(f"✓ Successfully generated mannequin CSV")
                
                # Show output info
                if result.stdout:
                    logger.info(f"Output: {result.stdout.strip()}")
                
                # Verify file exists and has content
                if os.path.exists(output_file):
                    file_size = os.path.getsize(output_file)
                    logger.info(f"✓ CSV file created: {output_file} ({file_size} bytes)")
                    
                    # Read and display CSV info
                    try:
                        with open(output_file, 'r', encoding='utf-8') as f:
                            lines = f.readlines()
                            row_count = len(lines) - 1  # Exclude header
                            logger.info(f"✓ CSV contains {row_count} mannequin(s)")
                            
                            # Show first few lines
                            if row_count > 0:
                                logger.info(f"✓ First row: {lines[1].strip()}")
                    except Exception as e:
                        logger.warning(f"Could not read CSV info: {str(e)}")
                    
                    return True, "CSV generated successfully", output_file
                else:
                    logger.warning(f"CSV file not found: {output_file}")
                    return False, "CSV generated but file not found", ""
            else:
                error_msg = f"Command failed with return code {result.returncode}"
                logger.error(f"✗ {error_msg}")
                
                if result.stderr:
                    logger.error(f"Error: {result.stderr}")
                if result.stdout:
                    logger.error(f"Output: {result.stdout}")
                
                return False, error_msg, ""
        
        except subprocess.TimeoutExpired:
            error_msg = "Command timed out after 5 minutes"
            logger.error(f"✗ {error_msg}")
            return False, error_msg, ""
        except FileNotFoundError:
            error_msg = "gh command not found. Please install GitHub CLI"
            logger.error(f"✗ {error_msg}")
            logger.error("Install from: https://cli.github.com/")
            logger.error("Then install GEI extension: gh extension install github/gh-gei")
            return False, error_msg, ""
        except Exception as e:
            error_msg = f"Unexpected error: {str(e)}"
            logger.error(f"✗ {error_msg}")
            return False, error_msg, ""


# ==================== MAIN ====================
def main():
    """Main function to orchestrate generation"""
    
    logger.info("=" * 70)
    logger.info("GitHub Mannequin Generation Script Started")
    logger.info(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info(f"Log file: {log_filename}")
    logger.info("=" * 70)
    logger.info("")
    
    # Load and validate configuration
    config = Config()
    is_valid, validation_msg = config.validate()
    
    if not is_valid:
        logger.error(f"✗ Configuration validation failed: {validation_msg}")
        logger.error("")
        logger.error("Required settings in .env:")
        logger.error("  - GITHUB_TARGET_ORG     (Your GitHub organization)")
        logger.error("  - GITHUB_TARGET_PAT     (Personal Access Token with admin:org scope)")
        logger.error("")
        logger.error("Optional settings:")
        logger.error("  - GITHUB_API_URL        (For self-hosted GitHub Enterprise)")
        sys.exit(1)
    
    logger.info(f"✓ Configuration loaded successfully")
    logger.info(f"  Organization: {config.github_target_org}")
    logger.info(f"  API URL: {config.github_api_url or 'GitHub.com (default)'}")
    logger.info(f"  Output file: {config.output_csv_filename}.csv")
    logger.info("")
    
    # Initialize operations handler
    operations = GenerateOperations(config)
    
    try:
        # Generate mannequins
        success, message, output_file = operations.generate_mannequin_csv()
        
        if not success:
            logger.error(f"✗ Generation failed: {message}")
            logger.info("")
            logger.info("Troubleshooting:")
            logger.info("1. Verify GitHub CLI is installed: gh --version")
            logger.info("2. Verify GEI extension is installed: gh extension list")
            logger.info("3. Check your token has admin:org scope")
            logger.info("4. Verify organization name is correct")
            sys.exit(1)
        
        logger.info("")
        logger.info("=" * 70)
        logger.info("✓ GENERATION COMPLETE!")
        logger.info("=" * 70)
        logger.info("")
        logger.info("NEXT STEPS:")
        logger.info("1. Open the generated CSV file:")
        logger.info(f"   {output_file}")
        logger.info("")
        logger.info("2. Update the 'target-user' column with EMU usernames:")
        logger.info("   Format: username_ecanarys (e.g., sandeep-doddamani_ecanarys)")
        logger.info("")
        logger.info("3. Save the updated CSV as:")
        logger.info(f"   {config.reclaim_csv_filename}.csv")
        logger.info("")
        logger.info("4. Run the reclaim script:")
        logger.info("   python reclaim_mannequins.py")
        logger.info("")
        logger.info(f"Log file: {log_filename}")
        logger.info("=" * 70)
        
    except KeyboardInterrupt:
        logger.warning("✗ Script interrupted by user")
        sys.exit(1)
    except Exception as e:
        logger.error(f"✗ Unexpected error: {str(e)}", exc_info=True)
        sys.exit(1)


if __name__ == '__main__':
    main()
