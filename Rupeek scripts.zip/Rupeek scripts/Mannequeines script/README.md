# GitHub Enterprise Mannequin Automation

Two-script solution to generate and reclaim mannequins in GitHub Enterprise using the `gh gei` CLI.

## Prerequisites

1. **GitHub CLI (`gh`)** - [Install here](https://cli.github.com/)
2. **GEI Extension** - Install with: `gh extension install github/gh-gei`
3. **Python 3.7+** - [Download here](https://www.python.org/)
4. **GitHub Personal Access Token (PAT)** - Must have admin:org scope

## Setup

### 1. Install Python Dependencies

```bash
pip install -r requirements.txt
```

Or individually:
```bash
pip install python-dotenv requests pandas
```

### 2. Configure Environment Variables

Edit the `.env` file with your values:

```env
GITHUB_TARGET_ORG=your_destination_org          # Your GitHub organization
GITHUB_TARGET_PAT=ghp_xxxxxxxxxxxxx              # Your GitHub token
GITHUB_API_URL=                                  # (Optional) For self-hosted GitHub Enterprise
OUTPUT_CSV_FILENAME=mannequins                    # Output CSV file name
RECLAIM_CSV_FILENAME=mannequins_reclaim          # Reclaim CSV file name
API_RATE_LIMIT=5                                  # Requests per second
PAGE_SIZE=50                                      # Pagination size
```

## Usage - Two Script Approach

### Script 1: Generate Mannequin CSV

```bash
python generate_mannequins.py
```

This will:
1. Query your GitHub organization for all mannequins
2. Generate a CSV file (`mannequins.csv`)
3. Display file information in the console and log

**Output:** `mannequins.csv`

### Step 2: Manual Update (You Do This)

1. Open the generated `mannequins.csv` file
2. Update the `target-user` column with EMU usernames
3. Format: `username_ecanarys` (e.g., `sandeep-doddamani_ecanarys`)
4. Save as `mannequins_reclaim.csv` (or keep the original name and update RECLAIM_CSV_FILENAME in .env)

**Example CSV after update:**
```csv
id,login,name,email,company,target-user
m_001,mannequin_001,Mannequin 001,mannequin@github.example.com,ACME,sandeep-doddamani_ecanarys
m_002,mannequin_002,Mannequin 002,mannequin@github.example.com,ACME,john_smith_ecanarys
```

### Script 2: Reclaim Mannequins

```bash
python reclaim_mannequins.py
```

This will:
1. Validate your CSV file
2. Send reclaim invitations to specified users
3. Log all actions and results

**Next:** Users must accept the invitation via email to complete the transfer.

## Workflow Steps

```
┌─────────────────────────────────────────────────────────┐
│ Step 1: Generate CSV                                     │
│ python generate_mannequins.py                            │
│ → Creates mannequins.csv                                 │
└─────────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────────┐
│ Step 2: Manual Update (You)                              │
│ Open mannequins.csv and fill target-user column          │
│ Save as mannequins_reclaim.csv                           │
└─────────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────────┐
│ Step 3: Reclaim Mannequins                               │
│ python reclaim_mannequins.py                             │
│ → Sends invitations to users                             │
└─────────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────────┐
│ Step 4: User Action                                      │
│ Users receive emails and accept invitations              │
│ Mannequins are transferred to users                      │
└─────────────────────────────────────────────────────────┘
```

## CSV File Format

### Generated Mannequin CSV (`mannequins.csv`)
```csv
id,login,name,email,company,target-user
m_001,mannequin_001,Mannequin 001,mannequin@github.example.com,ACME,
m_002,mannequin_002,Mannequin 002,mannequin@github.example.com,ACME,
```

You need to fill in the `target-user` column with EMU usernames (format: `username_ecanarys`).

### Updated Reclaim CSV (`mannequins_reclaim.csv`)
```csv
id,login,name,email,company,target-user
m_001,mannequin_001,Mannequin 001,mannequin@github.example.com,ACME,sandeep-doddamani_ecanarys
m_002,mannequin_002,Mannequin 002,mannequin@github.example.com,ACME,john_smith_ecanarys
```

## Features

### Generate Script Features
✅ Queries GitHub organization for mannequins  
✅ Creates CSV with all mannequin data  
✅ Validates output file  
✅ Shows record count and file size  
✅ Error logging with detailed messages  

### Reclaim Script Features
✅ Validates CSV before processing  
✅ Checks for required columns  
✅ Warns about missing target-user values  
✅ Sends reclaim invitations  
✅ Lists all users who were invited  
✅ Comprehensive error handling  

### Both Scripts Include
✅ Configurable via `.env` file  
✅ API rate limiting  
✅ Pagination support  
✅ Detailed logging to file and console  
✅ Timestamp-based log files  
✅ Error recovery and helpful troubleshooting tips  

## Configuration Options

### Required (.env)
```env
GITHUB_TARGET_ORG=my-org              # Your organization name
GITHUB_TARGET_PAT=ghp_xxxxx           # Personal Access Token
```

### Optional (.env)
```env
GITHUB_API_URL=https://github.enterprise.com/api/v3     # For self-hosted
OUTPUT_CSV_FILENAME=mannequins                           # Generate output
RECLAIM_CSV_FILENAME=mannequins_reclaim                  # Reclaim input
API_RATE_LIMIT=5                                         # Requests/sec
PAGE_SIZE=50                                             # Pagination size
```

## Error Logs

All operations are logged to timestamped files:

```
logs/
├── generate_mannequins_20240117_143022.log
├── reclaim_mannequins_20240117_150045.log
└── ...
```

Check the log files if something fails for detailed error information.

## Troubleshooting

### "gh command not found"
```bash
# Install GitHub CLI
# macOS:
brew install gh

# Windows:
choco install gh
# or download from https://cli.github.com/

# Verify installation:
gh --version
```

### "gei extension not installed"
```bash
gh extension install github/gh-gei

# Verify:
gh extension list
```

### "Invalid token" error
- Check your GitHub PAT in `.env`
- Ensure token has `admin:org` scope
- Verify token is not expired
- Token cannot be used with SAML SSO unless authorized

### "Organization not found"
- Verify `GITHUB_TARGET_ORG` in `.env` is correct
- Check that your token has access to the org
- Verify spelling and case sensitivity

### CSV format errors
- Ensure CSV uses UTF-8 encoding
- Check that column headers match expected format
- No extra spaces or special characters in usernames
- Use format: `username_ecanarys`

### "No valid rows with target-user values"
- Ensure you updated the `target-user` column in the CSV
- Check that values are not empty
- Verify CSV hasn't been corrupted

## Advantages of Two-Script Approach

1. **Review Step** - Time to review and validate mannequins before reclaim
2. **Error Prevention** - Manually verify target-user mappings
3. **Flexibility** - Can run generate once, reclaim multiple times
4. **Transparency** - Clear separation between data gathering and action
5. **Safety** - Less chance of automating incorrect data
6. **Auditability** - Easier to track who was invited when

## Security Notes

⚠️ **Important:**
- Never commit `.env` file to version control
- Never share your GitHub PAT
- Add `.env` to `.gitignore`
- Use organization-specific tokens
- Rotate tokens regularly
- Don't share CSV files with sensitive username mappings

## Support

For issues with:
- **GitHub CLI**: https://github.com/cli/cli/issues
- **GEI Extension**: https://github.com/github/gh-gei/issues
- **Token Scopes**: https://docs.github.com/en/developers/apps/building-oauth-apps/scopes-for-oauth-apps
- **GitHub Enterprise**: Contact your GitHub Enterprise administrator

## License

MIT License - Use freely for GitHub Enterprise operations.
