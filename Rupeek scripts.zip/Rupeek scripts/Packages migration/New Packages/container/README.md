# Container Package Migration Script

A comprehensive Bash script to migrate Docker/OCI container images between GitHub organizations with built-in rate limiting, token rotation, and retry logic.

## Features

- **Multiple Token Support**: Use multiple GitHub tokens with automatic rotation on rate limits
- **Pagination Support**: Automatically handles paginated API responses
- **Rate Limit Management**: Intelligent token rotation when GitHub API rate limits are hit
- **CSV Reporting**: Detailed migration status report for each package version
- **Error Logging**: Captures errors and provides detailed error messages
- **Retry Logic**: Automatic retries for both API calls and container operations
- **Flexible Container Tools**: Supports both Docker CLI and Skopeo
- **Batch Processing**: Migrates all versions of all container packages in an organization
- **Tag Preservation**: Maintains all tags for each container version

## Prerequisites

- Bash 4.0+
- `gh` (GitHub CLI) v2.0+
- `jq` (JSON processor)
- **One of the following container tools:**
  - `skopeo` (recommended for efficiency) - [Installation guide](https://github.com/containers/skopeo/blob/main/install.md)
  - `docker` (Docker CLI)
- GitHub Personal Access Tokens (PATs) with appropriate scopes

## Required Token Scopes

- **Source token(s)**: `read:packages`, `read:org`
- **Target token(s)**: `write:packages`, `read:org`

## Setup

### 1. Create `.env` file

Create a `.env` file in the same directory as the script with the following variables:

```bash
# Required
SOURCE_ORG=source-organization
TARGET_ORG=target-organization

# Single token mode
GH_SOURCE_PAT=ghp_xxxxxxxxxxxxxxxxxxxx
GH_TARGET_PAT=ghp_xxxxxxxxxxxxxxxxxxxx

# OR Multi-token mode (comma-separated, no spaces)
# GH_SOURCE_PATS=token1,token2,token3
# GH_TARGET_PATS=tokenA,tokenB,tokenC

# Optional (defaults to github.com)
SOURCE_HOST=github.com
TARGET_HOST=github.com

# Optional (default: 10 latest versions per package)
MAX_VERSIONS_PER_PACKAGE=10

# Optional retry configuration
MAX_RETRIES=5
RETRY_BASE_SECONDS=2
```

### 2. Token Format

For multiple tokens (recommended for rate limit handling):
```bash
GH_SOURCE_PATS=ghp_xxxxxxxxxxxx,ghp_yyyyyyyyy,ghp_zzzzzzzzzz
GH_TARGET_PATS=ghp_aaaaaaaaaa,ghp_bbbbbbbbbb,ghp_cccccccccc
```

Multiple tokens allow the script to rotate through them when rate limits are encountered.

### 3. Install Required Tools

#### Option A: Skopeo (Recommended)

Skopeo is more efficient as it copies images directly between registries without local storage.

**Linux:**
```bash
# Ubuntu/Debian
sudo apt-get update
sudo apt-get install skopeo

# RHEL/CentOS/Fedora
sudo dnf install skopeo
```

**macOS:**
```bash
brew install skopeo
```

**Windows:**
```bash
# WSL2 required
wsl --install
# Then install in WSL using Linux instructions
```

#### Option B: Docker

If you already have Docker Desktop or Docker CLI installed, the script will use it automatically.

## Usage

### Basic Usage

```bash
chmod +x migrate-container-packages-between-orgs.sh
./migrate-container-packages-between-orgs.sh
```

### Package Selection via `packages.csv`

If `packages.csv` exists in the script folder, the script migrates only the packages listed in that file.
If `packages.csv` is missing or empty, the script migrates **all** container packages from the source organization.

#### Format

`packages.csv` is treated as a single-column package list (one package name per line).

- `package` header line is optional
- Lines starting with `#` are treated as comments
- Blank lines are ignored
- Use the exact GitHub container package name

**Example:**

```csv
package
my-app
backend-service
frontend-ui
# Hold for now
# legacy-app
```

**Important:** The script reads only the first column as package name. If additional columns exist (for example version, repo, status), they are ignored.

## Version Selection

By default, the script migrates only the **latest 10 versions** per container package, and processes them in **oldest to newest** order (so the newest selected version is pushed last).

- `MAX_VERSIONS_PER_PACKAGE=10` (default): Migrate the 10 most recent versions
- `MAX_VERSIONS_PER_PACKAGE=25`: Migrate the 25 most recent versions
- `MAX_VERSIONS_PER_PACKAGE=0`: Migrate **all** versions

Set this in your `.env` file:

```bash
MAX_VERSIONS_PER_PACKAGE=0  # Migrate all versions
```

## Container Registry Details

### GitHub Container Registry (GHCR)

Container packages are hosted at:
- Registry URL: `ghcr.io`
- Source format: `ghcr.io/SOURCE_ORG/PACKAGE_NAME:TAG`
- Target format: `ghcr.io/TARGET_ORG/PACKAGE_NAME:TAG`

### Authentication

The script handles authentication automatically using your GitHub tokens:
- **Skopeo**: Passes credentials per-operation
- **Docker**: Performs `docker login` before pull/push operations

## Output Files

All output files are created in the `./temp` directory:

| File | Description |
|------|-------------|
| `migration-report.csv` | Detailed CSV report of all migration operations |
| `migration-errors.log` | Tab-separated log of errors encountered |
| `failed-packages.txt` | List of packages that failed to migrate |

### CSV Report Columns

- **Timestamp**: ISO 8601 UTC timestamp
- **Package**: Container package name
- **Version**: Tag or version identifier
- **Action**: Operation performed (e.g., `migrate`, `skip`)
- **Status**: Result (`success`, `failed`, `skipped`, `error`)
- **Message**: Detailed status message

### Terminal Summary

At the end of a run, the script prints both package-level and version-level totals to avoid ambiguity:

- **Package-level**:
  - Packages discovered in source
  - Packages iterated
  - Packages selected for migration
  - Packages skipped by filter
  - Packages with >=1 successful version migration
  - Packages with >=1 failed migration/error
- **Version-level**:
  - Successful version migrations
  - Failed version migrations/errors
  - Skipped versions

## Examples

### Example 1: Migrate All Containers

```bash
# .env file
SOURCE_ORG=acme-corp
TARGET_ORG=acme-corp-backup
GH_SOURCE_PAT=ghp_source_token
GH_TARGET_PAT=ghp_target_token
MAX_VERSIONS_PER_PACKAGE=0  # All versions

# Run migration
./migrate-container-packages-between-orgs.sh
```

### Example 2: Migrate Specific Containers

```bash
# packages.csv
package
web-frontend
api-backend
worker-service

# Run migration
./migrate-container-packages-between-orgs.sh
```

### Example 3: Migrate Latest 5 Versions Only

```bash
# .env file
SOURCE_ORG=acme-corp
TARGET_ORG=acme-corp-new
GH_SOURCE_PAT=ghp_source_token
GH_TARGET_PAT=ghp_target_token
MAX_VERSIONS_PER_PACKAGE=5

# Run migration
./migrate-container-packages-between-orgs.sh
```

### Example 4: Cross-Instance Migration

```bash
# .env file
SOURCE_ORG=acme-corp
TARGET_ORG=acme-external
SOURCE_HOST=github.com
TARGET_HOST=ghe.company.com
GH_SOURCE_PAT=ghp_source_token
GH_TARGET_PAT=ghp_target_token

# Run migration
./migrate-container-packages-between-orgs.sh
```

## How It Works

1. **Load Configuration**: Reads `.env` file and validates settings
2. **Token Setup**: Configures token rotation for rate limit handling
3. **Package Discovery**: Lists all container packages in source organization via GitHub API
4. **Filter Application**: Applies `packages.csv` filter if present
5. **Version Retrieval**: Gets all versions for each package
6. **Version Sorting**: Sorts versions by creation date and prepares migration order
7. **Version Limiting**: Selects the latest `MAX_VERSIONS_PER_PACKAGE` versions if set, then migrates oldest to newest within that selection
8. **Container Migration**: For each version:
   - Pulls from source registry (or copies directly with skopeo)
   - Pushes to target registry
   - Preserves all tags
9. **Reporting**: Generates CSV report and error logs

## Troubleshooting

### "Neither skopeo nor docker is installed"

Install one of the required container tools (see Prerequisites section).

### Rate Limit Errors

- Add multiple tokens to your `.env` file:
  ```bash
  GH_SOURCE_PATS=token1,token2,token3
  GH_TARGET_PATS=tokenA,tokenB,tokenC
  ```
- The script will automatically rotate through tokens

### Authentication Failures

- Verify your tokens have the correct scopes:
  - Source: `read:packages`, `read:org`
  - Target: `write:packages`, `read:org`
- Ensure tokens are not expired
- Check that you have access to both organizations

### "No container packages found"

- Verify the source organization has container packages
- Check that your source token has `read:packages` scope
- Ensure you're using the correct organization name

### Docker Daemon Not Running

If using Docker and you see "Cannot connect to the Docker daemon":
```bash
# Start Docker Desktop (Windows/macOS)
# Or start Docker daemon (Linux)
sudo systemctl start docker
```

### Untagged Versions Skipped

Container versions without tags are automatically skipped. This is expected behavior as untagged images cannot be reliably referenced.

## Performance Notes

- **Skopeo** is significantly faster than Docker as it:
  - Copies images directly between registries
  - Doesn't store images locally
  - Uses less disk space
  - Supports concurrent operations

- **Docker** is slower but more widely available:
  - Downloads images to local disk
  - Requires more disk space
  - More familiar to most users

## Cleanup

To remove temporary files after migration:

```bash
rm -rf ./temp
```

## Limitations

- Untagged container versions are skipped (no reliable way to reference them)
- Very large images may take significant time to transfer
- Rate limits apply to GitHub API calls (mitigated by token rotation)

## Security Considerations

- Keep your `.env` file secure and never commit it to version control
- Add `.env` to your `.gitignore`
- Use tokens with minimal required scopes
- Rotate tokens regularly
- Consider using different tokens for different operations

## Contributing

Improvements and bug fixes are welcome. Please ensure:
- Scripts remain compatible with existing `.env` format
- Error handling is comprehensive
- Output formatting matches existing patterns

## License

This script is provided as-is for GitHub Packages migration purposes.

## Related Scripts

This script follows the same pattern as:
- `maven/migrate-maven-packages-between-orgs.sh`
- `npm/migrate-npm-packages-between-github-instances.sh`
- `nuget/migrate-nuget-packages-between-orgs.sh`
- `rubygems/migrate-rubygems-packages-between-github-instances.sh`

All scripts share common patterns for token management, error handling, and reporting.

## Updates after migration

After migrating container packages, update your consumers and delivery pipelines to point to the target organization.

### 1. Image/repository references

- Update image paths from `ghcr.io/SOURCE_ORG/...` to `ghcr.io/TARGET_ORG/...`.
- Update references in Dockerfiles, Helm charts, Kubernetes manifests, Terraform, and deployment scripts.

### 2. Authentication credentials

- Update registry credentials to use target-org tokens.
- Remove/rotate old source-org tokens where no longer needed.
- Confirm token scopes: `read:packages` for pull, `write:packages` for push.

### 3. CI/CD pipeline updates

- GitHub Actions: update secrets/PATs and ensure workflow permissions can access target org packages.
- Jenkins/other CI: update credential stores, registry login steps, and environment variables.
- Replace hardcoded old-org GHCR URLs in pipeline definitions.

### 4. Runtime/deployment validation

- Re-run build and deploy pipelines using the new image paths.
- Verify cluster/runtime can pull images from target org (imagePullSecrets/service accounts).
- Confirm rollout success and image digest/tag resolution in target environments.
