#!/bin/bash

# Container Package Migration Script for GitHub Packages
# Migrates Docker/OCI container images between GitHub organizations
#
# Prerequisites:
# 1. gh (GitHub CLI) installed
# 2. docker or skopeo installed
# 3. .env file configured (see .env.example or README.md)
#
# Usage: ./migrate-container-packages-between-orgs.sh

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="$SCRIPT_DIR/.env"

#############################################
# Load Environment Variables
#############################################

if [ ! -f "$ENV_FILE" ]; then
  echo "Error: .env file not found at $ENV_FILE"
  echo "Create it based on the template in README.md"
  exit 1
fi

# Normalize CRLF to LF for Windows compatibility
sanitized_env_file=$(mktemp)
sed 's/\r$//' "$ENV_FILE" > "$sanitized_env_file"
set -o allexport
# shellcheck source=.env
source "$sanitized_env_file"
set +o allexport
rm -f "$sanitized_env_file"

#############################################
# Configuration & Validation
#############################################

if [ -z "${SOURCE_ORG:-}" ]; then
  echo "Error: SOURCE_ORG is not set in .env"
  exit 1
fi

if [ -z "${TARGET_ORG:-}" ]; then
  echo "Error: TARGET_ORG is not set in .env"
  exit 1
fi

SOURCE_HOST=${SOURCE_HOST:-github.com}
TARGET_HOST=${TARGET_HOST:-github.com}
MAX_VERSIONS_PER_PACKAGE=${MAX_VERSIONS_PER_PACKAGE:-10}
MAX_RETRIES=${MAX_RETRIES:-5}
RETRY_BASE_SECONDS=${RETRY_BASE_SECONDS:-2}
MIGRATE_UNTAGGED=${MIGRATE_UNTAGGED:-false}

if ! [[ "$MAX_VERSIONS_PER_PACKAGE" =~ ^[0-9]+$ ]]; then
  echo "Error: MAX_VERSIONS_PER_PACKAGE must be a non-negative integer"
  exit 1
fi

# Detect which container tool to use
CONTAINER_TOOL=""
if command -v skopeo &> /dev/null; then
  CONTAINER_TOOL="skopeo"
  echo "Using skopeo for container operations"
elif command -v docker &> /dev/null; then
  CONTAINER_TOOL="docker"
  echo "Using docker for container operations"
else
  echo "Error: Neither skopeo nor docker is installed"
  echo "Install one of these tools to proceed"
  exit 1
fi

ROOT_DIR="$SCRIPT_DIR"
TEMP_DIR="$ROOT_DIR/temp"
CSV_FILE="$TEMP_DIR/migration-report.csv"
ERROR_LOG="$TEMP_DIR/migration-errors.log"
FAILED_PACKAGES_FILE="$TEMP_DIR/failed-packages.txt"
PACKAGES_CSV="$SCRIPT_DIR/packages.csv"

mkdir -p "$TEMP_DIR"

#############################################
# Token Management
#############################################

split_tokens() {
  local input="$1"
  local -n out_array=$2
  local token

  out_array=()
  IFS=',' read -r -a raw_tokens <<<"$input"
  for token in "${raw_tokens[@]}"; do
    token="${token#${token%%[![:space:]]*}}"
    token="${token%${token##*[![:space:]]}}"
    if [ -n "$token" ]; then
      out_array+=("$token")
    fi
  done
}

SOURCE_TOKENS=()
TARGET_TOKENS=()

if [ -n "${GH_SOURCE_PATS:-}" ]; then
  split_tokens "$GH_SOURCE_PATS" SOURCE_TOKENS
elif [ -n "${GH_SOURCE_PAT:-}" ]; then
  SOURCE_TOKENS=("$GH_SOURCE_PAT")
fi

if [ -n "${GH_TARGET_PATS:-}" ]; then
  split_tokens "$GH_TARGET_PATS" TARGET_TOKENS
elif [ -n "${GH_TARGET_PAT:-}" ]; then
  TARGET_TOKENS=("$GH_TARGET_PAT")
fi

if [ ${#SOURCE_TOKENS[@]} -eq 0 ]; then
  echo "Error: GH_SOURCE_PAT or GH_SOURCE_PATS is required in .env"
  exit 1
fi

if [ ${#TARGET_TOKENS[@]} -eq 0 ]; then
  echo "Error: GH_TARGET_PAT or GH_TARGET_PATS is required in .env"
  exit 1
fi

SOURCE_TOKEN_INDEX=0
TARGET_TOKEN_INDEX=0

get_current_token() {
  local role="$1"
  if [ "$role" = "source" ]; then
    echo "${SOURCE_TOKENS[$SOURCE_TOKEN_INDEX]}"
  else
    echo "${TARGET_TOKENS[$TARGET_TOKEN_INDEX]}"
  fi
}

rotate_token() {
  local role="$1"
  if [ "$role" = "source" ]; then
    SOURCE_TOKEN_INDEX=$(( (SOURCE_TOKEN_INDEX + 1) % ${#SOURCE_TOKENS[@]} ))
    echo "Rotated source token to index $SOURCE_TOKEN_INDEX"
  else
    TARGET_TOKEN_INDEX=$(( (TARGET_TOKEN_INDEX + 1) % ${#TARGET_TOKENS[@]} ))
    echo "Rotated target token to index $TARGET_TOKEN_INDEX"
  fi
}

#############################################
# Utility Functions
#############################################

is_rate_limit_error() {
  local error_text="$1"
  echo "$error_text" | grep -Eqi 'rate limit|secondary rate|HTTP 429|status code: 429|too many requests'
}

is_transient_error() {
  local error_text="$1"
  echo "$error_text" | grep -Eqi 'timeout|timed out|temporar|connection reset|502|503|504'
}

sleep_with_backoff() {
  local attempt="$1"
  local seconds=$(( RETRY_BASE_SECONDS * attempt ))
  echo "Retrying in ${seconds}s..."
  sleep "$seconds"
}

log_error() {
  local package_name="$1"
  local version="$2"
  local stage="$3"
  local message="$4"
  printf '%s\t%s\t%s\t%s\t%s\n' "$(date -u +"%Y-%m-%dT%H:%M:%SZ")" "$package_name" "$version" "$stage" "$message" >>"$ERROR_LOG"
}

csv_escape() {
  local s="$1"
  s="${s//\"/\"\"}"
  printf '"%s"' "$s"
}

write_csv_row() {
  local package_name="$1"
  local version="$2"
  local action="$3"
  local status="$4"
  local message="$5"
  printf '%s,%s,%s,%s,%s,%s\n' \
    "$(csv_escape "$(date -u +"%Y-%m-%dT%H:%M:%SZ")")" \
    "$(csv_escape "$package_name")" \
    "$(csv_escape "$version")" \
    "$(csv_escape "$action")" \
    "$(csv_escape "$status")" \
    "$(csv_escape "$message")" >>"$CSV_FILE"
}

#############################################
# GitHub API Functions
#############################################

gh_api_call() {
  local role="$1"
  local host="$2"
  local endpoint="$3"
  local paginate="$4"

  local attempt token output err_file
  for attempt in $(seq 1 "$MAX_RETRIES"); do
    token=$(get_current_token "$role")
    err_file=$(mktemp)

    if [ "$paginate" = "true" ]; then
      if output=$(MSYS_NO_PATHCONV=1 GH_HOST="$host" GH_TOKEN="$token" gh api --paginate "$endpoint" 2>"$err_file"); then
        rm -f "$err_file"
        echo "$output"
        return 0
      fi
    else
      if output=$(MSYS_NO_PATHCONV=1 GH_HOST="$host" GH_TOKEN="$token" gh api "$endpoint" 2>"$err_file"); then
        rm -f "$err_file"
        echo "$output"
        return 0
      fi
    fi

    local err_text
    err_text=$(cat "$err_file")
    rm -f "$err_file"

    if is_rate_limit_error "$err_text"; then
      echo "Rate limit hit for ${role} token on endpoint: $endpoint"
      rotate_token "$role"
      sleep_with_backoff "$attempt"
      continue
    fi

    if is_transient_error "$err_text"; then
      echo "Transient API error on endpoint: $endpoint"
      sleep_with_backoff "$attempt"
      continue
    fi

    echo "$err_text" >&2
    return 1
  done

  return 1
}

#############################################
# Package Filter Functions
#############################################

PACKAGE_FILTER_ENABLED=0
PACKAGE_FILTER_RAW=""
PACKAGE_FILTER_COUNT=0
declare -A PACKAGE_FILTER_SET=()

trim_whitespace() {
  local value="$1"
  # Trim leading/trailing whitespace
  value="${value#${value%%[![:space:]]*}}"
  value="${value%${value##*[![:space:]]}}"
  printf '%s' "$value"
}

load_package_filter() {
  if [ -f "$PACKAGES_CSV" ]; then
    echo "Found packages.csv - checking for package filters..."
    PACKAGE_FILTER_RAW=""
    PACKAGE_FILTER_COUNT=0
    PACKAGE_FILTER_SET=()

    local line pkg first_col normalized
    while IFS= read -r line || [ -n "$line" ]; do
      normalized=$(echo "$line" | tr -d '\r')
      normalized=$(trim_whitespace "$normalized")

      # Skip comments and empty rows
      if [ -z "$normalized" ] || [[ "$normalized" =~ ^# ]]; then
        continue
      fi

      # Use only first CSV column as package name
      first_col="${normalized%%,*}"
      first_col=$(trim_whitespace "$first_col")

      # Remove surrounding double quotes from first column if present
      if [[ "$first_col" == \"*\" ]]; then
        first_col="${first_col#\"}"
        first_col="${first_col%\"}"
      fi

      pkg=$(trim_whitespace "$first_col")

      # Ignore header row and empty values
      if [ -z "$pkg" ] || [ "${pkg,,}" = "package" ]; then
        continue
      fi

      if [ -z "${PACKAGE_FILTER_SET[$pkg]+x}" ]; then
        PACKAGE_FILTER_SET["$pkg"]=1
        PACKAGE_FILTER_COUNT=$((PACKAGE_FILTER_COUNT + 1))
        PACKAGE_FILTER_RAW+="$pkg"$'\n'
      fi
    done < "$PACKAGES_CSV"

    if [ "$PACKAGE_FILTER_COUNT" -eq 0 ]; then
      echo "packages.csv has no package entries - migrating all packages from source org."
      PACKAGE_FILTER_ENABLED=0
    else
      echo "packages.csv contains $PACKAGE_FILTER_COUNT package(s) to migrate."
      PACKAGE_FILTER_ENABLED=1
    fi
  else
    echo "packages.csv not found - migrating all packages from source org."
    PACKAGE_FILTER_ENABLED=0
  fi
}

package_in_filter() {
  local candidate="$1"
  [ -n "${PACKAGE_FILTER_SET[$candidate]+x}" ]
}

#############################################
# Container Operations
#############################################

container_login() {
  local role="$1"
  local host="$2"
  local token
  
  token=$(get_current_token "$role")
  local registry_url="ghcr.io"
  
  if [ "$CONTAINER_TOOL" = "docker" ]; then
    echo "$token" | docker login "$registry_url" -u "$(get_current_token "$role" | cut -c1-10)" --password-stdin 2>/dev/null || {
      echo "$token" | docker login "$registry_url" -u "token" --password-stdin
    }
  elif [ "$CONTAINER_TOOL" = "skopeo" ]; then
    # skopeo login is optional; credentials can be passed per-command
    echo "Skopeo will use credentials per operation"
  fi
}

copy_container_image() {
  local source_image="$1"
  local target_image="$2"
  local attempt
  
  for attempt in $(seq 1 "$MAX_RETRIES"); do
    local source_token target_token
    source_token=$(get_current_token "source")
    target_token=$(get_current_token "target")
    
    if [ "$CONTAINER_TOOL" = "skopeo" ]; then
      if skopeo copy \
        --src-creds="token:${source_token}" \
        --dest-creds="token:${target_token}" \
        "docker://${source_image}" \
        "docker://${target_image}" 2>&1; then
        return 0
      fi
    elif [ "$CONTAINER_TOOL" = "docker" ]; then
      # Pull from source
      container_login "source" "$SOURCE_HOST"
      if ! docker pull "$source_image" 2>&1; then
        if [ $attempt -lt "$MAX_RETRIES" ]; then
          sleep_with_backoff "$attempt"
          continue
        else
          return 1
        fi
      fi
      
      # Tag for target
      docker tag "$source_image" "$target_image"
      
      # Push to target
      container_login "target" "$TARGET_HOST"
      if docker push "$target_image" 2>&1; then
        # Cleanup local images
        docker rmi "$source_image" "$target_image" 2>/dev/null || true
        return 0
      fi
    fi
    
    if [ $attempt -lt "$MAX_RETRIES" ]; then
      echo "Attempt $attempt failed, retrying..."
      sleep_with_backoff "$attempt"
    fi
  done
  
  return 1
}

#############################################
# Repository Linking Functions
#############################################

get_package_repository() {
  local role="$1"
  local host="$2"
  local package_name="$3"
  
  local package_info
  package_info=$(gh_api_call "$role" "$host" "/orgs/$SOURCE_ORG/packages/container/$package_name" "false")
  
  if [ -z "$package_info" ]; then
    echo ""
    return 1
  fi
  
  local repo_full_name
  repo_full_name=$(echo "$package_info" | jq -r '.repository.full_name // empty')
  
  echo "$repo_full_name"
}

link_package_to_repository() {
  local package_name="$1"
  local repository_name="$2"
  
  if [ -z "$repository_name" ] || [ "$repository_name" = "null" ]; then
    return 0
  fi
  
  # Extract just the repo name (without org prefix)
  local repo_name_only
  repo_name_only=$(echo "$repository_name" | sed 's|.*/||')
  
  local target_repo="$TARGET_ORG/$repo_name_only"
  
  # GitHub Packages REST API does not support setting repository association via PATCH.
  # The link must be made through the GitHub web UI or by republishing via GitHub Actions.
  echo "    ⚠ Repository linking cannot be done via API (GitHub limitation)"
  echo "    ➜ To link manually, visit:"
  echo "      https://${TARGET_HOST}/orgs/${TARGET_ORG}/packages/container/package/${package_name}"
  echo "      → Click 'Connect repository' and select '${target_repo}'"
}

#############################################
# Main Migration Logic
#############################################

main() {
  echo "=========================================="
  echo "Container Package Migration"
  echo "=========================================="
  echo "Source: $SOURCE_ORG @ $SOURCE_HOST"
  echo "Target: $TARGET_ORG @ $TARGET_HOST"
  echo "Container tool: $CONTAINER_TOOL"
  echo "=========================================="
  echo ""

  # Initialize CSV file
  echo "Timestamp,Package,Version,Action,Status,Message" > "$CSV_FILE"
  
  # Load package filter
  load_package_filter

  # Get list of container packages from source org
  echo "Fetching container packages from source organization..."
  local packages_json
  packages_json=$(gh_api_call "source" "$SOURCE_HOST" "/orgs/$SOURCE_ORG/packages?package_type=container&per_page=100" "true")
  
  if [ -z "$packages_json" ]; then
    echo "No container packages found in source organization"
    exit 0
  fi

  local package_names
  package_names=$(echo "$packages_json" | jq -r '.[].name' | sort -u)
  
  local total_packages
  total_packages=$(echo "$package_names" | wc -l)
  echo "Found $total_packages container package(s) in source organization"
  echo ""

  local pkg_count=0
  local selected_pkg_count=0
  local skipped_pkg_count=0
  local success_package_count=0
  local failed_package_count=0
  local success_version_count=0
  local failed_version_count=0
  local skipped_version_count=0

  while IFS= read -r package_name; do
    [ -z "$package_name" ] && continue
    
    # Strip any trailing whitespace/newlines
    package_name=$(echo "$package_name" | tr -d '\r\n')
    
    pkg_count=$((pkg_count + 1))
    
    # Check package filter
    if [ "$PACKAGE_FILTER_ENABLED" -eq 1 ]; then
      if ! package_in_filter "$package_name"; then
        echo "[$pkg_count/$total_packages] Skipping $package_name (not in packages.csv)"
        write_csv_row "$package_name" "N/A" "skip" "skipped" "Not in packages.csv filter"
        skipped_pkg_count=$((skipped_pkg_count + 1))
        continue
      fi
    fi

    selected_pkg_count=$((selected_pkg_count + 1))
    local package_had_success=0
    local package_had_failure=0
    
    echo "=========================================="
    echo "[$pkg_count/$total_packages] Processing: $package_name"
    echo "=========================================="
    
    # Get repository link from source package
    echo "Checking source package repository link..."
    local source_repository
    source_repository=$(get_package_repository "source" "$SOURCE_HOST" "$package_name")
    
    if [ -n "$source_repository" ]; then
      echo "Source package is linked to repository: $source_repository"
    else
      echo "Source package has no repository link"
    fi
    
    # Get package versions
    local versions_json
    versions_json=$(gh_api_call "source" "$SOURCE_HOST" "/orgs/$SOURCE_ORG/packages/container/$package_name/versions?per_page=100" "true")
    
    if [ -z "$versions_json" ]; then
      echo "No versions found for $package_name"
      write_csv_row "$package_name" "N/A" "list-versions" "error" "No versions found"
      failed_version_count=$((failed_version_count + 1))
      package_had_failure=1

      if [ $package_had_success -eq 1 ]; then
        success_package_count=$((success_package_count + 1))
      fi
      if [ $package_had_failure -eq 1 ]; then
        failed_package_count=$((failed_package_count + 1))
      fi
      continue
    fi
    
    # Parse versions and tags
    local versions_data
    versions_data=$(echo "$versions_json" | jq -r '.[] | 
      {
        id: .id,
        created: .created_at,
        tags: (.metadata.container.tags // [])
      } | 
      @json')
    
    # Keep selection as latest N versions, but process oldest->newest so newest is pushed last
    local sorted_versions
    if [ "$MAX_VERSIONS_PER_PACKAGE" -eq 0 ]; then
      sorted_versions=$(echo "$versions_data" | jq -s 'sort_by(.created)')
    else
      sorted_versions=$(echo "$versions_data" | jq -s "sort_by(.created) | reverse | .[:$MAX_VERSIONS_PER_PACKAGE] | reverse")
    fi
    
    local version_count
    version_count=$(echo "$sorted_versions" | jq 'length')
    echo "Found $version_count version(s) to migrate"
    
    local ver_index=0
    local repo_linked=0
    while [ $ver_index -lt "$version_count" ]; do
      local version_data
      version_data=$(echo "$sorted_versions" | jq -r ".[$ver_index]")
      
      local version_id
      version_id=$(echo "$version_data" | jq -r '.id')
      
      local tags
      tags=$(echo "$version_data" | jq -r '.tags | join(", ")')
      
      if [ -z "$tags" ] || [ "$tags" = "null" ]; then
        tags="<untagged>"
        
        if [ "$MIGRATE_UNTAGGED" = "true" ]; then
          echo "  Version ID $version_id: $tags (will migrate using digest)"
          
          # Get the digest for this version
          local digest
          digest=$(gh_api_call "source" "$SOURCE_HOST" "/orgs/$SOURCE_ORG/packages/container/$package_name/versions/$version_id" "false" | jq -r '.name // empty')
          
          if [ -z "$digest" ] || [ "$digest" = "null" ]; then
            echo "    ✗ Could not retrieve digest for untagged version"
            write_csv_row "$package_name" "$version_id" "migrate" "error" "Could not get digest"
            ver_index=$((ver_index + 1))
            continue
          fi
          
          # Migrate using digest
          local source_image="ghcr.io/${SOURCE_ORG,,}/$package_name@$digest"
          local target_image="ghcr.io/${TARGET_ORG,,}/$package_name@$digest"
          
          echo "    Source: $source_image"
          echo "    Target: $target_image"
          
          if copy_container_image "$source_image" "$target_image"; then
            echo "    ✓ Successfully migrated untagged version"
            write_csv_row "$package_name" "$digest" "migrate" "success" "Migrated untagged version"
            success_version_count=$((success_version_count + 1))
            package_had_success=1
            
            # Link package to repository on first successful migration
            if [ $repo_linked -eq 0 ] && [ -n "$source_repository" ]; then
              if link_package_to_repository "$package_name" "$source_repository"; then
                repo_linked=1
              fi
            fi
          else
            echo "    ✗ Failed to migrate untagged version"
            write_csv_row "$package_name" "$digest" "migrate" "failed" "Copy failed"
            failed_version_count=$((failed_version_count + 1))
            package_had_failure=1
          fi
          
          ver_index=$((ver_index + 1))
          continue
        else
          echo "  Version ID $version_id: $tags (skipping untagged)"
          write_csv_row "$package_name" "$version_id" "migrate" "skipped" "Untagged version"
          skipped_version_count=$((skipped_version_count + 1))
          ver_index=$((ver_index + 1))
          continue
        fi
      fi
      
      echo "  Migrating version with tags: $tags"
      
      # Get the first tag for migration
      local primary_tag
      primary_tag=$(echo "$version_data" | jq -r '.tags[0]')
      
      if [ -z "$primary_tag" ] || [ "$primary_tag" = "null" ]; then
        echo "    Error: Could not determine primary tag"
        write_csv_row "$package_name" "$version_id" "migrate" "error" "No valid tag found"
        log_error "$package_name" "$tags" "tag-resolution" "No valid tag found"
        failed_version_count=$((failed_version_count + 1))
        package_had_failure=1
        ver_index=$((ver_index + 1))
        continue
      fi
      
      local source_image="ghcr.io/${SOURCE_ORG,,}/$package_name:$primary_tag"
      local target_image="ghcr.io/${TARGET_ORG,,}/$package_name:$primary_tag"
      
      echo "    Source: $source_image"
      echo "    Target: $target_image"
      
      if copy_container_image "$source_image" "$target_image"; then
        echo "    ✓ Successfully migrated"
        write_csv_row "$package_name" "$primary_tag" "migrate" "success" "Migrated successfully"
        success_version_count=$((success_version_count + 1))
        package_had_success=1
        
        # Link package to repository on first successful migration
        if [ $repo_linked -eq 0 ] && [ -n "$source_repository" ]; then
          if link_package_to_repository "$package_name" "$source_repository"; then
            repo_linked=1
          fi
        fi
        
        # Migrate additional tags if present
        local tag_array
        tag_array=$(echo "$version_data" | jq -r '.tags[]')
        local first_tag=1
        while IFS= read -r tag; do
          if [ $first_tag -eq 1 ]; then
            first_tag=0
            continue
          fi
          
          local additional_target="ghcr.io/${TARGET_ORG,,}/$package_name:$tag"
          echo "    Tagging additional: $tag"
          
          if [ "$CONTAINER_TOOL" = "skopeo" ]; then
            local target_token
            target_token=$(get_current_token "target")
            skopeo copy \
              --src-creds="token:${target_token}" \
              --dest-creds="token:${target_token}" \
              "docker://${target_image}" \
              "docker://${additional_target}" 2>&1 || true
          elif [ "$CONTAINER_TOOL" = "docker" ]; then
            docker pull "$target_image" 2>/dev/null || true
            docker tag "$target_image" "$additional_target" 2>/dev/null || true
            docker push "$additional_target" 2>/dev/null || true
            docker rmi "$additional_target" 2>/dev/null || true
          fi
        done <<< "$tag_array"
        
      else
        echo "    ✗ Failed to migrate"
        write_csv_row "$package_name" "$primary_tag" "migrate" "failed" "Copy operation failed"
        log_error "$package_name" "$primary_tag" "copy" "Failed to copy container image"
        echo "$package_name:$primary_tag" >> "$FAILED_PACKAGES_FILE"
        failed_version_count=$((failed_version_count + 1))
        package_had_failure=1
      fi
      
      ver_index=$((ver_index + 1))
    done

    if [ $package_had_success -eq 1 ]; then
      success_package_count=$((success_package_count + 1))
    fi
    if [ $package_had_failure -eq 1 ]; then
      failed_package_count=$((failed_package_count + 1))
    fi
    
    echo ""
  done <<< "$package_names"

  echo "=========================================="
  echo "Migration Complete"
  echo "=========================================="
  echo "Packages discovered in source: $total_packages"
  echo "Packages iterated: $pkg_count"
  echo "Packages selected for migration: $selected_pkg_count"
  echo "Packages skipped by filter: $skipped_pkg_count"
  echo "Packages with >=1 successful version migration: $success_package_count"
  echo "Packages with >=1 failed migration/error: $failed_package_count"
  echo ""
  echo "Successful version migrations: $success_version_count"
  echo "Failed version migrations/errors: $failed_version_count"
  echo "Skipped versions: $skipped_version_count"
  echo ""
  echo "Reports saved to:"
  echo "  - CSV: $CSV_FILE"
  echo "  - Errors: $ERROR_LOG"
  echo "  - Failed: $FAILED_PACKAGES_FILE"
  echo "=========================================="
}

# Run main function
main
