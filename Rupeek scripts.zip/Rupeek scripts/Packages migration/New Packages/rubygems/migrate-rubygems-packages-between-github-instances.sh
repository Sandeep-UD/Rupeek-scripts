#!/bin/bash

# Usage: ./migrate-rubygems-packages-between-github-instances.sh [source-host] [target-host] [cutoff-date] | tee output.log
#
# Prereqs:
# 1. gh cli installed
# 2. Create a .env file with:
#    SOURCE_HOST=github.com   (optional, defaults to github.com)
#    TARGET_HOST=github.com   (optional, defaults to github.com)
#    GH_SOURCE_PAT=ghp_abc    (must have at least read:packages, read:org)
#    GH_TARGET_PAT=ghp_xyz    (must have at least write:packages, read:org)
#    SOURCE_OWNER=source-owner (or SOURCE_ORG for backward compatibility)
#    TARGET_OWNER=target-owner (or TARGET_ORG for backward compatibility)
#    SOURCE_GH_USERNAME=octocat   (optional, defaults to x-access-token)
#    TARGET_GH_USERNAME=octocat   (optional, defaults to x-access-token)
#
# Notes:
# - Downloads .gem artifacts from source registry and pushes them to target registry.
# - See ./failed-packages-rubygems.txt for package versions that failed critical steps.

set -euo pipefail

MAX_RETRIES=${MAX_RETRIES:-5}
RETRY_BASE_SECONDS=${RETRY_BASE_SECONDS:-2}
MAX_VERSIONS_PER_PACKAGE=${MAX_VERSIONS_PER_PACKAGE:-10}

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="$SCRIPT_DIR/.env"

if [ -f "$ENV_FILE" ]; then
  sanitized_env_file=$(mktemp)
  # Normalize CRLF to LF so Bash can source .env files created on Windows.
  sed 's/\r$//' "$ENV_FILE" > "$sanitized_env_file"
  set -o allexport
  # shellcheck source=.env
  source "$sanitized_env_file"
  set +o allexport
  rm -f "$sanitized_env_file"
else
  echo "Error: .env file not found at $ENV_FILE. Create one based on README examples"
  exit 1
fi

SOURCE_OWNER=${SOURCE_OWNER:-${SOURCE_ORG:-}}
TARGET_OWNER=${TARGET_OWNER:-${TARGET_ORG:-}}

if [ -z "${SOURCE_OWNER:-}" ]; then
  echo "Error: SOURCE_OWNER (or SOURCE_ORG) is not set in .env"
  exit 1
fi

if [ -z "${TARGET_OWNER:-}" ]; then
  echo "Error: TARGET_OWNER (or TARGET_ORG) is not set in .env"
  exit 1
fi

SOURCE_HOST=${SOURCE_HOST:-github.com}
TARGET_HOST=${TARGET_HOST:-github.com}

SOURCE_GH_USERNAME=${SOURCE_GH_USERNAME:-x-access-token}
TARGET_GH_USERNAME=${TARGET_GH_USERNAME:-x-access-token}
REWRITE_GITHUB_OWNER_LINKS=${REWRITE_GITHUB_OWNER_LINKS:-true}

ROOT_DIR="$SCRIPT_DIR"
CSV_FILE="$ROOT_DIR/migration-report-rubygems.csv"
ERROR_LOG="$ROOT_DIR/migration-errors-rubygems.log"
FAILED_PACKAGES_FILE="$ROOT_DIR/failed-packages-rubygems.txt"
PACKAGES_CSV="$SCRIPT_DIR/packages.csv"
RUN_FAILED=0

if ! [[ "$MAX_VERSIONS_PER_PACKAGE" =~ ^[0-9]+$ ]]; then
  echo "Error: MAX_VERSIONS_PER_PACKAGE must be a non-negative integer"
  exit 1
fi

mark_failed() {
  RUN_FAILED=1
}

log_info() {
  printf '%s\n' "$1"
}

split_tokens() {
  local input="$1"
  local -n out_array=$2
  local token

  out_array=()
  IFS=',' read -r -a raw_tokens <<<"$input"
  for token in "${raw_tokens[@]}"; do
    token="${token#${token%%[![:space:]]*}}"
    token="${token%${token##*[![:space:]]}}"
    if [ -n "$token" ]; then
      out_array+=("$token")
    fi
  done
}

SOURCE_TOKENS=()
TARGET_TOKENS=()

if [ -n "${GH_SOURCE_PATS:-}" ]; then
  split_tokens "$GH_SOURCE_PATS" SOURCE_TOKENS
elif [ -n "${GH_SOURCE_PAT:-}" ]; then
  SOURCE_TOKENS=("$GH_SOURCE_PAT")
fi

if [ -n "${GH_TARGET_PATS:-}" ]; then
  split_tokens "$GH_TARGET_PATS" TARGET_TOKENS
elif [ -n "${GH_TARGET_PAT:-}" ]; then
  TARGET_TOKENS=("$GH_TARGET_PAT")
fi

if [ ${#SOURCE_TOKENS[@]} -eq 0 ]; then
  echo "Error: GH_SOURCE_PAT or GH_SOURCE_PATS is required in .env"
  exit 1
fi

if [ ${#TARGET_TOKENS[@]} -eq 0 ]; then
  echo "Error: GH_TARGET_PAT or GH_TARGET_PATS is required in .env"
  exit 1
fi

SOURCE_TOKEN_INDEX=0
TARGET_TOKEN_INDEX=0

get_current_token() {
  local role="$1"
  if [ "$role" = "source" ]; then
    echo "${SOURCE_TOKENS[$SOURCE_TOKEN_INDEX]}"
  else
    echo "${TARGET_TOKENS[$TARGET_TOKEN_INDEX]}"
  fi
}

rotate_token() {
  local role="$1"
  if [ "$role" = "source" ]; then
    SOURCE_TOKEN_INDEX=$(( (SOURCE_TOKEN_INDEX + 1) % ${#SOURCE_TOKENS[@]} ))
    echo "Rotated source token to index $SOURCE_TOKEN_INDEX"
  else
    TARGET_TOKEN_INDEX=$(( (TARGET_TOKEN_INDEX + 1) % ${#TARGET_TOKENS[@]} ))
    echo "Rotated target token to index $TARGET_TOKEN_INDEX"
  fi
}

is_rate_limit_error() {
  local error_text="$1"
  echo "$error_text" | grep -Eqi 'rate limit|secondary rate|HTTP 429|status code: 429|too many requests'
}

is_transient_error() {
  local error_text="$1"
  echo "$error_text" | grep -Eqi 'timeout|timed out|temporar|connection reset|502|503|504'
}

sleep_with_backoff() {
  local attempt="$1"
  local seconds=$(( RETRY_BASE_SECONDS * attempt ))
  echo "Retrying in ${seconds}s..."
  sleep "$seconds"
}

log_error() {
  local package_name="$1"
  local version="$2"
  local stage="$3"
  local message="$4"
  mark_failed
  printf '%s\t%s\t%s\t%s\t%s\n' "$(date -u +"%Y-%m-%dT%H:%M:%SZ")" "$package_name" "$version" "$stage" "$message" >>"$ERROR_LOG"
}

csv_escape() {
  local s="$1"
  s="${s//\"/\"\"}"
  printf '"%s"' "$s"
}

PACKAGE_FILTER_ENABLED=0
PACKAGE_FILTER_RAW=""

load_package_filter() {
  if [ -f "$PACKAGES_CSV" ]; then
    log_info "Found packages.csv - migrating listed packages only."
    PACKAGE_FILTER_RAW=$(grep -v -E '^[[:space:]]*(#|package)' "$PACKAGES_CSV" | grep -v -E '^[[:space:]]*$' | tr -d '\r' || true)

    if [ -z "$PACKAGE_FILTER_RAW" ]; then
      log_info "packages.csv has no package rows - migrating all packages from source owner."
      PACKAGE_FILTER_ENABLED=0
    else
      PACKAGE_FILTER_ENABLED=1
    fi
  else
    log_info "packages.csv not found - migrating all packages from source owner."
    PACKAGE_FILTER_ENABLED=0
  fi
}

package_in_filter() {
  local candidate="$1"
  local pkg
  while IFS= read -r pkg; do
    [ -z "$pkg" ] && continue
    if [ "$pkg" = "$candidate" ]; then
      return 0
    fi
  done <<< "$PACKAGE_FILTER_RAW"
  return 1
}

write_csv_row() {
  local package_name="$1"
  local version="$2"
  local action="$3"
  local status="$4"
  local message="$5"
  printf '%s,%s,%s,%s,%s,%s\n' \
    "$(csv_escape "$(date -u +"%Y-%m-%dT%H:%M:%SZ")")" \
    "$(csv_escape "$package_name")" \
    "$(csv_escape "$version")" \
    "$(csv_escape "$action")" \
    "$(csv_escape "$status")" \
    "$(csv_escape "$message")" >>"$CSV_FILE"
}

gh_api_call() {
  local role="$1"
  local host="$2"
  local endpoint="$3"
  local paginate="$4"

  local attempt token output err_file
  for attempt in $(seq 1 "$MAX_RETRIES"); do
    token=$(get_current_token "$role")
    err_file=$(mktemp)

    if [ "$paginate" = "true" ]; then
      if output=$(GH_HOST="$host" GH_TOKEN="$token" "$GH_CMD" api --paginate "$endpoint" 2>"$err_file"); then
        rm -f "$err_file"
        echo "$output"
        return 0
      fi
    else
      if output=$(GH_HOST="$host" GH_TOKEN="$token" "$GH_CMD" api "$endpoint" 2>"$err_file"); then
        rm -f "$err_file"
        echo "$output"
        return 0
      fi
    fi

    local err_text
    err_text=$(cat "$err_file")
    rm -f "$err_file"

    if is_rate_limit_error "$err_text"; then
      echo "Rate limit hit for ${role} token on endpoint: $endpoint"
      rotate_token "$role"
      sleep_with_backoff "$attempt"
      continue
    fi

    if is_transient_error "$err_text"; then
      echo "Transient API error on endpoint: $endpoint"
      sleep_with_backoff "$attempt"
      continue
    fi

    echo "$err_text" >&2
    return 1
  done

  return 1
}

download_gem_with_retry() {
  local package_name="$1"
  local version="$2"
  local output_file="$3"

  local attempt token status url
  local gem_file="${package_name}-${version}.gem"
  url="https://rubygems.pkg.$SOURCE_HOST/$SOURCE_OWNER/gems/$gem_file"

  for attempt in $(seq 1 "$MAX_RETRIES"); do
    token=$(get_current_token "source")
    status=$("$CURL_CMD" -sS -L -u "$SOURCE_GH_USERNAME:$token" -o "$output_file" -w "%{http_code}" "$url" || true)

    if [ "$status" = "200" ]; then
      return 0
    fi

    if [ "$status" = "429" ] || [ "$status" = "403" ] || [ "$status" = "502" ] || [ "$status" = "503" ] || [ "$status" = "504" ]; then
      echo "HTTP $status while downloading $gem_file"
      if [ "$status" = "429" ] || [ "$status" = "403" ]; then
        rotate_token "source"
      fi
      sleep_with_backoff "$attempt"
      continue
    fi

    break
  done

  return 1
}

gem_push_with_retry() {
  local gem_file="$1"
  local attempt token output

  for attempt in $(seq 1 "$MAX_RETRIES"); do
    token=$(get_current_token "target")
    output=$(GEM_HOST_API_KEY="$token" "$GEM_CMD" push "$gem_file" --host "https://rubygems.pkg.$TARGET_HOST/$TARGET_OWNER" 2>&1) && return 0

    echo "$output"
    if is_rate_limit_error "$output" || is_transient_error "$output" || echo "$output" | grep -Eqi '429|403|401|too many requests|timed out'; then
      rotate_token "target"
      sleep_with_backoff "$attempt"
      continue
    fi

    return 1
  done

  return 1
}

rewrite_gem_links_for_target_owner() {
  local input_gem="$1"
  local output_gem="$2"
  local package_name="$3"
  local version="$4"

  local rewrite_root unpack_dir spec_file spec_name built_gem
  local build_output

  rewrite_root="$temp_dir/rewrite-${package_name//\//_}-${version}"
  rm -rf "$rewrite_root"
  mkdir -p "$rewrite_root"

  if ! "$GEM_CMD" unpack "$input_gem" --target "$rewrite_root" >/dev/null 2>&1; then
    return 1
  fi

  unpack_dir=$(find "$rewrite_root" -mindepth 1 -maxdepth 1 -type d | head -n 1)
  if [ -z "$unpack_dir" ]; then
    return 1
  fi

  spec_file=$(find "$unpack_dir" -maxdepth 1 -type f -name '*.gemspec' | head -n 1)
  if [ -z "$spec_file" ]; then
    return 1
  fi

  # Update common GitHub URL patterns and standard metadata fields used by GitHub Packages.
  SRC_OWNER="$SOURCE_OWNER" TGT_OWNER="$TARGET_OWNER" perl -i -pe '
    BEGIN {
      $src = quotemeta($ENV{"SRC_OWNER"});
      $tgt = $ENV{"TGT_OWNER"};
      $src_url = quotemeta("https://github.com/" . $ENV{"SRC_OWNER"});
      $tgt_url = "https://github.com/" . $ENV{"TGT_OWNER"};
    }
    s#https?://github\.com/$src/#https://github.com/$tgt/#g;
    s#git@github\.com:$src/#git@github.com:$tgt/#g;
    s#github\.com/$src/#github.com/$tgt/#g;
    s#"homepage_uri"\s*=>\s*"[^"]*"#"homepage_uri" => "$tgt_url"#g;
    s#"source_code_uri"\s*=>\s*"[^"]*"#"source_code_uri" => "$tgt_url"#g;
    s#"changelog_uri"\s*=>\s*"[^"]*"#"changelog_uri" => "$tgt_url"#g;
    s#"bug_tracker_uri"\s*=>\s*"[^"]*"#"bug_tracker_uri" => "$tgt_url"#g;
    s#homepage\s*=\s*"[^"]*"#homepage = "$tgt_url"#g;
    s#metadata\["homepage_uri"\]\s*=\s*"[^"]*"#metadata["homepage_uri"] = "$tgt_url"#g;
    s#metadata\["source_code_uri"\]\s*=\s*"[^"]*"#metadata["source_code_uri"] = "$tgt_url"#g;
    s#metadata\["changelog_uri"\]\s*=\s*"[^"]*"#metadata["changelog_uri"] = "$tgt_url"#g;
    s#metadata\["bug_tracker_uri"\]\s*=\s*"[^"]*"#metadata["bug_tracker_uri"] = "$tgt_url"#g;
  ' "$spec_file"

  spec_name=$(basename "$spec_file")
  build_output=$(cd "$unpack_dir" && "$GEM_CMD" build "$spec_name" 2>&1) || {
    echo "$build_output"
    return 1
  }

  built_gem=$(find "$unpack_dir" -maxdepth 1 -type f -name '*.gem' | head -n 1)
  if [ -z "$built_gem" ]; then
    return 1
  fi

  cp "$built_gem" "$output_gem"
  return 0
}

resolve_cmd() {
  local cmd="$1"
  if command -v "$cmd" >/dev/null 2>&1; then
    command -v "$cmd"
    return 0
  fi
  if command -v "${cmd}.exe" >/dev/null 2>&1; then
    command -v "${cmd}.exe"
    return 0
  fi
  return 1
}

GH_CMD=$(resolve_cmd gh || true)
JQ_CMD=$(resolve_cmd jq || true)
CURL_CMD=$(resolve_cmd curl || true)
GEM_CMD=$(resolve_cmd gem || true)

if [ -z "$GH_CMD" ]; then
  echo "Error: required command not found: gh (or gh.exe)"
  exit 1
fi
if [ -z "$JQ_CMD" ]; then
  echo "Error: required command not found: jq (or jq.exe)"
  exit 1
fi
if [ -z "$CURL_CMD" ]; then
  echo "Error: required command not found: curl (or curl.exe)"
  exit 1
fi
if [ -z "$GEM_CMD" ]; then
  echo "Error: required command not found: gem (or gem.exe)"
  exit 1
fi

# Optional CLI overrides:
# $1 source host, $2 target host, $3 cutoff date
if [ -n "${1:-}" ]; then
  SOURCE_HOST=$1
fi
if [ -n "${2:-}" ]; then
  TARGET_HOST=$2
fi
CUTOFF_DATE=${3:-}

log_info "Starting RubyGems migration..."
log_info "Source: $SOURCE_HOST/$SOURCE_OWNER"
log_info "Target: $TARGET_HOST/$TARGET_OWNER"
log_info "Max versions/package: $MAX_VERSIONS_PER_PACKAGE"
load_package_filter

mkdir -p "$ROOT_DIR/temp"
cd "$ROOT_DIR/temp"
temp_dir=$(pwd)

printf 'timestamp,package,version,action,status,message\n' >"$CSV_FILE"
printf 'timestamp\tpackage\tversion\tstage\tmessage\n' >"$ERROR_LOG"
: >"$FAILED_PACKAGES_FILE"

owner_scope=""
packages_json=""

# Try org endpoint first, then fall back to user endpoint for account migrations.
if packages_json=$(gh_api_call "source" "$SOURCE_HOST" "orgs/$SOURCE_OWNER/packages?package_type=rubygems" "true" 2>/dev/null | "$JQ_CMD" -cs 'add' 2>/dev/null); then
  owner_scope="orgs"
  log_info "Discovery scope: orgs"
fi

if [ -z "$packages_json" ] || [ "$packages_json" = "null" ]; then
  if packages_json=$(gh_api_call "source" "$SOURCE_HOST" "users/$SOURCE_OWNER/packages?package_type=rubygems" "true" 2>/dev/null | "$JQ_CMD" -cs 'add' 2>/dev/null); then
    owner_scope="users"
    log_info "Discovery scope: users"
  fi
fi

if [ -z "$packages_json" ] || [ "$packages_json" = "null" ]; then
  echo "STATUS: FAILED"
  write_csv_row "$SOURCE_OWNER" "" "package-discovery" "failed" "unable to list packages from orgs/ or users/ endpoints"
  exit 1
fi

if [ "$packages_json" = "[]" ]; then
  msg="no rubygems packages found for source owner"
  log_info "WARN: $msg"
  mark_failed
  write_csv_row "$SOURCE_OWNER" "" "package-discovery" "skipped" "$msg"
fi

while IFS= read -r pkg; do
  package_name=$(echo "$pkg" | "$JQ_CMD" -r '.name')

  if [ "$PACKAGE_FILTER_ENABLED" -eq 1 ] && ! package_in_filter "$package_name"; then
    continue
  fi

  log_info "Processing gem: $package_name"

  versions_endpoint="$owner_scope/$SOURCE_OWNER/packages/rubygems/$package_name/versions"
  if [ -n "$CUTOFF_DATE" ]; then
    versions=$(gh_api_call "source" "$SOURCE_HOST" "$versions_endpoint" "true" | "$JQ_CMD" -cs 'add' |
      "$JQ_CMD" -r --arg cutoff "$CUTOFF_DATE" '.[] | select(.created_at >= $cutoff) | .name' |
      sort -V)
  else
    versions=$(gh_api_call "source" "$SOURCE_HOST" "$versions_endpoint" "true" | "$JQ_CMD" -cs 'add' |
      "$JQ_CMD" -r '.[].name' |
      sort -V)
  fi

  if [ "$MAX_VERSIONS_PER_PACKAGE" -gt 0 ]; then
    versions=$(echo "$versions" | tail -n "$MAX_VERSIONS_PER_PACKAGE")
  fi

  if [ -z "$versions" ]; then
    msg="no versions found after filtering"
    log_info "WARN: $msg for $package_name"
    write_csv_row "$package_name" "" "version-discovery" "skipped" "$msg"
    continue
  fi

  for version in $versions; do
    gem_file="${package_name}-${version}.gem"
    publish_gem_file="$gem_file"
    log_info "Processing version: $package_name@$version"

    if ! download_gem_with_retry "$package_name" "$version" "$gem_file"; then
      msg="failed to download gem"
      echo "ERROR: $msg for $package_name@$version"
      log_error "$package_name" "$version" "download" "$msg"
      write_csv_row "$package_name" "$version" "download" "failed" "$msg"
      echo "skipped package due to download failure: $package_name-$version" >>"$FAILED_PACKAGES_FILE"
      continue
    fi

    if [ "$REWRITE_GITHUB_OWNER_LINKS" = "true" ]; then
      rewritten_gem_file="${package_name}-${version}.rewritten.gem"
      if rewrite_gem_links_for_target_owner "$gem_file" "$rewritten_gem_file" "$package_name" "$version"; then
        publish_gem_file="$rewritten_gem_file"
        log_info "Rewrote GitHub owner links for $package_name@$version"
      else
        log_info "WARN: could not rewrite links for $package_name@$version; publishing original artifact"
      fi
    fi

    if gem_push_with_retry "$publish_gem_file"; then
      log_info "Published: $package_name@$version"
      write_csv_row "$package_name" "$version" "publish" "success" "published"
    else
      msg="gem push failed"
      echo "ERROR: $msg for $package_name@$version"
      log_error "$package_name" "$version" "publish" "$msg"
      write_csv_row "$package_name" "$version" "publish" "failed" "$msg"
      echo "skipped package due to publish failure: $package_name-$version" >>"$FAILED_PACKAGES_FILE"
    fi

    rm -f "$gem_file" "$publish_gem_file"
  done
done < <(echo "$packages_json" | "$JQ_CMD" -c '.[] | {name: .name}')

if [ "$RUN_FAILED" -eq 0 ]; then
  echo "STATUS: SUCCEEDED"
  exit 0
else
  echo "STATUS: FAILED"
  exit 1
fi