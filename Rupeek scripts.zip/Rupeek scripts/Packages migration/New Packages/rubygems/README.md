# RubyGems Package Migration

This folder contains everything needed to migrate GitHub Packages (RubyGems) from one GitHub org/account to another.

Script file:
- `migrate-rubygems-packages-between-github-instances.sh`

## What it does

- Lists RubyGems packages from the source org using paginated GitHub API calls
- Discovers versions per package (with optional cutoff date filtering)
- Downloads `.gem` artifacts from source registry
- Publishes to target registry with retries
- Rotates source/target tokens automatically when rate limits/auth pressure occur
- Writes detailed CSV and error logs

## Prerequisites

- GitHub CLI (`gh`)
- `jq`, `curl`, Ruby `gem` CLI
- Bash shell (Git Bash / WSL on Windows)

## `.env` file

Create `rubygems/.env` from `rubygems/.env.example`.

Required values:

```env
GH_SOURCE_PAT=ghp_source_token_here
GH_TARGET_PAT=ghp_target_token_here
SOURCE_ORG=source-org-name
TARGET_ORG=target-org-name
```

Optional values:

```env
# Comma-separated token rotation pools
# GH_SOURCE_PATS=ghp_source_1,ghp_source_2
# GH_TARGET_PATS=ghp_target_1,ghp_target_2

# Hosts (defaults to github.com)
# SOURCE_HOST=github.com
# TARGET_HOST=github.com

# Retry tuning
# MAX_RETRIES=5
# RETRY_BASE_SECONDS=2

# Maximum versions to migrate per package (latest N; 0 = all)
# MAX_VERSIONS_PER_PACKAGE=10

# RubyGems basic auth usernames (defaults to x-access-token)
# SOURCE_GH_USERNAME=octocat
# TARGET_GH_USERNAME=octocat
```

Optional package filter via `packages.csv` in this folder:

- one package name per line
- optional `package` header
- `#` comments and blank lines are ignored

Example:

```csv
package
my_gem
internal_tools
```

If `packages.csv` is missing or empty, all packages are considered.

Required token scopes:

- `GH_SOURCE_PAT`: `read:packages`, `read:org`
- `GH_TARGET_PAT`: `write:packages`, `read:org`

## Run

From repository root:

```bash
./rubygems/migrate-rubygems-packages-between-github-instances.sh | tee rubygems/output-rubygems.log
```

With host overrides:

```bash
./rubygems/migrate-rubygems-packages-between-github-instances.sh github.com github.com | tee rubygems/output-rubygems.log
```

With cutoff date:

```bash
./rubygems/migrate-rubygems-packages-between-github-instances.sh github.com github.com 2025-01-01T00:00:00Z | tee rubygems/output-rubygems.log
```

## Output files

All output files are written in this `rubygems/` folder:

- `migration-report-rubygems.csv`
- `migration-errors-rubygems.log`
- `failed-packages-rubygems.txt`
- `temp/`

## Updates after migration

After migrating RubyGems packages, update your consumers and delivery pipelines to point to the target organization.

### 1. Repository configuration (`Gemfile`, `.gemspec`, `.gemrc`, Bundler config)

- Update any source URLs that reference the old org/host packages endpoint.
- For private gems hosted on GitHub Packages, ensure the source uses the target org namespace.
- Verify local and CI Bundler settings resolve gems from the target registry.

Example private source pattern:

```ruby
source "https://rubygems.pkg.github.com/TARGET_ORG"
```

### 2. Authentication credentials

- Update credentials used by `gem` and Bundler for the target organization.
- Rotate/remove old source-org tokens where they are no longer needed.
- Confirm target tokens include at least `read:packages` for install and `write:packages` for publish.

Common places to update:

- `~/.gem/credentials`
- `~/.bundle/config`
- environment variables used by scripts (`GH_TARGET_PAT`, `BUNDLE_RUBYGEMS__PKG__GITHUB__COM`, etc.)

### 3. CI/CD pipeline updates

- GitHub Actions: update `GITHUB_TOKEN` permissions and/or PAT-based secrets so workflows can access target org packages.
- Jenkins/other CI: update stored credentials, secret stores, and runtime variables used for RubyGems auth.
- Replace any hardcoded old-org package URLs in pipeline scripts.
- Re-run install/publish jobs to validate end-to-end access to the target org registry.

### 4. Bundler projects (if applicable)

- Run `bundle install` after configuration changes to refresh lockfile resolution against the target source.
- If `Gemfile.lock` pins a source tied to old org URLs, regenerate/refresh it and commit the updated lockfile.
- Validate dependent applications can install private gems from the target org in clean environments.
