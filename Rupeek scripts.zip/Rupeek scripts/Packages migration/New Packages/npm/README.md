# NPM Package Migration Script

A simple script to migrate GitHub Packages (npm) from one GitHub org to another.

Script file:
- `migrate-npm-packages-between-github-instances.sh`

## What it does

- Reads npm packages from a source org
- Downloads package tarballs and republishes them to a target org
- Updates package `repository.url` when matching target repo exists
- Re-applies npm dist-tags (like `latest`, `beta`, etc.)
- Supports multiple source/target tokens with automatic token rotation
- Retries API and npm operations for rate limits and transient failures
- Handles paginated GitHub API responses for package/version discovery
- Writes a CSV migration report and a structured error log


## Prerequisites

- GitHub CLI (`gh`) installed
- `npm`, `jq`, `curl`, `tar`, `perl` available
- Access tokens for source and target with required scopes
- Bash shell (Git Bash / WSL on Windows)

## 1) Create `.env`

Create a `.env` file in this folder:

```env
GH_SOURCE_PAT=ghp_source_token_here
GH_TARGET_PAT=ghp_target_token_here
# Optional multi-token mode (comma-separated):
# GH_SOURCE_PATS=ghp_source_1,ghp_source_2
# GH_TARGET_PATS=ghp_target_1,ghp_target_2
SOURCE_ORG=source-org-name
TARGET_ORG=target-org-name

# Optional: latest N versions/package to migrate (0 = all)
# MAX_VERSIONS_PER_PACKAGE=10

# Optional retry tuning
# MAX_RETRIES=5
# RETRY_BASE_SECONDS=2
```

Required token scopes:

- `GH_SOURCE_PAT`: `read:packages`, `read:org`
- `GH_TARGET_PAT`: `write:packages`, `read:org`

Multi-token notes:

- If `GH_SOURCE_PATS` is set, it is used instead of `GH_SOURCE_PAT`
- If `GH_TARGET_PATS` is set, it is used instead of `GH_TARGET_PAT`
- Tokens should be comma-separated without quotes
- Token rotation occurs automatically when rate-limit or auth-related failures are detected

Retry behavior:

- `MAX_RETRIES` controls attempts per operation (default: `5`)
- `RETRY_BASE_SECONDS` controls linear backoff base (default: `2`)
- Backoff delay is `RETRY_BASE_SECONDS * attempt_number`

Optional package filter via `packages.csv` in this folder:

- one package name per line
- optional `package` header
- `#` comments and blank lines are ignored

Example:

```csv
package
@source-org/pkg-a
unscoped-pkg-b
```

If `packages.csv` is missing or empty, all packages are considered.

## 2) Authenticate (optional but recommended)

```bash
gh auth status
```

If needed, refresh scopes:

```bash
gh auth refresh -h github.com -s read:packages,read:org,write:packages
```

## 3) Run the script

Migrate all versions:

```bash
./migrate-npm-packages-between-github-instances.sh | tee output.log
```

Override source/target host:

```bash
./migrate-npm-packages-between-github-instances.sh github.com github.com | tee output.log
```

Migrate only versions created on/after a date:

```bash
./migrate-npm-packages-between-github-instances.sh github.com github.com 2025-01-01T00:00:00Z | tee output.log
```

## Output files

- `output.log`: full run output (when piped with `tee`)
- `temp/`: temporary working folder created by script
- `migration-report.csv`: per-step migration results (created in repo root)
- `migration-errors.log`: timestamped error log with stage details (created in repo root)
- `failed-packages.txt`: packages/versions that failed critical steps (created in repo root)

CSV columns:

- `timestamp`
- `package`
- `version`
- `action`
- `status`
- `message`

## Cleanup

After migration:

```bash
rm -rf ./temp
```

## Notes

- Repo mapping is best-effort. If no matching target repo exists, package publish can still succeed.
- Test with a small package set first before full migration.
- If you use GitHub Enterprise Server, pass source and target hosts as CLI args.
