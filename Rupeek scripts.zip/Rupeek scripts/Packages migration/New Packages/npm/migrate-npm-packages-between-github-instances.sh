#!/bin/bash

# Usage: ./migrate-npm-packages-between-github-instances.sh [source-host] [target-host] [cutoff-date] | tee output.log
#
#
# Prereqs:
# 1. [gh cli](https://cli.github.com) installed
# 2. Create a .env file (see .env.example) with:
#    SOURCE_HOST=github.com   (optional, defaults to github.com)
#    TARGET_HOST=github.com   (optional, defaults to github.com)
#    GH_SOURCE_PAT=ghp_abc   (must have at least `read:packages`, `read:org` scope)
#    GH_TARGET_PAT=ghp_xyz   (must have at least `write:packages`, `read:org` scope)
#    SOURCE_ORG=joshjohanning-org
#    TARGET_ORG=joshjohanning-emu
#
# Example: ./migrate-npm-packages-between-github-instances.sh github.com github.com | tee output.log
#
# Notes:
# - Mapping the npm package to a repo is optional.
#   - If there is a repo that exists in the target with the same repo name, it will map it
#   - If the repo doesn't exist, the package will still import but won't be mapped to a repo
# - See ./failed-packages.txt for any packages that failed to import

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

MAX_RETRIES=${MAX_RETRIES:-5}
RETRY_BASE_SECONDS=${RETRY_BASE_SECONDS:-2}
MAX_VERSIONS_PER_PACKAGE=${MAX_VERSIONS_PER_PACKAGE:-10}

# Load variables from .env file
if [ -f .env ]; then
  # Export only lines that are valid KEY=VALUE assignments (skip comments and blank lines)
  set -o allexport
  # shellcheck source=.env
  source .env
  set +o allexport
else
  echo "Error: .env file not found. Create one based on .env.example"
  exit 1
fi

if [ -z "$SOURCE_ORG" ]; then
  echo "Error: SOURCE_ORG is not set in .env"
  exit 1
fi

if [ -z "$TARGET_ORG" ]; then
  echo "Error: TARGET_ORG is not set in .env"
  exit 1
fi

echo "..."

SOURCE_HOST=${SOURCE_HOST:-github.com}
TARGET_HOST=${TARGET_HOST:-github.com}

if ! [[ "$MAX_VERSIONS_PER_PACKAGE" =~ ^[0-9]+$ ]]; then
  echo "Error: MAX_VERSIONS_PER_PACKAGE must be a non-negative integer"
  exit 1
fi

ROOT_DIR=$(pwd)
CSV_FILE="$ROOT_DIR/migration-report.csv"
ERROR_LOG="$ROOT_DIR/migration-errors.log"
FAILED_PACKAGES_FILE="$ROOT_DIR/failed-packages.txt"
PACKAGES_CSV="$SCRIPT_DIR/packages.csv"

PACKAGE_FILTER_ENABLED=0
PACKAGE_FILTER_RAW=""

load_package_filter() {
  if [ -f "$PACKAGES_CSV" ]; then
    echo "Found packages.csv - migrating listed packages only."
    PACKAGE_FILTER_RAW=$(grep -v -E '^[[:space:]]*(#|package)' "$PACKAGES_CSV" | grep -v -E '^[[:space:]]*$' | tr -d '\r' || true)

    if [ -z "$PACKAGE_FILTER_RAW" ]; then
      echo "packages.csv has no package rows - migrating all packages from source org."
      PACKAGE_FILTER_ENABLED=0
    else
      PACKAGE_FILTER_ENABLED=1
    fi
  else
    echo "packages.csv not found - migrating all packages from source org."
    PACKAGE_FILTER_ENABLED=0
  fi
}

package_in_filter() {
  local candidate="$1"
  local pkg
  while IFS= read -r pkg; do
    [ -z "$pkg" ] && continue
    if [ "$pkg" = "$candidate" ]; then
      return 0
    fi
  done <<< "$PACKAGE_FILTER_RAW"
  return 1
}

split_tokens() {
  local input="$1"
  local -n out_array=$2
  local token

  out_array=()
  IFS=',' read -r -a raw_tokens <<<"$input"
  for token in "${raw_tokens[@]}"; do
    token="${token#${token%%[![:space:]]*}}"
    token="${token%${token##*[![:space:]]}}"
    if [ -n "$token" ]; then
      out_array+=("$token")
    fi
  done
}

SOURCE_TOKENS=()
TARGET_TOKENS=()

if [ -n "${GH_SOURCE_PATS:-}" ]; then
  split_tokens "$GH_SOURCE_PATS" SOURCE_TOKENS
elif [ -n "${GH_SOURCE_PAT:-}" ]; then
  SOURCE_TOKENS=("$GH_SOURCE_PAT")
fi

if [ -n "${GH_TARGET_PATS:-}" ]; then
  split_tokens "$GH_TARGET_PATS" TARGET_TOKENS
elif [ -n "${GH_TARGET_PAT:-}" ]; then
  TARGET_TOKENS=("$GH_TARGET_PAT")
fi

if [ ${#SOURCE_TOKENS[@]} -eq 0 ]; then
  echo "Error: GH_SOURCE_PAT or GH_SOURCE_PATS is required in .env"
  exit 1
fi

if [ ${#TARGET_TOKENS[@]} -eq 0 ]; then
  echo "Error: GH_TARGET_PAT or GH_TARGET_PATS is required in .env"
  exit 1
fi

SOURCE_TOKEN_INDEX=0
TARGET_TOKEN_INDEX=0

get_current_token() {
  local role="$1"
  if [ "$role" = "source" ]; then
    echo "${SOURCE_TOKENS[$SOURCE_TOKEN_INDEX]}"
  else
    echo "${TARGET_TOKENS[$TARGET_TOKEN_INDEX]}"
  fi
}

rotate_token() {
  local role="$1"
  if [ "$role" = "source" ]; then
    SOURCE_TOKEN_INDEX=$(( (SOURCE_TOKEN_INDEX + 1) % ${#SOURCE_TOKENS[@]} ))
    echo "Rotated source token to index $SOURCE_TOKEN_INDEX"
  else
    TARGET_TOKEN_INDEX=$(( (TARGET_TOKEN_INDEX + 1) % ${#TARGET_TOKENS[@]} ))
    echo "Rotated target token to index $TARGET_TOKEN_INDEX"
  fi
}

is_rate_limit_error() {
  local error_text="$1"
  echo "$error_text" | grep -Eqi 'rate limit|secondary rate|HTTP 429|status code: 429|too many requests'
}

is_transient_error() {
  local error_text="$1"
  echo "$error_text" | grep -Eqi 'timeout|timed out|temporar|connection reset|502|503|504'
}

sleep_with_backoff() {
  local attempt="$1"
  local seconds=$(( RETRY_BASE_SECONDS * attempt ))
  echo "Retrying in ${seconds}s..."
  sleep "$seconds"
}

log_error() {
  local package_name="$1"
  local version="$2"
  local stage="$3"
  local message="$4"
  printf '%s\t%s\t%s\t%s\t%s\n' "$(date -u +"%Y-%m-%dT%H:%M:%SZ")" "$package_name" "$version" "$stage" "$message" >>"$ERROR_LOG"
}

csv_escape() {
  local s="$1"
  s="${s//\"/\"\"}"
  printf '"%s"' "$s"
}

write_csv_row() {
  local package_name="$1"
  local version="$2"
  local action="$3"
  local status="$4"
  local message="$5"
  printf '%s,%s,%s,%s,%s,%s\n' \
    "$(csv_escape "$(date -u +"%Y-%m-%dT%H:%M:%SZ")")" \
    "$(csv_escape "$package_name")" \
    "$(csv_escape "$version")" \
    "$(csv_escape "$action")" \
    "$(csv_escape "$status")" \
    "$(csv_escape "$message")" >>"$CSV_FILE"
}

gh_api_call() {
  local role="$1"
  local host="$2"
  local endpoint="$3"
  local paginate="$4"

  local attempt token output err_file
  for attempt in $(seq 1 "$MAX_RETRIES"); do
    token=$(get_current_token "$role")
    err_file=$(mktemp)

    if [ "$paginate" = "true" ]; then
      if output=$(GH_HOST="$host" GH_TOKEN="$token" gh api --paginate "$endpoint" 2>"$err_file"); then
        rm -f "$err_file"
        echo "$output"
        return 0
      fi
    else
      if output=$(GH_HOST="$host" GH_TOKEN="$token" gh api "$endpoint" 2>"$err_file"); then
        rm -f "$err_file"
        echo "$output"
        return 0
      fi
    fi

    local err_text
    err_text=$(cat "$err_file")
    rm -f "$err_file"

    if is_rate_limit_error "$err_text"; then
      echo "Rate limit hit for ${role} token on endpoint: $endpoint"
      rotate_token "$role"
      sleep_with_backoff "$attempt"
      continue
    fi

    if is_transient_error "$err_text"; then
      echo "Transient API error on endpoint: $endpoint"
      sleep_with_backoff "$attempt"
      continue
    fi

    echo "$err_text" >&2
    return 1
  done

  return 1
}

curl_download_with_retry() {
  local role="$1"
  local url="$2"
  local output_file="$3"

  local attempt token status
  for attempt in $(seq 1 "$MAX_RETRIES"); do
    token=$(get_current_token "$role")
    status=$(curl -sS -L -H "Authorization: token $token" -o "$output_file" -w "%{http_code}" "$url" || true)

    if [ "$status" = "200" ]; then
      return 0
    fi

    if [ "$status" = "429" ] || [ "$status" = "403" ] || [ "$status" = "502" ] || [ "$status" = "503" ] || [ "$status" = "504" ]; then
      echo "HTTP $status for $url"
      if [ "$status" = "429" ] || [ "$status" = "403" ]; then
        rotate_token "$role"
      fi
      sleep_with_backoff "$attempt"
      continue
    fi

    break
  done

  return 1
}

write_npmrc_with_token() {
  local token="$1"
  {
    echo "@$TARGET_ORG:registry=https://npm.pkg.$TARGET_HOST/"
    echo "//npm.pkg.$TARGET_HOST/:_authToken=$token"
  } >"$temp_dir/.npmrc"
}

npm_publish_with_retry() {
  local package_tgz="$1"
  local attempt token output

  for attempt in $(seq 1 "$MAX_RETRIES"); do
    token=$(get_current_token "target")
    write_npmrc_with_token "$token"
    output=$(npm publish --ignore-scripts --userconfig "$temp_dir/.npmrc" 2>&1) && return 0

    echo "$output"
    if is_rate_limit_error "$output" || is_transient_error "$output" || echo "$output" | grep -Eqi 'E401|E403|E429'; then
      rotate_token "target"
      sleep_with_backoff "$attempt"
      continue
    fi

    return 1
  done

  echo "Failed publish after retries for $package_tgz" >&2
  return 1
}

download_package_manifest() {
  local package_name="$1"
  local manifest_file="$2"
  local manifest_url
  local -a manifest_urls=()

  # GitHub npm package names from the API can be scoped or unscoped depending on source metadata.
  # Try both URL forms for unscoped names so tarball metadata and version lists stay consistent.
  if [[ "$package_name" == @*/* ]]; then
    manifest_urls+=("https://npm.pkg.$SOURCE_HOST/$package_name")
  else
    manifest_urls+=("https://npm.pkg.$SOURCE_HOST/$package_name")
    manifest_urls+=("https://npm.pkg.$SOURCE_HOST/@$SOURCE_ORG/$package_name")
  fi

  for manifest_url in "${manifest_urls[@]}"; do
    if curl_download_with_retry "source" "$manifest_url" "$manifest_file"; then
      echo "$manifest_url"
      return 0
    fi
  done

  return 1
}

manifest_tarball_url_for_version() {
  local manifest_file="$1"
  local version="$2"
  local clean_version

  clean_version=$(printf '%s' "$version" | tr -d '\r' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')

  # Normal npm manifests use semver keys, but some registries can return
  # non-standard keys. Fall back to searching by nested .version value.
  jq -r --arg version "$clean_version" '
    (.versions[$version].dist.tarball)
    // (
      .versions
      | to_entries
      | map(select(.value.version == $version))
      | .[0].value.dist.tarball
    )
    // empty
  ' "$manifest_file"
}

target_package_ref() {
  local package_name="$1"

  if [[ "$package_name" == @*/* ]]; then
    echo "$package_name" | sed "s#^@[^/]\+/#@$TARGET_ORG/#"
  else
    echo "@$TARGET_ORG/$package_name"
  fi
}

npm_dist_tag_add_with_retry() {
  local package_with_version="$1"
  local dist_tag="$2"
  local attempt token output

  for attempt in $(seq 1 "$MAX_RETRIES"); do
    token=$(get_current_token "target")
    write_npmrc_with_token "$token"
    output=$(npm dist-tag add "$package_with_version" "$dist_tag" --userconfig "$temp_dir/.npmrc" 2>&1) && return 0

    echo "$output"
    if is_rate_limit_error "$output" || is_transient_error "$output" || echo "$output" | grep -Eqi 'E401|E403|E429'; then
      rotate_token "target"
      sleep_with_backoff "$attempt"
      continue
    fi

    return 1
  done

  return 1
}

# Optional CLI overrides:
# $1 source host, $2 target host, $3 cutoff date
if [ -n "${1:-}" ]; then
  SOURCE_HOST=$1
fi
if [ -n "${2:-}" ]; then
  TARGET_HOST=$2
fi
# Optional: Set CUTOFF_DATE to migrate only package versions created on or after this date.
# Format: YYYY-MM-DDTHH:MM:SSZ (e.g., 2023-03-13T00:00:00Z)
# Example: To migrate versions from the past year, use: $(date -u -v-1y +"%Y-%m-%dT%H:%M:%SZ")
# If CUTOFF_DATE is unset or empty, all available versions will be migrated.
CUTOFF_DATE=${3:-}

echo "Source host: $SOURCE_HOST"
echo "Target host: $TARGET_HOST"
echo "Source org: $SOURCE_ORG"
echo "Target org: $TARGET_ORG"
echo "Max versions/package: $MAX_VERSIONS_PER_PACKAGE"

load_package_filter

# create temp dir
mkdir -p ./temp
cd ./temp
temp_dir=$(pwd)

printf 'timestamp,package,version,action,status,message\n' >"$CSV_FILE"
printf 'timestamp\tpackage\tversion\tstage\tmessage\n' >"$ERROR_LOG"
: >"$FAILED_PACKAGES_FILE"

packages_json=$(gh_api_call "source" "$SOURCE_HOST" "orgs/$SOURCE_ORG/packages?package_type=npm" "true" | jq -cs 'add') || {
  echo "ERROR: unable to list source npm packages"
  exit 1
}

echo "$packages_json" | jq -c '.[] | {name: .name, repo_name: (.repository.name // "")}' | while IFS= read -r pkg; do

  package_name=$(echo "$pkg" | jq -r '.name')

  if [ "$PACKAGE_FILTER_ENABLED" -eq 1 ] && ! package_in_filter "$package_name"; then
    continue
  fi

  repo_name=$(echo "$pkg" | jq -r '.repo_name')
  safe_package_name=$(echo "$package_name" | tr '/@' '__')
  manifest_file="${temp_dir}/${safe_package_name}.json"
  
  # If no repo from source API, try to infer from package name (remove @org/ prefix)
  if [ -z "$repo_name" ] || [ "$repo_name" == "null" ]; then
    # Extract repo name from package name by removing org prefix and converting to kebab-case
    inferred_repo_name=$(echo "$package_name" | sed "s/@$SOURCE_ORG\///g" | tr '_' '-')
    repo_name="$inferred_repo_name"
    echo "No source repo linked. Attempting to link with inferred name: $repo_name"
  fi

  echo "org: $SOURCE_ORG repo: $repo_name --> package name $package_name"

  # Cache package metadata to avoid multiple API calls for each version
  if ! manifest_url_used=$(download_package_manifest "$package_name" "$manifest_file"); then
    msg="failed to fetch package manifest"
    echo "ERROR: $msg for $package_name"
    log_error "$package_name" "" "manifest" "$msg"
    write_csv_row "$package_name" "" "manifest" "failed" "$msg"
    echo "skipped package due to manifest failure: $package_name" >>"$FAILED_PACKAGES_FILE"
    continue
  fi
  echo "Fetched manifest from: $manifest_url_used"

  # Fetch versions, filter by date only if CUTOFF_DATE is set
  versions_endpoint="orgs/$SOURCE_ORG/packages/npm/$package_name/versions"
  if [ -n "$CUTOFF_DATE" ]; then
    versions=$(gh_api_call "source" "$SOURCE_HOST" "$versions_endpoint" "true" | jq -cs 'add' |
      jq -r --arg cutoff "$CUTOFF_DATE" '.[] | select(.created_at >= $cutoff) | .name' |
      tr -d '\r' |
      sed '/^[[:space:]]*$/d' |
      sort -V)
  else
    versions=$(gh_api_call "source" "$SOURCE_HOST" "$versions_endpoint" "true" | jq -cs 'add' |
      jq -r '.[].name' |
      tr -d '\r' |
      sed '/^[[:space:]]*$/d' |
      sort -V)
  fi

  if [ "$MAX_VERSIONS_PER_PACKAGE" -gt 0 ]; then
    versions=$(echo "$versions" | tail -n "$MAX_VERSIONS_PER_PACKAGE")
  fi

  if [ -z "$versions" ]; then
    msg="no versions found after filtering"
    echo "WARN: $msg for $package_name"
    write_csv_row "$package_name" "" "version-discovery" "skipped" "$msg"
    continue
  fi

  while IFS= read -r version; do
    [ -z "$version" ] && continue
    echo "$version"

    # get url of tarball
    url=$(manifest_tarball_url_for_version "$manifest_file" "$version")

    # check for error
    if [ -z "$url" ]; then
      msg="version not found in manifest"
      echo "ERROR: $msg for package $package_name version $version"
      log_error "$package_name" "$version" "tarball-url" "$msg"
      write_csv_row "$package_name" "$version" "tarball-url" "failed" "$msg"
      continue
    fi

    # download
    tarball_file="$package_name-$version.tgz"
    if ! curl_download_with_retry "source" "$url" "$tarball_file"; then
      msg="failed to download tarball"
      echo "ERROR: $msg for $package_name@$version"
      log_error "$package_name" "$version" "download" "$msg"
      write_csv_row "$package_name" "$version" "download" "failed" "$msg"
      echo "skipped package due to download failure: $package_name-$version" >>"$FAILED_PACKAGES_FILE"
      continue
    fi

    # untar
    mkdir -p ./$package_name-$version
    # if you run into permissions issue, add a `sudo` here
    if ! tar xzf "$tarball_file" -C "$package_name-$version"; then
      msg="failed to extract tarball"
      echo "ERROR: $msg for $package_name@$version"
      log_error "$package_name" "$version" "untar" "$msg"
      write_csv_row "$package_name" "$version" "untar" "failed" "$msg"
      echo "skipped package due to untar failure: $package_name-$version" >>"$FAILED_PACKAGES_FILE"
      continue
    fi

    cd $package_name-$version/package
    perl -pi -e "s/$SOURCE_ORG/$TARGET_ORG/ig" package.json
    
    # Remove prepare script to prevent build errors during publish
    # (the package is already built, no need to rebuild)
    jq 'if .scripts then .scripts |= del(.prepare) else . end' package.json > package.json.tmp && mv package.json.tmp package.json
    
    # Set repository URL in package.json if repo exists in target org
    if [ -n "$repo_name" ] && [ "$repo_name" != "null" ]; then
      repo_endpoint="repos/$TARGET_ORG/$repo_name"
      repo_check=$(gh_api_call "target" "$TARGET_HOST" "$repo_endpoint" "false" 2>/dev/null || echo "")
      if [ -n "$repo_check" ]; then
        # Update package.json with correct repository URL (GitHub will auto-link on publish)

repo_url="https://$TARGET_HOST/$TARGET_ORG/$repo_name"

repo_type=$(jq -r '
  if has("repository") then
    (.repository | type)
  else
    "missing"
  end
' package.json)

echo "repository field type: $repo_type"

jq --arg repo "$repo_url" '
if (.repository | type) == "object" then
  .repository.url = $repo
elif (.repository | type) == "string" then
  .repository = {
    "type": "git",
    "url": $repo
  }
else
  .repository = {
    "type": "git",
    "url": $repo
  }
end
' package.json > package.json.tmp && mv package.json.tmp package.json

echo "Updated repository URL in package.json to: $repo_url"
      fi
    fi
    
    if npm_publish_with_retry "$tarball_file"; then
      write_csv_row "$package_name" "$version" "publish" "success" "published"
    else
      msg="npm publish failed"
      echo "ERROR: $msg for $package_name@$version"
      log_error "$package_name" "$version" "publish" "$msg"
      write_csv_row "$package_name" "$version" "publish" "failed" "$msg"
      echo "skipped package due to failure: $package_name-$version" >>"$FAILED_PACKAGES_FILE"
    fi

    cd ./../../

  done <<<"$versions"

  # Mark the latest tag as latest in GitHub's UI, otherwise latest version will be last semver version pushed
  MANIFEST="$manifest_file"
  PACKAGE=$(target_package_ref "$package_name")
  DIST_TAGS=$(jq -r '.["dist-tags"] | keys[]?' "$MANIFEST")
  for DIST_TAG in $DIST_TAGS; do
    # get the version for the current tag
    version=$(jq --arg TAG "$DIST_TAG" -r '.["dist-tags"].[$TAG]' "$MANIFEST")
    echo "Setting dist-tag $DIST_TAG to version $version for package $PACKAGE"
    # set the dist-tag using npm CLI
    if npm_dist_tag_add_with_retry "$PACKAGE@$version" "$DIST_TAG"; then
      write_csv_row "$package_name" "$version" "dist-tag:$DIST_TAG" "success" "dist-tag applied"
    else
      msg="failed to set dist-tag $DIST_TAG"
      echo "ERROR: $msg for $PACKAGE@$version"
      log_error "$package_name" "$version" "dist-tag" "$msg"
      write_csv_row "$package_name" "$version" "dist-tag:$DIST_TAG" "failed" "$msg"
    fi
  done

  echo "..."

done

echo "Run this to clean up your working dir: rm -rf ./temp"
echo "CSV report: $CSV_FILE"
echo "Error log: $ERROR_LOG"
echo "Failed packages list: $FAILED_PACKAGES_FILE"

# TODO: Ability to delta sync? might be separate script


# TODO: Concept for parallelization to speed up the process