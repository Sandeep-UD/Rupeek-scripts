# Enhanced Version Selection Feature

## Overview

Your Maven package migration script has been enhanced to support migrating **only specific selected versions** of packages. This gives you fine-grained control over which versions get migrated.

## How It Works

### Three Usage Modes

#### Mode 1: Migrate All Versions (Default)
- **File needed**: None
- **Behavior**: Migrates the latest N versions per package (controlled by `MAX_VERSIONS_PER_PACKAGE`)
- **Best for**: Full migrations of recent versions

#### Mode 2: Migrate Specific Packages Only
- **File needed**: `packages.csv`
- **Behavior**: Migrates all versions of listed packages
- **Best for**: When you have multiple packages but only want some

#### Mode 3: Migrate Specific Package Versions (NEW!)
- **File needed**: `versions.csv`
- **Behavior**: Migrates ONLY the versions listed in this file
- **Best for**: Selective migration, gradual rollouts, or testing

## Using the New Feature: `versions.csv`

### Step 1: Create `versions.csv`

Create a file named `versions.csv` in the same directory as the script with this format:

```csv
package,version
com.mycompany.mydepartment.my-project,1.0.0
com.mycompany.mydepartment.my-project,1.0.1
com.mycompany.mydepartment1.my-project1,1.1.2
com.mycompany.mydepartment1.my-project1,1.2.0
```

### Step 2: Format Guidelines

- **Header line** (optional): `package,version`
- **Comments**: Lines starting with `#` are ignored
- **Blank lines**: Skipped automatically
- **Line endings**: Windows/Unix line endings both supported
- **Package name**: Exact Maven package name (e.g., `com.example.mylib`)
- **Version**: Exact version string (e.g., `1.0.0`, `2.1.0-SNAPSHOT`)

### Step 3: Run the Script

```bash
./migrate-maven-packages-between-orgs.sh
```

The script will:
1. Detect `versions.csv`
2. Load the specified package versions
3. Migrate ONLY those versions
4. Skip any other versions

## Example Scenarios

### Scenario 1: Migrate Specific Versions for Testing
```csv
package,version
com.mycompany.api,1.5.0
com.mycompany.api,1.5.1
com.mycompany.core,2.0.0-SNAPSHOT
```

### Scenario 2: Gradual Rollout
**Batch 1 (day 1):**
```csv
package,version
com.mycompany.common,1.0.0
```

**Batch 2 (day 2):**
```csv
package,version
com.mycompany.common,1.1.0
com.mycompany.common,1.2.0
```

### Scenario 3: Skip Problematic Versions
```csv
package,version
# Skip 1.0.0 due to known issue
com.mycompany.api,1.0.1
com.mycompany.api,1.1.0
# 1.1.1 has vulnerability, skip it
com.mycompany.api,1.2.0
```

## Key Points

✅ **When `versions.csv` exists**: Only specified versions are migrated  
✅ **When `versions.csv` is missing**: Falls back to default behavior (all/limited versions)  
✅ **`MAX_VERSIONS_PER_PACKAGE` is ignored** when using `versions.csv`  
✅ **Combine with `packages.csv`**: Use both files together for maximum control  
✅ **Safe to edit**: Pause the script, edit `versions.csv`, and re-run (won't duplicate completed versions)  

## Migration Report

The generated `migration-report.csv` will show the status of each migrated version:

```csv
package,version,source_repo,target_repo,packaging,status
com.mycompany.mydepartment.my-project,1.0.0,repo1,repo1,jar,SUCCESS
com.mycompany.mydepartment.my-project,1.0.1,repo1,repo1,jar,SUCCESS
com.mycompany.mydepartment1.my-project1,1.1.2,repo2,repo2,war,DEPLOY_FAILED
```

## Troubleshooting

**Q: The script says "No matching versions found"**
- Check the package name matches exactly (case-sensitive)
- Verify the version string is correct
- Ensure the version exists in the source organization

**Q: Can I combine `packages.csv` and `versions.csv`?**
- Yes! Use `packages.csv` to filter packages, then `versions.csv` to filter versions
- Only versions in `versions.csv` will be processed

**Q: What if I make a mistake in `versions.csv`?**
- Stop the script, fix the file, and re-run
- The script won't re-migrate successfully completed versions
- Failed versions can be retried by keeping them in `versions.csv`

**Q: How do I list all available versions?**
- Use: `gh api --paginate "orgs/{SOURCE_ORG}/packages/maven/{PACKAGE_NAME}/versions" | jq -r '.[].name'`
- This shows all versions available for a specific package

## Advanced Usage

### Get All Versions for a Package
```bash
gh api --paginate \
  "orgs/YOUR_SOURCE_ORG/packages/maven/com.mycompany.mylib/versions" \
  | jq -r '.[].name' | sort
```

### Generate `versions.csv` Programmatically
```bash
echo "package,version" > versions.csv
gh api --paginate "orgs/YOUR_SOURCE_ORG/packages?package_type=maven" \
  | jq -r '.[] | select(.name | startswith("com.mycompany")) | .name' \
  | while read pkg; do
    gh api --paginate "orgs/YOUR_SOURCE_ORG/packages/maven/$pkg/versions" \
      | jq -r ".[] | \"$pkg,\" + .name" | head -3
  done >> versions.csv
```

---

**Happy migrating!** 🚀
