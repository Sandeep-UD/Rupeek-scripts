# Maven Package Migration Script

A comprehensive Bash script to migrate Maven packages between GitHub organizations with built-in rate limiting, token rotation, and retry logic.

## Features

- **Multiple Token Support**: Use multiple GitHub tokens with automatic rotation on rate limits
- **Pagination Support**: Automatically handles paginated API responses
- **Rate Limit Management**: Intelligent token rotation when GitHub API rate limits are hit
- **CSV Reporting**: Detailed migration status report for each package version
- **Error Logging**: Captures deployment logs and provides detailed error messages
- **Retry Logic**: Automatic retries for both API calls and Maven deployments
- **SNAPSHOT Resolution**: Properly handles Maven SNAPSHOT versions with timestamp-based resolution
- **Batch Processing**: Migrates all versions of all packages in an organization

## Prerequisites

- Bash 4.0+
- `gh` (GitHub CLI) v2.0+
- `curl`
- `jq`
- `maven` (for deployment)
- GitHub Personal Access Tokens (PATs) with `read:packages` and `write:packages` scopes

## Setup

### 1. Create `.env` file

Create a `.env` file in the same directory as the script with the following variables:

```bash
# Required
SOURCE_ORG=source-organization
TARGET_ORG=target-organization
GH_SOURCE_PAT=token1,token2,token3
GH_TARGET_PAT=token4,token5,token6

# Optional (defaults to github.com)
SOURCE_HOST=github.com
TARGET_HOST=github.com
GH_USER=your-github-username

# Optional (default: 10 latest versions per package)
MAX_VERSIONS_PER_PACKAGE=10
```

### 2. Token Format

Tokens should be comma-separated without spaces:
```
GH_SOURCE_PAT=ghp_xxxxxxxxxxxx,ghp_yyyyyyyyy,ghp_zzzzzzzzzz
```

Multiple tokens allow the script to rotate through them when rate limits are encountered.

### 3. Maven Configuration

The script generates a temporary `settings.xml` in the working directory with GitHub authentication. Ensure your Maven installation can read this file.

## Usage

```bash
chmod +x migrate-maven-packages-between-orgs.sh
./migrate-maven-packages-between-orgs.sh
```

## Package Selection via `packages.csv`

If `packages.csv` exists in the script folder, the script migrates only the packages listed in that file.
If `packages.csv` is missing, the script migrates all Maven packages from the source organization.

### Expected format

`packages.csv` supports two formats:

1. `package` (single column): migrate all versions for listed packages
2. `package,version` (two columns): migrate only listed versions for listed packages

- `package` header line is optional
- lines starting with `#` are treated as comments
- blank lines are ignored
- use the exact GitHub Maven package name (as returned by `gh api`)

Single-column example:

```csv
package
com.mycompany.mydepartment.my-project-1.1.0
com.mycompany.mydepartment1.my-project1-1.1.2
# temporary hold
com.mycompany.mydepartment3.my-project1-5.5.59
```

Two-column example:

```csv
package,version
com.mycompany.mydepartment.my-project,1.0.0
com.mycompany.mydepartment.my-project,1.0.1
com.mycompany.mydepartment1.my-project1,1.1.2
```

Important: Avoid inline comments in data values (for example, `1.0.0 #note`), because they are treated as part of the version string.

## Version Selection via `versions.csv` (NEW!)

If you want to migrate **only specific versions** of packages instead of all versions, create a `versions.csv` file in the script folder.

### Expected format

`versions.csv` is treated as a two-column CSV file with package names and version numbers.

- Header line (`package,version`) is optional
- lines starting with `#` are treated as comments
- blank lines are ignored
- format: one package-version pair per line (comma-separated)
- use the exact GitHub Maven package name and version

Example:

```csv
package,version
com.mycompany.mydepartment.my-project,1.0.0
com.mycompany.mydepartment.my-project,1.0.1
com.mycompany.mydepartment.my-project,1.1.0
com.mycompany.mydepartment1.my-project1,1.1.2
com.mycompany.mydepartment1.my-project1,1.2.0
# temporary hold
com.mycompany.mydepartment3.my-project1,5.5.59
```

### How it works

1. If `versions.csv` exists and has valid entries, the script will **only migrate those specific package versions**
2. The `MAX_VERSIONS_PER_PACKAGE` setting is **ignored** when using `versions.csv`
3. If `versions.csv` doesn't exist or is empty, the script falls back to the default behavior (all packages, limited by `MAX_VERSIONS_PER_PACKAGE`)
4. If `packages.csv` is in `package,version` format, those versions are loaded directly from `packages.csv` even without `versions.csv`
5. You can combine `packages.csv` and `versions.csv`:
  - Use `packages.csv` to select which packages to consider
  - Use `versions.csv` to select specific versions of those packages

### Use cases

- **Selective migration**: Migrate only tested/stable versions
- **Gradual rollout**: Migrate versions in batches
- **Skip problematic versions**: Exclude versions with known issues
- **Point-in-time migration**: Migrate a specific snapshot of versions

## Version Selection

### Automatic selection (default)

By default, the script migrates only the latest 10 versions per Maven package (newest first based on package version timestamps from GitHub).

- Set `MAX_VERSIONS_PER_PACKAGE=10` to keep the default behavior.
- Set `MAX_VERSIONS_PER_PACKAGE=25` (or any positive integer) to migrate more recent versions.
- Set `MAX_VERSIONS_PER_PACKAGE=0` to migrate all versions.

### Manual selection with `versions.csv` (recommended for selective migration)

For fine-grained control over which versions to migrate, create a `versions.csv` file with the package names and specific versions you want to migrate. See the [Version Selection via versions.csv](#version-selection-via-versionscsv-new) section above for details.

When `versions.csv` exists, `MAX_VERSIONS_PER_PACKAGE` is ignored.

## Output

The script creates a `migration-work` directory with the following structure:

```
migration-work/
├── migration-report.csv          # Main migration report
├── settings.xml                  # Temporary Maven settings
├── deploy.log                    # Latest Maven deployment log
└── [package-name-version]/       # Working directory for each version
    ├── metadata.xml
    ├── version-metadata.xml      # For SNAPSHOT versions
    ├── [artifact-id]-[version].pom
    ├── [artifact-id]-[version].[packaging]
    └── deploy.log
```

### Migration Report (CSV)

The `migration-report.csv` file contains:

| Column | Description |
|--------|-------------|
| package | Maven package name |
| version | Package version |
| source_repo | Source repository name |
| target_repo | Target repository name |
| packaging | Maven packaging type (jar, war, etc.) |
| status | Migration status |

**Status Values:**
- `SUCCESS` - Package successfully migrated
- `DEPLOY_FAILED` - Maven deployment failed
- `DOWNLOAD_FAILED` - Failed to download package artifact
- `INVALID_POM` - POM file validation failed
- `TARGET_REPO_NOT_FOUND` - Target repository doesn't exist

## Error Handling

### Rate Limiting

When the GitHub API returns a 429 (Too Many Requests) response:
1. Script detects the rate limit error
2. Rotates to the next token in the list
3. Retries the operation
4. Cycles through all tokens before failing

### Deployment Failures

Maven deployments are retried up to 3 times:
1. Initial attempt
2. If rate limit detected, rotate token and regenerate settings.xml
3. Retry deployment
4. Final attempt before recording failure

### Logs

- **Console output**: Real-time progress and error messages
- **deploy.log**: Maven deployment output (updated per version)
- **migration-report.csv**: Final status of all packages

## Example Workflow

```bash
# 1. Prepare environment
cp .env.example .env
# Edit .env with your org names and tokens

# 2. Run the migration
./migrate-maven-packages-between-orgs.sh

# 3. Monitor progress
# Script prints each package and version as it processes

# 4. Review results
cat migration-work/migration-report.csv

# 5. Check for failures
grep -v "SUCCESS" migration-work/migration-report.csv

# 6. Clean up (optional)
rm -rf migration-work
```

## Troubleshooting

### "rate limit" error in logs

**Cause**: All tokens have reached their rate limits
**Solution**: 
- Wait for rate limits to reset (usually 1 hour)
- Use tokens with higher rate limits (organization tokens, classic tokens)
- Add more tokens to the comma-separated list

### "Target repo not found"

**Cause**: Repository exists in source org but not in target org
**Solution**:
- Manually create the target repository
- Ensure the repository exists in the target organization
- Re-run the script (it will skip already processed versions)

### "INVALID_POM" status

**Cause**: Downloaded POM file is corrupted or invalid
**Solution**:
- Check source repository access
- Verify the package version exists in source
- Check GitHub token permissions

### Maven deployment authentication failure

**Cause**: Settings.xml has invalid GitHub token
**Solution**:
- Verify `GH_TARGET_PAT` is set correctly
- Ensure token has `write:packages` scope
- Check for special characters in token (no URL encoding needed)

## Performance Tips

1. **Use multiple tokens** to avoid hitting single-token rate limits
2. **Run during off-peak hours** to minimize rate limit conflicts
3. **Monitor the CSV report** to identify common failure patterns
4. **Use organization tokens** (higher rate limits than personal tokens)

## Security Considerations

- **Never commit `.env`** file with credentials
- **Keep tokens secret** - consider using GitHub's token rotation
- **Use least privilege** - tokens should only have `packages` scope
- **Temporary files** - `settings.xml` is created temporarily and removed on script completion (if interrupted, manually delete)

## Advanced Options

### Custom Maven Properties

Edit the Maven deploy command in the script to add custom properties:

```bash
-DskipTests=true \
-DskipStaging=true \
```

### Filtering Packages

To migrate only specific packages, modify the packages loop or pre-filter the results:

```bash
packages=$(GH_TOKEN=$(get_source_token) gh api --paginate \
  "orgs/${SOURCE_ORG}/packages?package_type=maven" \
  -q '.[].name | select(. | startswith("com.company."))')
```

## License

[Your License Here]

## Support

For issues or questions, check the error logs and migration report first. Common issues are usually related to:
- GitHub token permissions
- Network connectivity
- Rate limiting
