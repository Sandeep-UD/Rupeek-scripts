#!/bin/bash

# Usage: ./migrate-nuget-packages-between-orgs.sh
#
#
# Prereqs:
# 1. [gh cli](https://cli.github.com) installed
# 2. Create a `.env` file in this folder with:
#    - SOURCE_ORG=<source-org>
#    - TARGET_ORG=<target-org>
#    - GH_SOURCE_PAT=<source-pat> (must have at least `read:packages`, `read:org` scope)
#    - GH_TARGET_PAT=<target-pat> (must have at least `write:packages`, `read:org` scope)
#
# Notes:
# - This script installs [gpr](https://github.com/jcansdale/gpr) locally to the `./temp/tools` directory
# - This script assumes that the target org's repo name is the same as the source
# - If the repo doesn't exist, the package will still import but won't be mapped to a repo
#


set -e

# shellcheck disable=SC2155
set -uo pipefail

# load .env from script directory if present
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="$SCRIPT_DIR/.env"

if [ ! -f "$ENV_FILE" ]; then
  echo "Error: .env file not found at $ENV_FILE"
  echo "Create it from .env.example and set required values."
  exit 1
fi

set -a
. "$ENV_FILE"
set +a

echo "..."

SOURCE_HOST="${SOURCE_HOST:-github.com}"
MAX_VERSIONS_PER_PACKAGE="${MAX_VERSIONS_PER_PACKAGE:-10}"

MAX_RETRIES="${MAX_RETRIES:-6}"
BASE_RETRY_SECONDS="${BASE_RETRY_SECONDS:-2}"
PACKAGES_CSV="$SCRIPT_DIR/packages.csv"

if ! [[ "$MAX_VERSIONS_PER_PACKAGE" =~ ^[0-9]+$ ]]; then
  echo "Error: MAX_VERSIONS_PER_PACKAGE must be a non-negative integer"
  exit 1
fi

if [ -z "$SOURCE_ORG" ] || [ -z "$TARGET_ORG" ]; then
  echo "Error: SOURCE_ORG and TARGET_ORG must be set in .env."
  echo "Usage: $0"
  exit 1
fi

# Backward-compatible token config:
# - Single token: GH_SOURCE_PAT / GH_TARGET_PAT
# - Multiple tokens (comma-separated): GH_SOURCE_PATS / GH_TARGET_PATS
if [ -z "${GH_SOURCE_PATS:-}" ]; then
  GH_SOURCE_PATS="${GH_SOURCE_PAT:-}"
fi

if [ -z "${GH_TARGET_PATS:-}" ]; then
  GH_TARGET_PATS="${GH_TARGET_PAT:-}"
fi

if [ -z "$GH_SOURCE_PATS" ]; then
  echo "Error: set GH_SOURCE_PAT or GH_SOURCE_PATS in .env"
  exit 1
fi

if [ -z "$GH_TARGET_PATS" ]; then
  echo "Error: set GH_TARGET_PAT or GH_TARGET_PATS in .env"
  exit 1
fi

IFS=',' read -r -a SOURCE_TOKENS <<< "$GH_SOURCE_PATS"
IFS=',' read -r -a TARGET_TOKENS <<< "$GH_TARGET_PATS"

for i in "${!SOURCE_TOKENS[@]}"; do
  SOURCE_TOKENS[$i]="$(echo "${SOURCE_TOKENS[$i]}" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')"
done

for i in "${!TARGET_TOKENS[@]}"; do
  TARGET_TOKENS[$i]="$(echo "${TARGET_TOKENS[$i]}" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')"
done

if [ "${#SOURCE_TOKENS[@]}" -eq 0 ]; then
  echo "Error: no source tokens parsed from GH_SOURCE_PATS"
  exit 1
fi

if [ "${#TARGET_TOKENS[@]}" -eq 0 ]; then
  echo "Error: no target tokens parsed from GH_TARGET_PATS"
  exit 1
fi

PACKAGE_FILTER_ENABLED=0
PACKAGE_FILTER_RAW=""

load_package_filter() {
  if [ -f "$PACKAGES_CSV" ]; then
    echo "Found packages.csv - migrating listed packages only."
    PACKAGE_FILTER_RAW=$(grep -v -E '^[[:space:]]*(#|package)' "$PACKAGES_CSV" | grep -v -E '^[[:space:]]*$' | tr -d '\r' || true)
    if [ -z "$PACKAGE_FILTER_RAW" ]; then
      echo "packages.csv has no package rows - migrating all packages from source org."
      PACKAGE_FILTER_ENABLED=0
    else
      PACKAGE_FILTER_ENABLED=1
    fi
  else
    echo "packages.csv not found - migrating all packages from source org."
    PACKAGE_FILTER_ENABLED=0
  fi
}

package_in_filter() {
  local candidate="$1"
  local pkg
  while IFS= read -r pkg; do
    [ -z "$pkg" ] && continue
    if [ "$pkg" = "$candidate" ]; then
      return 0
    fi
  done <<< "$PACKAGE_FILTER_RAW"
  return 1
}

source_token_idx=0
target_token_idx=0

echo "Max versions/package: $MAX_VERSIONS_PER_PACKAGE"
load_package_filter

# create temp dir
mkdir -p ./temp
cd ./temp
temp_dir=$(pwd)
GPR_PATH="$temp_dir/tool/gpr"
CSV_FILE="$temp_dir/migration-report.csv"
ERROR_LOG="$temp_dir/migration-errors.log"

echo "timestamp,source_org,target_org,repo,package,version,status,message" > "$CSV_FILE"
echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] Starting migration" > "$ERROR_LOG"

# check if dotnet is installed
if ! command -v dotnet &>/dev/null; then
  echo "Error: dotnet could not be found"
  exit
fi

# install gpr locally
if [ ! -f "$GPR_PATH" ]; then
  echo "Installing gpr locally to $GPR_PATH"
  dotnet tool install gpr --add-source https://api.nuget.org/v3/index.json --tool-path ./tool
fi

csv_escape() {
  local value="${1:-}"
  value="${value//\"/\"\"}"
  printf '"%s"' "$value"
}

log_error() {
  local message="$1"
  echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] $message" >> "$ERROR_LOG"
}

append_csv() {
  local repo="$1"
  local package="$2"
  local version="$3"
  local status="$4"
  local message="$5"

  {
    csv_escape "$(date -u +"%Y-%m-%dT%H:%M:%SZ")"
    printf ','
    csv_escape "$SOURCE_ORG"
    printf ','
    csv_escape "$TARGET_ORG"
    printf ','
    csv_escape "$repo"
    printf ','
    csv_escape "$package"
    printf ','
    csv_escape "$version"
    printf ','
    csv_escape "$status"
    printf ','
    csv_escape "$message"
    printf '\n'
  } >> "$CSV_FILE"
}

next_source_token() {
  local idx=$((source_token_idx % ${#SOURCE_TOKENS[@]}))
  local token="${SOURCE_TOKENS[$idx]}"
  source_token_idx=$((source_token_idx + 1))
  echo "$token"
}

next_target_token() {
  local idx=$((target_token_idx % ${#TARGET_TOKENS[@]}))
  local token="${TARGET_TOKENS[$idx]}"
  target_token_idx=$((target_token_idx + 1))
  echo "$token"
}

is_rate_limited() {
  local err="$1"
  if echo "$err" | grep -Eqi 'rate limit exceeded|secondary rate limit|too many requests|HTTP 429'; then
    return 0
  fi
  return 1
}

gh_api_with_retry() {
  local endpoint="$1"
  local query="$2"
  local token_type="$3" # source|target

  local attempt=1
  while [ "$attempt" -le "$MAX_RETRIES" ]; do
    local token
    if [ "$token_type" = "source" ]; then
      token="$(next_source_token)"
    else
      token="$(next_target_token)"
    fi

    local stderr_file
    stderr_file="$(mktemp)"

    local output
    if output=$(GH_HOST="$SOURCE_HOST" GH_TOKEN="$token" gh api "$endpoint" --paginate -q "$query" 2>"$stderr_file"); then
      rm -f "$stderr_file"
      echo "$output"
      return 0
    fi

    local err
    err="$(cat "$stderr_file")"
    rm -f "$stderr_file"

    if is_rate_limited "$err"; then
      local sleep_seconds=$((BASE_RETRY_SECONDS * attempt))
      log_error "Rate limited ($token_type token) for endpoint '$endpoint'. Attempt $attempt/$MAX_RETRIES. Retrying in ${sleep_seconds}s. Details: $err"
      sleep "$sleep_seconds"
      attempt=$((attempt + 1))
      continue
    fi

    if [ "$attempt" -lt "$MAX_RETRIES" ]; then
      local sleep_seconds=$((BASE_RETRY_SECONDS * attempt))
      log_error "Transient API error for endpoint '$endpoint'. Attempt $attempt/$MAX_RETRIES. Retrying in ${sleep_seconds}s. Details: $err"
      sleep "$sleep_seconds"
      attempt=$((attempt + 1))
      continue
    fi

    log_error "API request failed after $MAX_RETRIES attempts. Endpoint: '$endpoint'. Details: $err"
    return 1
  done

  return 1
}

download_nupkg_with_retry() {
  local url="$1"
  local output_file="$2"

  local attempt=1
  while [ "$attempt" -le "$MAX_RETRIES" ]; do
    local token
    token="$(next_source_token)"

    local http_code
    http_code=$(curl -sS -L \
      -H "Authorization: token $token" \
      -w '%{http_code}' \
      -o "$output_file" \
      "$url" || echo "000")

    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
      return 0
    fi

    if [ "$http_code" = "429" ] || [ "$http_code" = "403" ] || [ "$http_code" = "000" ] || [ "$http_code" -ge 500 ]; then
      local sleep_seconds=$((BASE_RETRY_SECONDS * attempt))
      log_error "Download retry for '$url' (HTTP $http_code), attempt $attempt/$MAX_RETRIES, waiting ${sleep_seconds}s"
      sleep "$sleep_seconds"
      attempt=$((attempt + 1))
      continue
    fi

    log_error "Download failed for '$url' with non-retryable HTTP $http_code"
    return 1
  done

  log_error "Download failed after $MAX_RETRIES attempts for '$url'"
  return 1
}

push_with_retry() {
  local nupkg_file="$1"
  local repo_name="$2"

  local attempt=1
  while [ "$attempt" -le "$MAX_RETRIES" ]; do
    local token
    token="$(next_target_token)"

    local output_file
    output_file="$(mktemp)"

    if "$GPR_PATH" push "$nupkg_file" --repository "https://github.com/$TARGET_ORG/$repo_name" -k "$token" > "$output_file" 2>&1; then
      rm -f "$output_file"
      return 0
    fi

    local err
    err="$(cat "$output_file")"
    rm -f "$output_file"

    if is_rate_limited "$err" || echo "$err" | grep -Eqi 'timeout|temporar|5[0-9]{2}|network'; then
      local sleep_seconds=$((BASE_RETRY_SECONDS * attempt))
      log_error "Push retry for '$nupkg_file' to '$repo_name', attempt $attempt/$MAX_RETRIES, waiting ${sleep_seconds}s. Details: $err"
      sleep "$sleep_seconds"
      attempt=$((attempt + 1))
      continue
    fi

    log_error "Push failed for '$nupkg_file' to '$repo_name': $err"
    return 1
  done

  log_error "Push failed after $MAX_RETRIES attempts for '$nupkg_file' to '$repo_name'"
  return 1
}

total_processed=0
total_success=0
total_failed=0

packages=$(gh_api_with_retry "orgs/$SOURCE_ORG/packages?package_type=nuget" '.[] | [.name, (.repository.name // "")] | @tsv' source || true)

if [ -z "$packages" ]; then
  echo "No packages found or package listing failed. See $ERROR_LOG"
  append_csv "" "" "" "FAILED" "Could not list source packages"
  echo "CSV report: $CSV_FILE"
  echo "Error log: $ERROR_LOG"
  exit 1
fi

while IFS= read -r response; do

  [ -z "$response" ] && continue

  packageName=$(echo "$response" | cut -f 1)
  repoName=$(echo "$response" | cut -f 2)

  if [ "$PACKAGE_FILTER_ENABLED" -eq 1 ] && ! package_in_filter "$packageName"; then
    continue
  fi

  if [ -z "$repoName" ] || [ "$repoName" = "null" ]; then
    repoName="$packageName"
  fi

  echo "$repoName --> $packageName"

  versions=$(gh_api_with_retry "orgs/$SOURCE_ORG/packages/nuget/$packageName/versions" '.[] | .name' source || true)
  versions=$(echo "$versions" | tr -d '\r' | sed '/^[[:space:]]*$/d' | sort -V)

  if [ "$MAX_VERSIONS_PER_PACKAGE" -gt 0 ]; then
    versions=$(echo "$versions" | tail -n "$MAX_VERSIONS_PER_PACKAGE")
  fi

  if [ -z "$versions" ]; then
    total_failed=$((total_failed + 1))
    append_csv "$repoName" "$packageName" "" "FAILED" "Could not fetch versions"
    log_error "No versions found or failed to query versions for package '$packageName'"
    continue
  fi

  while IFS= read -r version; do
    [ -z "$version" ] && continue
    total_processed=$((total_processed + 1))
    echo "$version"
    url="https://nuget.pkg.$SOURCE_HOST/$SOURCE_ORG/download/$packageName/$version/$packageName.$version.nupkg"
    echo "$url"

    nupkg_file="${packageName}_${version}.nupkg"
    if ! download_nupkg_with_retry "$url" "$nupkg_file"; then
      total_failed=$((total_failed + 1))
      append_csv "$repoName" "$packageName" "$version" "FAILED" "Download failed"
      continue
    fi

    # must do this otherwise there is errors (multiple of each file)
    # Use PowerShell to remove duplicate files from the nupkg (which is a zip file)
    if ! powershell.exe -Command "Add-Type -AssemblyName System.IO.Compression.FileSystem; \$zip = [System.IO.Compression.ZipFile]::Open('${nupkg_file}', 'Update'); \$filesToRemove = \$zip.Entries | Where-Object { \$_.FullName -eq '_rels/.rels' -or \$_.FullName -eq '[Content_Types].xml' }; if (\$filesToRemove) { \$filesToRemove | ForEach-Object { \$_.Delete() } }; \$zip.Dispose()"; then
      total_failed=$((total_failed + 1))
      append_csv "$repoName" "$packageName" "$version" "FAILED" "Zip cleanup failed"
      log_error "Zip cleanup failed for '$nupkg_file'"
      continue
    fi

    if push_with_retry "./$nupkg_file" "$repoName"; then
      total_success=$((total_success + 1))
      append_csv "$repoName" "$packageName" "$version" "SUCCESS" "Pushed"
    else
      total_failed=$((total_failed + 1))
      append_csv "$repoName" "$packageName" "$version" "FAILED" "Push failed"
    fi
  done <<< "$versions"

  echo "..."

done <<< "$packages"

echo "Processed: $total_processed"
echo "Succeeded: $total_success"
echo "Failed: $total_failed"
echo "CSV report: $CSV_FILE"
echo "Error log: $ERROR_LOG"
echo "Run this to clean up your working dir: rm -rf ./temp"
