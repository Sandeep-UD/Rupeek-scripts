# NuGet Package Migration (GitHub Packages)

This folder contains a script to migrate NuGet packages from one GitHub organization to another.

Script: `migrate-nuget-packages-between-orgs.sh`

## What the script does

- Reads package list from `SOURCE_ORG`
- Downloads all versions of each NuGet package
- Pushes packages to `TARGET_ORG`
- Tries to map each package to a repository with the same name in the target org
- Uses paginated GitHub API calls (`--paginate`) for package/version listing
- Retries transient failures and rate-limit responses with backoff
- Can rotate across multiple source/target tokens
- Writes a CSV migration report and an error log file

## Prerequisites

1. `gh` (GitHub CLI) installed
2. `.NET SDK` installed (`dotnet` command available)
3. Bash environment (Git Bash/WSL/macOS/Linux)
4. Source and target GitHub Personal Access Tokens (PATs)

## Setup

Create a `.env` file in this folder:

```env
SOURCE_ORG=your-source-org
TARGET_ORG=your-target-org
# single-token mode
GH_SOURCE_PAT=your-source-token
GH_TARGET_PAT=your-target-token

# or multi-token mode (comma-separated; script rotates tokens)
# GH_SOURCE_PATS=token1,token2,token3
# GH_TARGET_PATS=tokenA,tokenB,tokenC

# optional (default: github.com)
SOURCE_HOST=github.com

# optional maximum versions per package (latest N; 0 = all)
# MAX_VERSIONS_PER_PACKAGE=10

# optional retry tuning
# MAX_RETRIES=6
# BASE_RETRY_SECONDS=2
```

Required token scopes:

- `GH_SOURCE_PAT` / each token in `GH_SOURCE_PATS`: `read:packages`, `read:org`
- `GH_TARGET_PAT` / each token in `GH_TARGET_PATS`: `write:packages`, `read:org`

Optional package filter via `packages.csv` in this folder:

- one package name per line
- optional `package` header
- `#` comments and blank lines are ignored

Example:

```csv
package
My.Package
Contoso.Utility
```

If `packages.csv` is missing or empty, all packages are considered.

## Run

From this folder:

```bash
chmod +x ./migrate-nuget-packages-between-orgs.sh
./migrate-nuget-packages-between-orgs.sh
```

## Output

- Temporary files are created in `./temp`
- Local `gpr` tool is installed to `./temp/tool`
- CSV report: `./temp/migration-report.csv`
- Error log: `./temp/migration-errors.log`

## Cleanup

```bash
rm -rf ./temp
```

## Notes

- The script expects source and target repo names to match.
- If a target repo does not exist, package import can still succeed, but repository mapping may be missing.
