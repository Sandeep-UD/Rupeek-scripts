# Enterprise GitHub Secrets Migration Orchestrator (v4)

A high-performance, fault-tolerant Python orchestrator for bulk migrating GitHub Actions secrets at enterprise scale (1,000+ repositories). Built on top of the GitHub CLI and the `gh-secrets-migrator` extension.

Supports both **Repository-to-Repository** (`ORG_TO_ORG=false`) and **Organization-to-Organization** (`ORG_TO_ORG=true`) migrations.

---

## Table of Contents
1. [Key Features](#key-features)
2. [Prerequisites](#prerequisites)
3. [Quick Start](#quick-start)
4. [Configuration (`.env`)](#configuration-env)
   - [Option A: Multiple PATs (Rotation & Failover)](#option-a-multiple-pats-rotation--failover)
   - [Option B: Single GitHub App (Recommended)](#option-b-single-github-app-recommended)
   - [Option C: Two Separate GitHub Apps](#option-c-two-separate-github-apps)
   - [Option D: Hybrid (PAT + GitHub App)](#option-d-hybrid-pat--github-app)
5. [Input CSV Format (`repos.csv`)](#input-csv-format-reposcsv)
6. [GitHub App Permission Requirements](#github-app-permission-requirements)
7. [Running the Migration](#running-the-migration)
8. [Reports & Audit Logging](#reports--audit-logging)
9. [Performance Tuning for 800+ Repositories](#performance-tuning-for-800-repositories)
10. [Troubleshooting & FAQs](#troubleshooting--faqs)

---

## Key Features

- **Multi-PAT Rotation & Auto-Failover**: Round-robins across multiple Personal Access Tokens. Automatically cools down exhausted tokens and rotates to the next available token without failing jobs.
- **First-Class GitHub App Support**: Generates and auto-refreshes short-lived Installation Access Tokens (yielding up to 15,000 requests/hour). Automatically auto-discovers organization installation IDs.
- **Continuous Sliding-Window Worker Pool**: Continuous thread pool execution with zero batch stalls—fast repositories do not wait for slower ones.
- **Crash Durability & Seamless Resume**: Atomic snapshot checkpointing (`migration_checkpoint.csv`). Automatically skips completed repositories on rerun.
- **Rate Limit & Abuse Protection**: Shared start-rate limiter with exponential backoff and jitter. Safely handles GitHub primary and secondary rate limits.
- **Security & Secret Scrubbing**: All PATs, GitHub App tokens, and secret patterns are automatically redacted from console and log files. Detached standard input (`stdin=DEVNULL`) prevents CLI interactive freezes. Formula-injection sanitization prevents spreadsheet execution risks.

---

## Prerequisites

1. **Python 3.10+**
   ```bash
   python --version
   ```
2. **Python Dependencies**
   ```bash
   pip install python-dotenv
   # Optional (recommended for GitHub App JWT signing):
   pip install cryptography
   ```
   *(Note: If `cryptography` is not installed, the script will automatically use `openssl` if available on your system).*

3. **GitHub CLI (`gh`)**
   ```bash
   gh --version
   ```

4. **GitHub CLI Secrets Migrator Extension**
   ```bash
   gh extension install github/gh-secrets-migrator
   ```

---

## Quick Start

1. Clone or copy the migration files into your working folder:
   ```text
   New secrets migration/
   ├── migrate_secrets.py
   ├── .env
   ├── repos.csv
   ├── reports/
   └── logs/
   ```
2. Populate `repos.csv` with your source and target repositories.
3. Configure your credentials and organizations in `.env`.
4. Run a dry run to validate connectivity and permissions:
   ```bash
   py .\migrate_secrets.py
   ```
5. When ready for production, set `DRY_RUN=false` in `.env` and execute.

---

## Configuration (`.env`)

Create or update your `.env` file in the same directory as `migrate_secrets.py`.

### Common Settings

```ini
# ============================================================
# TARGET & SOURCE ORGANIZATIONS
# ============================================================
SOURCE_ORG=source-organization
TARGET_ORG=target-organization

SOURCE_ENDPOINT=https://api.github.com
TARGET_ENDPOINT=https://api.github.com

# ------------------------------------------------------------
# MIGRATION MODE:
# false = Repository-to-Repository (uses repos.csv)
# true  = Organization-to-Organization (migrates org secrets directly)
# ------------------------------------------------------------
ORG_TO_ORG=false
ORG_SOURCE_REPO=.github

# ------------------------------------------------------------
# RUN CONTROLS
# ------------------------------------------------------------
DRY_RUN=false
SKIP_OVERWRITE=true
RESUME_ENABLED=true
SKIP_SUCCESS=true
RETRY_FAILED=true

# ------------------------------------------------------------
# PERFORMANCE & TIMEOUTS
# ------------------------------------------------------------
MAX_WORKERS=5
DELAY_SECONDS=0.5
COMMAND_TIMEOUT=180

# ------------------------------------------------------------
# VERIFICATION
# (Set to false for 800+ repos for fastest processing)
# ------------------------------------------------------------
VERIFY_SECRETS=false
VERIFY_TIMEOUT=15
VERIFY_INTERVAL=4
```

---

### Authentication Configurations

Choose the credential setup that best matches your environment:

#### Option A: Multiple PATs (Rotation & Failover)
Provide one or more comma-separated PATs per side. The script round-robins across them and automatically fails over if a token's 5,000 req/hr quota is exhausted:

```ini
SOURCE_PATS=ghp_srcToken111111111111111111111111111111,ghp_srcToken222222222222222222222222222222
TARGET_PATS=ghp_tgtToken111111111111111111111111111111,ghp_tgtToken222222222222222222222222222222
```

#### Option B: Single GitHub App (Recommended)
If both organizations are in the same enterprise (or the App is set to **"Any account"**), create **one** App, install it on both orgs, and configure:

```ini
APP_ID=12345678
APP_PRIVATE_KEY_PATH=C:\path\to\github-app-key.pem

# Installation IDs are automatically resolved per organization
```

#### Option C: Two Separate GitHub Apps
If Source and Target organizations are in separate tenants or environments:

```ini
SOURCE_APP_ID=11111111
SOURCE_APP_PRIVATE_KEY_PATH=C:\path\to\source-key.pem

TARGET_APP_ID=22222222
TARGET_APP_PRIVATE_KEY_PATH=C:\path\to\target-key.pem
```

#### Option D: Hybrid (PAT + GitHub App)
Mix credentials freely. For example, use a PAT on Source and a GitHub App on Target:

```ini
SOURCE_PATS=ghp_sourceToken123456789...

TARGET_APP_ID=22222222
TARGET_APP_PRIVATE_KEY_PATH=C:\path\to\target-key.pem
```

---

## Input CSV Format (`repos.csv`)

Required when `ORG_TO_ORG=false`. Create a UTF-8 encoded `repos.csv` file in the same directory:

```csv
source_repo,target_repo
frontend-portal,frontend-portal
backend-api,backend-api
auth-service,auth-service
legacy-utils,modern-utils
```

- Column headers must be exactly `source_repo,target_repo`.
- Whitespace is automatically trimmed.
- Duplicate rows are automatically detected and logged as `SKIPPED`.

---

## GitHub App Permission Requirements

If using a GitHub App for authentication, grant the following permissions in the GitHub App settings:

### Repository Permissions
| Permission | Access Level | Purpose |
| :--- | :--- | :--- |
| **Secrets** | **Read and write** | Read secret names (source) and write encrypted secrets (target). |
| **Workflows** | **Read and write** | Required because `gh secrets-migrator` deploys a temporary workflow. |
| **Contents** | **Read and write** | Allows temporary branch and workflow commit creation/cleanup. |
| **Actions** | **Read and write** | Allows triggering and monitoring the migration workflow. |
| **Administration** | **Read-only** | Verifies repository existence and permissions. |
| **Metadata** | **Read-only** | Mandatory GitHub base permission. |

### Organization Permissions (Required for `ORG_TO_ORG=true`)
| Permission | Access Level | Purpose |
| :--- | :--- | :--- |
| **Organization secrets** | **Read and write** | Required for migrating org-level shared secrets. |
| **Administration** | **Read-only** | Used to auto-discover installation IDs and verify org access. |

### Installation Configuration
- **Where can this GitHub App be installed?**: Select **"Any account"** (if installing on both Source and Target orgs) or **"Only on this account"**.
- **Webhook**: Uncheck **Active** (not needed for migration).

---

## Running the Migration

### Step 1: Pre-Flight Check (Dry Run)
Set `DRY_RUN=true` in `.env` and execute:
```powershell
py .\migrate_secrets.py
```
This tests credentials, verifies repository existence, and inspects secret counts without mutating any destination repository.

### Step 2: Production Execution
Set `DRY_RUN=false` in `.env` and run:
```powershell
py .\migrate_secrets.py
```

### Step 3: Interrupting & Resuming
- **First Ctrl-C**: Graceful stop. In-flight jobs finish, the latest checkpoint is flushed to disk, and no new jobs start.
- **Second Ctrl-C**: Hard terminate. Kills active CLI child processes immediately.
- **To Resume**: Simply run `py .\migrate_secrets.py` again. Repositories with status `SUCCESS` or `SUCCESS_UNVERIFIED` are automatically skipped.

---

## Reports & Audit Logging

All outputs are saved to the `reports/` and `logs/` folders:

- **`reports/migration_results.csv`**: Full chronological audit trail. Every repository run, retry attempt, duration, and status is logged here.
- **`reports/migration_checkpoint.csv`**: Atomic snapshot containing only the latest status for each repository mapping. Used by the resume engine.
- **`reports/migration_summary.csv`**: High-level execution summary per run ID (start time, completion percentage, total verified, overall outstanding).
- **`reports/migration_errors.log`**: Dedicated log capturing failures and error traces.
- **`logs/migration.log`**: Detailed real-time application log.

---

## Performance Tuning for 800+ Repositories

For high-throughput migrations of 800+ repositories, use the following `.env` settings:

```ini
MAX_WORKERS=5           # 5 parallel workers
DELAY_SECONDS=0.5       # 0.5s start spacing avoids secondary rate limits
VERIFY_SECRETS=false    # Skips post-check API calls, saving 2-4 requests per repo
COMMAND_TIMEOUT=180     # 3 min timeout prevents hanging on network stalls
```

### Expected Throughput:
- **With GitHub App or 2+ PATs**: ~50–65 repositories per minute $\rightarrow$ **15 to 25 minutes total** for 800 repositories.
- **With a Single Classic PAT**: ~45–60 minutes total (due to a ~30 min rate-limit reset window after 5,000 requests).

---

## Troubleshooting & FAQs

### Q: Why did verification report `missing: SECRETS_MIGRATOR_SOURCE_PAT`?
**A:** This is not an error! `gh secrets-migrator` creates two temporary internal tokens on the source repo (`SECRETS_MIGRATOR_SOURCE_PAT` and `SECRETS_MIGRATOR_TARGET_PAT`) to run its migration workflow. The tool intentionally does not copy these internal tokens to the target. Your real application secrets migrated successfully. Set `VERIFY_SECRETS=false` to skip this check.

### Q: What if a repository fails with a timeout?
**A:** If `COMMAND_TIMEOUT` is reached, the process is terminated and the status is logged as `TIMEOUT`. You can safely re-run the script with `RETRY_FAILED=true` to re-attempt failed jobs.

### Q: Can I migrate both repo secrets and org secrets?
**A:** Yes. First run with `ORG_TO_ORG=false` using `repos.csv` to migrate all repository-level secrets. Then run with `ORG_TO_ORG=true` to migrate the shared organization-level secrets.
