#!/usr/bin/env python3
"""
Enterprise GitHub Secrets Migration Orchestrator (v4 - High Throughput).

Features:
  - Multi-PAT rotation with automatic failover upon rate-limit exhaustion.
  - GitHub App authentication (standalone or automatic fallback when PATs exhaust).
  - High-concurrency continuous worker pool (no batch barriers).
  - High-performance atomic checkpointing and incremental results logging.
  - Fast, non-blocking post-migration verification.
  - Subprocess safety (detached stdin, command timeout, ambient token sanitization).
  - Full secret token scrubbing across all loggers and console outputs.
  - Graceful multi-stage Ctrl-C interrupt handling.
"""

import base64
import csv
import json
import logging
import os
import random
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from collections import Counter
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from datetime import datetime, timezone
from pathlib import Path

from dotenv import load_dotenv

# Force UTF-8 encoding on Windows to prevent charmap/cp1252 UnicodeEncodeErrors
if sys.platform == "win32":
    os.environ["PYTHONIOENCODING"] = "utf-8:replace"
    os.environ["PYTHONUTF8"] = "1"
    os.environ["PYTHONLEGACYWINDOWSSTDIO"] = "0"


# Optional RSA signing libraries for GitHub App JWT generation
try:
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import padding
    from cryptography.hazmat.primitives.serialization import load_pem_private_key
    HAS_CRYPTOGRAPHY = True
except ImportError:
    HAS_CRYPTOGRAPHY = False

try:
    import jwt as pyjwt
    HAS_PYJWT = True
except ImportError:
    HAS_PYJWT = False


# ============================================================
# CONFIGURATION HELPERS
# ============================================================

def env_str(name, default=""):
    return os.getenv(name, default).strip()


def env_bool(name, default):
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    return raw.strip().lower() in ("1", "true", "yes", "y", "on")


def env_num(name, default, cast, minimum):
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        value = default
    else:
        try:
            value = cast(raw.strip())
        except ValueError:
            raise SystemExit(f"Invalid value for {name}: {raw!r}")
    return max(minimum, value)


def env_list(name, fallback_name=""):
    """Parse comma/newline/space-separated tokens from environment variables."""
    raw = os.getenv(name, "") or (os.getenv(fallback_name, "") if fallback_name else "")
    tokens = []
    for item in re.split(r"[\r\n,;]+", raw):
        cleaned = item.strip()
        if cleaned:
            tokens.append(cleaned)
    return tokens


# ============================================================
# PATHS AND BASE CONFIGURATION
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

REPORT_DIR = BASE_DIR / "reports"
LOG_DIR = BASE_DIR / "logs"

REPORT_DIR.mkdir(exist_ok=True)
LOG_DIR.mkdir(exist_ok=True)

INPUT_CSV = BASE_DIR / "repos.csv"

RESULT_CSV = REPORT_DIR / "migration_results.csv"
SUMMARY_CSV = REPORT_DIR / "migration_summary.csv"
CHECKPOINT_CSV = REPORT_DIR / "migration_checkpoint.csv"
ERROR_LOG = REPORT_DIR / "migration_errors.log"
MAIN_LOG = LOG_DIR / "migration.log"

load_dotenv(BASE_DIR / ".env")

RUN_ID = (
    datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    + "-" + uuid.uuid4().hex[:6]
)

SOURCE_ORG = env_str("SOURCE_ORG")
TARGET_ORG = env_str("TARGET_ORG")

SOURCE_ENDPOINT = env_str("SOURCE_ENDPOINT", "https://api.github.com")
TARGET_ENDPOINT = env_str("TARGET_ENDPOINT", "https://api.github.com")

ORG_SOURCE_REPO = env_str("ORG_SOURCE_REPO", ".github")

ORG_TO_ORG = env_bool("ORG_TO_ORG", False)
DRY_RUN = env_bool("DRY_RUN", False)
SKIP_OVERWRITE = env_bool("SKIP_OVERWRITE", True)

RESUME_ENABLED = env_bool("RESUME_ENABLED", True)
SKIP_SUCCESS = env_bool("SKIP_SUCCESS", True)
RETRY_FAILED = env_bool("RETRY_FAILED", True)

PAT_MODE = env_str("PAT_MODE", "env").lower()  # "env" or "flag"

MAX_WORKERS = env_num("MAX_WORKERS", 5, int, 1)
DELAY_SECONDS = env_num("DELAY_SECONDS", 1.0, float, 0)

MAX_RETRIES = env_num("MAX_RETRIES", 3, int, 0)
RETRY_BASE_DELAY = env_num("RETRY_BASE_DELAY", 4.0, float, 0)
RETRY_MAX_DELAY = env_num("RETRY_MAX_DELAY", 120.0, float, 0)

COMMAND_TIMEOUT = env_num("COMMAND_TIMEOUT", 180, int, 0)

VERIFY_SECRETS = env_bool("VERIFY_SECRETS", True)
VERIFY_TIMEOUT = env_num("VERIFY_TIMEOUT", 15, int, 1)
VERIFY_INTERVAL = env_num("VERIFY_INTERVAL", 4, int, 1)

PRECHECK_REPOS = env_bool("PRECHECK_REPOS", True)
REQUIRE_TARGET_REPO = env_bool("REQUIRE_TARGET_REPO", True)
PILOT_LIMIT = env_num("PILOT_LIMIT", 0, int, 0)

MODE = "org-to-org" if ORG_TO_ORG else "repo-to-repo"


# ============================================================
# TOKEN SCRUBBING & REDACTION
# ============================================================

TOKEN_PATTERN = re.compile(
    r"(gh[pousr]_[A-Za-z0-9_]{20,}|github_pat_[A-Za-z0-9_]{20,})"
)

DYNAMIC_SECRETS = set()
SECRETS_LOCK = threading.Lock()


def register_secret_to_scrub(secret: str):
    if secret and len(secret) >= 8:
        with SECRETS_LOCK:
            DYNAMIC_SECRETS.add(secret)


def scrub(text):
    text = str(text)
    with SECRETS_LOCK:
        for sec in sorted(DYNAMIC_SECRETS, key=len, reverse=True):
            if sec in text:
                text = text.replace(sec, "[REDACTED]")
    return TOKEN_PATTERN.sub("[REDACTED]", text)


def redact(text):
    return scrub(text)[-3000:]


class ScrubFilter(logging.Filter):
    def filter(self, record):
        record.msg = scrub(record.getMessage())
        record.args = ()
        return True


# ============================================================
# LOGGING
# ============================================================

logger = logging.getLogger("secrets_migration")
logger.setLevel(logging.INFO)
logger.handlers.clear()

formatter = logging.Formatter(
    "%(asctime)s | %(levelname)s | %(threadName)s | %(message)s"
)

file_handler = logging.FileHandler(MAIN_LOG, encoding="utf-8")
file_handler.setFormatter(formatter)

error_handler = logging.FileHandler(ERROR_LOG, encoding="utf-8")
error_handler.setFormatter(formatter)
error_handler.setLevel(logging.ERROR)

console_handler = logging.StreamHandler(sys.stdout)
console_handler.setFormatter(formatter)

for handler in (file_handler, error_handler, console_handler):
    handler.addFilter(ScrubFilter())
    logger.addHandler(handler)


# ============================================================
# GITHUB APP AUTHENTICATION HANDLER
# ============================================================

class GitHubAppAuth:
    """Handles GitHub App JWT signing and installation token caching."""

    def __init__(self, app_id, private_key_pem, endpoint, installation_id=None):
        self.app_id = str(app_id).strip()
        self.private_key_pem = private_key_pem.strip()
        self.endpoint = endpoint
        self.installation_id = str(installation_id).strip() if installation_id else None

        self._token_cache = {}  # org -> (token, expires_at_mono)
        self._lock = threading.Lock()
        self._exhausted_until = 0.0

    def is_exhausted(self, now_mono):
        return self._exhausted_until > now_mono

    def mark_exhausted(self, duration=3600.0):
        with self._lock:
            self._exhausted_until = time.monotonic() + duration

    def _sign_jwt(self) -> str:
        now_ts = int(time.time())
        payload = {
            "iat": now_ts - 60,
            "exp": now_ts + 540,
            "iss": self.app_id,
        }
        header = {"alg": "RS256", "typ": "JWT"}

        def b64url(b_data):
            return base64.urlsafe_b64encode(b_data).decode("ascii").rstrip("=")

        h_b64 = b64url(json.dumps(header, separators=(",", ":")).encode("utf-8"))
        p_b64 = b64url(json.dumps(payload, separators=(",", ":")).encode("utf-8"))
        signing_input = f"{h_b64}.{p_b64}".encode("ascii")

        # Approach 1: cryptography package
        if HAS_CRYPTOGRAPHY:
            priv_key = load_pem_private_key(self.private_key_pem.encode("utf-8"), password=None)
            signature = priv_key.sign(signing_input, padding.PKCS1v15(), hashes.SHA256())
            return f"{h_b64}.{p_b64}.{b64url(signature)}"

        # Approach 2: PyJWT
        if HAS_PYJWT:
            return pyjwt.encode(payload, self.private_key_pem, algorithm="RS256")

        # Approach 3: OpenSSL CLI fallback
        openssl_bin = shutil.which("openssl")
        if openssl_bin:
            with tempfile.NamedTemporaryFile("w", delete=False, suffix=".pem") as tmp:
                tmp.write(self.private_key_pem)
                tmp_path = tmp.name
            try:
                proc = subprocess.run(
                    [openssl_bin, "dgst", "-sha256", "-sign", tmp_path],
                    input=signing_input,
                    capture_output=True,
                    check=True,
                )
                signature = proc.stdout
                return f"{h_b64}.{p_b64}.{b64url(signature)}"
            finally:
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)

        raise RuntimeError(
            "GitHub App authentication requires 'cryptography' (pip install cryptography) "
            "or 'openssl' on system PATH."
        )

    def get_token(self, org: str) -> str:
        with self._lock:
            now_mono = time.monotonic()
            if org in self._token_cache:
                token, expires_mono = self._token_cache[org]
                if expires_mono - now_mono > 300:  # 5 min safe buffer
                    return token

            jwt_token = self._sign_jwt()

            # Auto-resolve installation_id if omitted
            if not self.installation_id:
                inst_path = f"/orgs/{urllib.parse.quote(org)}/installation"
                inst_url = normalize_api_url(self.endpoint, inst_path)
                req = urllib.request.Request(
                    inst_url,
                    headers={
                        "Authorization": f"Bearer {jwt_token}",
                        "Accept": "application/vnd.github+json",
                        "X-GitHub-Api-Version": "2022-11-28",
                        "User-Agent": "secrets-migration-orchestrator",
                    },
                )
                with urllib.request.urlopen(req, timeout=30) as resp:
                    inst_data = json.loads(resp.read().decode("utf-8"))
                    self.installation_id = str(inst_data["id"])
                logger.info("Auto-discovered GitHub App Installation ID for %s: %s", org, self.installation_id)

            # Exchange JWT for installation access token
            token_path = f"/app/installations/{self.installation_id}/access_tokens"
            token_url = normalize_api_url(self.endpoint, token_path)
            req = urllib.request.Request(
                token_url,
                data=b"{}",
                headers={
                    "Authorization": f"Bearer {jwt_token}",
                    "Accept": "application/vnd.github+json",
                    "X-GitHub-Api-Version": "2022-11-28",
                    "User-Agent": "secrets-migration-orchestrator",
                },
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                token_data = json.loads(resp.read().decode("utf-8"))
                new_token = token_data["token"]

            register_secret_to_scrub(new_token)
            # Default GitHub App tokens expire in 60 minutes
            self._token_cache[org] = (new_token, now_mono + 3600)
            return new_token


# ============================================================
# MULTI-CREDENTIAL POOL WITH AUTO-FAILOVER
# ============================================================

class CredentialPool:
    """Manages rotation across multiple PATs and GitHub App tokens."""

    def __init__(self, role: str, org: str, endpoint: str, pats: list, app_auth: GitHubAppAuth = None):
        self.role = role
        self.org = org
        self.endpoint = endpoint
        self.pats = pats
        self.app_auth = app_auth
        self._lock = threading.Lock()
        self._index = 0

        self.state = {}
        for idx, pat in enumerate(pats, 1):
            register_secret_to_scrub(pat)
            self.state[pat] = {
                "name": f"{role}-PAT-{idx} ({pat[:4]}...{pat[-4:] if len(pat) > 8 else ''})",
                "exhausted_until": 0.0,
                "invalid": False,
            }

    def has_credentials(self) -> bool:
        return bool(self.pats) or (self.app_auth is not None)

    def get_credential(self) -> tuple[str, str]:
        """
        Returns (token_string, human_readable_name).
        Rotates across valid PATs. If all PATs are in cooldown, falls back to GitHub App.
        If all are exhausted, waits until the earliest reset.
        """
        while not STOP.is_set():
            with self._lock:
                now_mono = time.monotonic()

                # 1. Round-robin through available PATs
                available_pats = [
                    p for p in self.pats
                    if not self.state[p]["invalid"] and self.state[p]["exhausted_until"] <= now_mono
                ]

                if available_pats:
                    pat = available_pats[self._index % len(available_pats)]
                    self._index += 1
                    return pat, self.state[pat]["name"]

                # 2. Fall back to GitHub App if PATs are empty or exhausted
                if self.app_auth and not self.app_auth.is_exhausted(now_mono):
                    try:
                        token = self.app_auth.get_token(self.org)
                        return token, f"{self.role}-GitHubApp(ID:{self.app_auth.app_id})"
                    except Exception as exc:
                        logger.error("[%s] GitHub App token generation failed: %s", self.role, exc)
                        self.app_auth.mark_exhausted(60.0)

                # 3. All credentials exhausted: compute earliest reset
                earliest_resets = []
                for p in self.pats:
                    if not self.state[p]["invalid"]:
                        earliest_resets.append(self.state[p]["exhausted_until"])
                if self.app_auth:
                    earliest_resets.append(self.app_auth._exhausted_until)

                if not earliest_resets:
                    raise RuntimeError(f"[{self.role}] All configured credentials are invalid.")

                earliest_time = min(earliest_resets)
                wait_sec = max(2.0, earliest_time - now_mono)

            logger.warning(
                "[%s] All credentials in cooldown/rate-limited. Waiting %.1fs for quota reset...",
                self.role, wait_sec
            )
            STOP.wait(wait_sec)

        raise RuntimeError("Operation interrupted while waiting for credentials.")

    def report_rate_limited(self, token: str, reset_seconds: float = None):
        with self._lock:
            now_mono = time.monotonic()
            cooldown = reset_seconds if reset_seconds is not None else 3600.0
            if token in self.state:
                self.state[token]["exhausted_until"] = now_mono + cooldown
                logger.warning(
                    "[%s] %s exhausted quota. Cooling down for %.0fs.",
                    self.role, self.state[token]["name"], cooldown
                )
            elif self.app_auth:
                self.app_auth.mark_exhausted(cooldown)
                logger.warning("[%s] GitHub App quota exhausted. Cooling down for %.0fs.", self.role, cooldown)

    def report_invalid(self, token: str, reason: str):
        with self._lock:
            if token in self.state:
                self.state[token]["invalid"] = True
                logger.error(
                    "[%s] %s marked PERMANENTLY INVALID (%s). Rotating.",
                    self.role, self.state[token]["name"], reason
                )


# ============================================================
# API UTILITIES & GHES NORMALIZATION
# ============================================================

def normalize_api_url(endpoint: str, path: str) -> str:
    endpoint = endpoint.rstrip("/")
    path = "/" + path.lstrip("/")
    if "api.github.com" in endpoint:
        return endpoint + path
    if not endpoint.endswith("/api/v3"):
        endpoint += "/api/v3"
    return endpoint + path


def api_request(endpoint: str, cred_pool: CredentialPool, path: str, params: dict = None):
    """Robust API request with automatic token rotation upon 401 or 403 rate limits."""
    last_error = None

    for attempt in range(1, MAX_RETRIES + 3):
        if STOP.is_set():
            raise RuntimeError("Interrupted")

        token, token_name = cred_pool.get_credential()
        url = normalize_api_url(endpoint, path)
        if params:
            url += "?" + urllib.parse.urlencode(params)

        req = urllib.request.Request(
            url,
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/vnd.github+json",
                "X-GitHub-Api-Version": "2022-11-28",
                "User-Agent": "secrets-migration-orchestrator",
            },
        )

        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                remaining = resp.headers.get("X-RateLimit-Remaining")
                if remaining and remaining.isdigit() and int(remaining) <= 2:
                    reset = resp.headers.get("X-RateLimit-Reset")
                    reset_wait = max(1.0, int(reset) - time.time()) if reset and reset.isdigit() else 3600.0
                    cred_pool.report_rate_limited(token, reset_wait)
                return json.loads(resp.read().decode("utf-8"))

        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", "replace")[:300]
            headers = exc.headers

            # 401 Unauthorized: Permanently invalidate this token
            if exc.code == 401:
                cred_pool.report_invalid(token, f"HTTP 401: {body}")
                continue

            # 403 / 429 Rate limits
            limited = exc.code == 429 or (
                exc.code == 403 and (
                    headers.get("Retry-After")
                    or headers.get("X-RateLimit-Remaining") == "0"
                    or "rate limit" in body.lower()
                    or "secondary" in body.lower()
                )
            )

            if limited:
                retry_after = headers.get("Retry-After")
                reset = headers.get("X-RateLimit-Reset")
                if retry_after and retry_after.isdigit():
                    wait_sec = float(retry_after)
                elif reset and reset.isdigit():
                    wait_sec = max(1.0, int(reset) - time.time())
                else:
                    wait_sec = 60.0

                cred_pool.report_rate_limited(token, wait_sec)
                last_error = RuntimeError(f"Rate limited on {path} ({token_name}): {body}")
                continue

            if exc.code >= 500:
                last_error = RuntimeError(f"HTTP {exc.code} for {path}: {body}")
                STOP.wait(min(120.0, RETRY_BASE_DELAY * (2 ** (attempt - 1))))
                continue

            raise RuntimeError(f"HTTP {exc.code} for {path}: {body}")

        except Exception as exc:
            last_error = exc
            STOP.wait(min(120.0, RETRY_BASE_DELAY * (2 ** (attempt - 1))))

    raise last_error or RuntimeError(f"Failed to query {path}")


def list_secret_names(endpoint: str, cred_pool: CredentialPool, path: str) -> set:
    names = set()
    page = 1
    while True:
        data = api_request(endpoint, cred_pool, path, {"per_page": 100, "page": page})
        batch = data.get("secrets", [])
        names.update(item["name"].upper() for item in batch)
        if len(batch) < 100:
            break
        page += 1
    return names


# ============================================================
# SHARED STATE & RATE LIMITING
# ============================================================

CSV_LOCK = threading.Lock()
STOP = threading.Event()

ACTIVE_PROCESSES = set()
ACTIVE_LOCK = threading.Lock()

CHECKPOINT_CACHE = {}
CHECKPOINT_LOCK = threading.Lock()

RUNTIME = {
    "source_env": {"SOURCE_PAT"},
    "target_env": {"TARGET_PAT"},
}


class RateLimiter:
    """Shared start-rate limiter to avoid spiking GitHub secondary rate limits."""

    def __init__(self, interval):
        self.interval = interval
        self._lock = threading.Lock()
        self._next_slot = 0.0

    def acquire(self):
        if self.interval <= 0:
            return
        with self._lock:
            now_ = time.monotonic()
            slot = max(now_, self._next_slot)
            self._next_slot = slot + self.interval
        delay = slot - now_
        if delay > 0:
            STOP.wait(delay)


LIMITER = RateLimiter(DELAY_SECONDS)


# ============================================================
# CSV HELPERS & DATA SANITIZATION
# ============================================================

FIELDS = [
    "timestamp",
    "run_id",
    "mode",
    "source_org",
    "source_repo",
    "target_org",
    "target_repo",
    "status",
    "attempts",
    "return_code",
    "duration_seconds",
    "source_secret_count",
    "target_secret_count",
    "missing_secrets",
    "details",
]

SUMMARY_FIELDS = [
    "run_id",
    "started_at",
    "finished_at",
    "duration_minutes",
    "mode",
    "source_org",
    "target_org",
    "dry_run",
    "input_mappings",
    "invalid_or_duplicate_rows",
    "skipped_already_completed",
    "skipped_failed_by_config",
    "selected_this_run",
    "succeeded_verified",
    "succeeded_unverified",
    "dry_run_ok",
    "verify_failed",
    "precheck_failed",
    "failed",
    "dry_run_failed",
    "not_started",
    "interrupted",
    "success_percentage_this_run",
    "overall_completed",
    "overall_outstanding",
]


def now():
    return datetime.now(timezone.utc).isoformat()


def csv_safe(val):
    if isinstance(val, str) and val[:1] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + val
    return val


def append_result_row(job, result):
    row = {
        "timestamp": now(),
        "run_id": RUN_ID,
        "mode": MODE,
        "source_org": SOURCE_ORG,
        "source_repo": job["source_repo"],
        "target_org": TARGET_ORG,
        "target_repo": job["target_repo"],
        "attempts": 0,
        "return_code": "",
        "duration_seconds": 0,
        "source_secret_count": "",
        "target_secret_count": "",
        "missing_secrets": "",
        "details": "",
    }
    row.update(result)
    row["details"] = csv_safe(row["details"])
    row["missing_secrets"] = csv_safe(row["missing_secrets"])

    with CSV_LOCK:
        write_header = not RESULT_CSV.exists() or RESULT_CSV.stat().st_size == 0
        with RESULT_CSV.open("a", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=FIELDS, extrasaction="ignore", restval="")
            if write_header:
                writer.writeheader()
            writer.writerow(row)
            f.flush()

    # Update checkpoint in memory
    key = (
        MODE,
        SOURCE_ORG.lower(),
        job["source_repo"].lower(),
        TARGET_ORG.lower(),
        job["target_repo"].lower(),
    )
    with CHECKPOINT_LOCK:
        CHECKPOINT_CACHE[key] = row

    return row


def flush_checkpoint():
    with CHECKPOINT_LOCK:
        rows = list(CHECKPOINT_CACHE.values())
    if not rows:
        return
    tmp = CHECKPOINT_CSV.with_suffix(".tmp")
    with tmp.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS, extrasaction="ignore", restval="")
        writer.writeheader()
        writer.writerows(rows)
    os.replace(tmp, CHECKPOINT_CSV)


# ============================================================
# INITIAL VALIDATION & DISCOVERY
# ============================================================

def setup_credential_pools() -> tuple[CredentialPool, CredentialPool]:
    # 1. Parse PAT lists
    source_pats = env_list("SOURCE_PATS", "SOURCE_PAT")
    target_pats = env_list("TARGET_PATS", "TARGET_PAT")

    # 2. Parse GitHub App configurations
    src_app_id = env_str("SOURCE_APP_ID", env_str("APP_ID"))
    src_app_key = env_str("SOURCE_APP_PRIVATE_KEY", env_str("APP_PRIVATE_KEY"))
    src_app_key_path = env_str("SOURCE_APP_PRIVATE_KEY_PATH", env_str("APP_PRIVATE_KEY_PATH"))
    src_app_inst = env_str("SOURCE_APP_INSTALLATION_ID", env_str("APP_INSTALLATION_ID"))

    if not src_app_key and src_app_key_path and Path(src_app_key_path).is_file():
        src_app_key = Path(src_app_key_path).read_text(encoding="utf-8")

    src_app = GitHubAppAuth(src_app_id, src_app_key, SOURCE_ENDPOINT, src_app_inst) if (src_app_id and src_app_key) else None

    tgt_app_id = env_str("TARGET_APP_ID", env_str("APP_ID"))
    tgt_app_key = env_str("TARGET_APP_PRIVATE_KEY", env_str("APP_PRIVATE_KEY"))
    tgt_app_key_path = env_str("TARGET_APP_PRIVATE_KEY_PATH", env_str("APP_PRIVATE_KEY_PATH"))
    tgt_app_inst = env_str("TARGET_APP_INSTALLATION_ID", env_str("APP_INSTALLATION_ID"))

    if not tgt_app_key and tgt_app_key_path and Path(tgt_app_key_path).is_file():
        tgt_app_key = Path(tgt_app_key_path).read_text(encoding="utf-8")

    tgt_app = GitHubAppAuth(tgt_app_id, tgt_app_key, TARGET_ENDPOINT, tgt_app_inst) if (tgt_app_id and tgt_app_key) else None

    source_pool = CredentialPool("SOURCE", SOURCE_ORG, SOURCE_ENDPOINT, source_pats, src_app)
    target_pool = CredentialPool("TARGET", TARGET_ORG, TARGET_ENDPOINT, target_pats, tgt_app)

    if not source_pool.has_credentials():
        raise ValueError("Missing SOURCE credentials. Supply SOURCE_PATS / SOURCE_PAT or SOURCE_APP_ID + Private Key.")
    if not target_pool.has_credentials():
        raise ValueError("Missing TARGET credentials. Supply TARGET_PATS / TARGET_PAT or TARGET_APP_ID + Private Key.")

    return source_pool, target_pool


def validate_environment(source_pool: CredentialPool, target_pool: CredentialPool):
    if not SOURCE_ORG or not TARGET_ORG:
        raise ValueError("SOURCE_ORG and TARGET_ORG must be configured in .env.")

    if SOURCE_ORG.lower() == TARGET_ORG.lower() and SOURCE_ENDPOINT.lower() == TARGET_ENDPOINT.lower():
        raise ValueError("Source and target organizations must be different on the same endpoint.")

    if not ORG_TO_ORG and not INPUT_CSV.is_file():
        raise FileNotFoundError(f"Input CSV not found: {INPUT_CSV}")

    # Check GitHub CLI
    res = subprocess.run(["gh", "--version"], capture_output=True, text=True, check=False, timeout=15)
    if res.returncode != 0:
        raise RuntimeError("GitHub CLI (gh) is not installed.")

    # Check extension
    res = subprocess.run(["gh", "secrets-migrator", "--help"], capture_output=True, text=True, check=False, timeout=30)
    if res.returncode != 0:
        raise RuntimeError("GitHub extension 'gh secrets-migrator' is not installed.")

    help_text = res.stdout + res.stderr
    for flag in ["--source-org", "--source-repo", "--target-org"]:
        if flag not in help_text:
            raise RuntimeError(f"Installed 'gh secrets-migrator' does not advertise required flag: {flag}")

    # Detect supported PAT env vars
    for name in set(re.findall(r"\b[A-Z][A-Z0-9_]*PAT\b", help_text)):
        if "SOURCE" in name:
            RUNTIME["source_env"].add(name)
        elif "TARGET" in name or name == "GH_PAT":
            RUNTIME["target_env"].add(name)

    # Validate API connectivity and secret scope access
    logger.info("Validating SOURCE and TARGET API connectivity and secret permissions...")
    api_request(SOURCE_ENDPOINT, source_pool, f"/orgs/{urllib.parse.quote(SOURCE_ORG)}")
    api_request(TARGET_ENDPOINT, target_pool, f"/orgs/{urllib.parse.quote(TARGET_ORG)}")

    try:
        api_request(SOURCE_ENDPOINT, source_pool, f"/orgs/{urllib.parse.quote(SOURCE_ORG)}/actions/secrets", {"per_page": 1})
        api_request(TARGET_ENDPOINT, target_pool, f"/orgs/{urllib.parse.quote(TARGET_ORG)}/actions/secrets", {"per_page": 1})
    except Exception as exc:
        logger.warning("Secret API permission pre-check notice (might require repo-level scope): %s", exc)

    logger.info("Configuration and credentials verified successfully.")


# ============================================================
# CSV INPUT PARSING & RESUME LOGIC
# ============================================================

def load_repositories():
    valid = []
    invalid = []
    seen = set()

    with INPUT_CSV.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        reader.fieldnames = [(n or "").strip().lower() for n in (reader.fieldnames or [])]

        if not {"source_repo", "target_repo"}.issubset(set(reader.fieldnames)):
            raise ValueError("CSV must contain 'source_repo' and 'target_repo' columns.")

        for line, row in enumerate(reader, start=2):
            s = (row.get("source_repo") or "").strip()
            t = (row.get("target_repo") or "").strip()
            if not s and not t:
                continue

            if not s or not t:
                invalid.append({"source_repo": s, "target_repo": t, "reason": f"Line {line}: missing repo name"})
                continue

            if not re.fullmatch(r"[A-Za-z0-9_.-]+", s) or not re.fullmatch(r"[A-Za-z0-9_.-]+", t):
                invalid.append({"source_repo": s, "target_repo": t, "reason": f"Line {line}: invalid characters"})
                continue

            key = (s.lower(), t.lower())
            if key in seen:
                invalid.append({"source_repo": s, "target_repo": t, "reason": f"Line {line}: duplicate mapping"})
                continue

            seen.add(key)
            valid.append({"source_repo": s, "target_repo": t})

    return valid, invalid


def init_checkpoint_and_filter(jobs: list):
    global CHECKPOINT_CACHE
    if RESULT_CSV.is_file():
        with RESULT_CSV.open("r", encoding="utf-8-sig", newline="") as f:
            for row in csv.DictReader(f):
                status = row.get("status") or ""
                if status in ("DRY_RUN", "DRY_RUN_FAILED", "SKIPPED"):
                    continue
                key = (
                    (row.get("mode") or "").lower(),
                    (row.get("source_org") or "").lower(),
                    (row.get("source_repo") or "").lower(),
                    (row.get("target_org") or "").lower(),
                    (row.get("target_repo") or "").lower(),
                )
                CHECKPOINT_CACHE[key] = row

    pending = []
    skipped_completed = 0
    skipped_failed = 0

    for job in jobs:
        key = (MODE, SOURCE_ORG.lower(), job["source_repo"].lower(), TARGET_ORG.lower(), job["target_repo"].lower())
        prev_status = CHECKPOINT_CACHE.get(key, {}).get("status", "")

        if prev_status in ("SUCCESS", "SUCCESS_UNVERIFIED") and SKIP_SUCCESS:
            skipped_completed += 1
            continue
        if prev_status in ("FAILED", "VERIFY_FAILED", "PRECHECK_FAILED") and not RETRY_FAILED:
            skipped_failed += 1
            continue

        pending.append(job)

    if PILOT_LIMIT and len(pending) > PILOT_LIMIT:
        logger.warning("PILOT_LIMIT=%s: processing only first %s repos.", PILOT_LIMIT, PILOT_LIMIT)
        pending = pending[:PILOT_LIMIT]

    return pending, skipped_completed, skipped_failed


# ============================================================
# CLI SUBPROCESS EXECUTION
# ============================================================

TRANSIENT_REGEX = re.compile(
    r"rate.?limit|secondary rate|abuse detection|HTTP.?429|HTTP.?50[0234]|"
    r"timed?\s*out|temporarily unavailable|connection (reset|aborted)|TLS handshake",
    re.IGNORECASE,
)

RATE_LIMIT_REGEX = re.compile(r"rate.?limit|secondary rate|abuse detection|HTTP.?429", re.IGNORECASE)


def build_command(source_repo, target_repo, s_token, t_token):
    cmd = [
        "gh", "secrets-migrator",
        "--source-org", SOURCE_ORG,
        "--source-repo", source_repo,
        "--target-org", TARGET_ORG,
        "--source-endpoint", SOURCE_ENDPOINT,
        "--target-endpoint", TARGET_ENDPOINT,
    ]
    if target_repo:
        cmd.extend(["--target-repo", target_repo])
    if ORG_TO_ORG:
        cmd.append("--org-to-org")
    if SKIP_OVERWRITE:
        cmd.append("--skip-overwrite")
    if PAT_MODE == "flag":
        cmd.extend(["--source-pat", s_token, "--target-pat", t_token])
    cmd.append("--verbose")
    return cmd


def run_cli_subprocess(cmd, s_token, t_token):
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8:replace"
    env["PYTHONUTF8"] = "1"
    env["PYTHONLEGACYWINDOWSSTDIO"] = "0"

    env.pop("GITHUB_TOKEN", None)
    env.pop("GH_TOKEN", None)
    env["GH_PROMPT_DISABLED"] = "1"
    env["GH_NO_UPDATE_NOTIFIER"] = "1"

    for k in RUNTIME["source_env"]:
        env[k] = s_token
    for k in RUNTIME["target_env"]:
        env[k] = t_token

    # On Windows, wrap with chcp 65001 so PyInstaller binaries (gh-secrets-migrator)
    # never inherit legacy cp1252, preventing UnicodeEncodeErrors with emojis
    if sys.platform == "win32":
        cmd_str = subprocess.list2cmdline(cmd)
        full_cmd = f"chcp 65001 >nul && {cmd_str}"
        process = subprocess.Popen(
            full_cmd,
            shell=True,
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
    else:
        process = subprocess.Popen(
            cmd,
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
        )

    with ACTIVE_LOCK:
        ACTIVE_PROCESSES.add(process)

    try:
        stdout, stderr = process.communicate(timeout=COMMAND_TIMEOUT or None)
    except subprocess.TimeoutExpired:
        process.kill()
        process.communicate()
        raise
    finally:
        with ACTIVE_LOCK:
            ACTIVE_PROCESSES.discard(process)

    return process.returncode, stdout, stderr


# ============================================================
# MIGRATION WORKER
# ============================================================

def verify_migrated_secrets(source_repo, target_repo, source_pool, target_pool):
    src_path = f"/orgs/{urllib.parse.quote(SOURCE_ORG)}/actions/secrets" if ORG_TO_ORG else f"/repos/{urllib.parse.quote(SOURCE_ORG)}/{urllib.parse.quote(source_repo)}/actions/secrets"
    tgt_path = f"/orgs/{urllib.parse.quote(TARGET_ORG)}/actions/secrets" if ORG_TO_ORG else f"/repos/{urllib.parse.quote(TARGET_ORG)}/{urllib.parse.quote(target_repo)}/actions/secrets"

    try:
        source_names = list_secret_names(SOURCE_ENDPOINT, source_pool, src_path)
    except Exception as exc:
        return "UNAVAILABLE", None, None, [], f"Source secrets list error: {exc}"

    if not source_names:
        return "VERIFIED", 0, 0, [], "Source has no secrets; nothing to verify."

    deadline = time.monotonic() + VERIFY_TIMEOUT
    while True:
        try:
            target_names = list_secret_names(TARGET_ENDPOINT, target_pool, tgt_path)
        except Exception as exc:
            return "UNAVAILABLE", len(source_names), None, [], f"Target secrets list error: {exc}"

        missing = sorted(source_names - target_names)
        if not missing:
            return "VERIFIED", len(source_names), len(target_names), [], "All source secret names exist on target."

        if STOP.is_set():
            return "INTERRUPTED", len(source_names), len(target_names), missing, "Interrupted."

        if time.monotonic() >= deadline:
            return "MISSING", len(source_names), len(target_names), missing, f"{len(missing)} secrets missing after timeout."

        STOP.wait(VERIFY_INTERVAL)


def execute_migration_job(job, source_pool: CredentialPool, target_pool: CredentialPool):
    LIMITER.acquire()
    if STOP.is_set():
        return None

    started = time.monotonic()
    s_repo = job["source_repo"]
    t_repo = job["target_repo"]

    # Pre-checks
    if not ORG_TO_ORG and (DRY_RUN or PRECHECK_REPOS):
        try:
            api_request(SOURCE_ENDPOINT, source_pool, f"/repos/{urllib.parse.quote(SOURCE_ORG)}/{urllib.parse.quote(s_repo)}")
            try:
                api_request(TARGET_ENDPOINT, target_pool, f"/repos/{urllib.parse.quote(TARGET_ORG)}/{urllib.parse.quote(t_repo)}")
            except Exception as exc:
                if REQUIRE_TARGET_REPO:
                    raise
        except Exception as exc:
            status = "DRY_RUN_FAILED" if DRY_RUN else "PRECHECK_FAILED"
            logger.error("%s: %s -> %s | %s", status, s_repo, t_repo, exc)
            return append_result_row(job, {
                "status": status,
                "duration_seconds": round(time.monotonic() - started, 2),
                "details": redact(str(exc)),
            })

    if DRY_RUN:
        return append_result_row(job, {
            "status": "DRY_RUN",
            "duration_seconds": round(time.monotonic() - started, 2),
            "details": "Pre-checks passed. Dry-run only.",
        })

    # Migration Loop with Token Failover
    attempts = 0
    return_code = ""
    last_error = ""

    for attempt in range(1, MAX_RETRIES + 2):
        if STOP.is_set():
            last_error = "Interrupted before CLI execution."
            break

        attempts = attempt
        s_token, s_name = source_pool.get_credential()
        t_token, t_name = target_pool.get_credential()

        cmd = build_command(s_repo, t_repo, s_token, t_token)
        logger.info("[%s/%s] Migrating %s -> %s (using %s, %s)", attempt, MAX_RETRIES + 1, s_repo, t_repo, s_name, t_name)

        try:
            return_code, stdout, stderr = run_cli_subprocess(cmd, s_token, t_token)
        except subprocess.TimeoutExpired:
            return_code = "TIMEOUT"
            last_error = f"CLI timed out after {COMMAND_TIMEOUT}s."
            break
        except Exception as exc:
            return_code = ""
            last_error = redact(f"CLI execution failed: {exc}")
            transient = True
        else:
            if return_code == 0:
                last_error = ""
                break
            combined = f"{stderr or ''}\n{stdout or ''}".strip()
            last_error = redact(combined) or "CLI failure"
            transient = bool(TRANSIENT_REGEX.search(last_error))

            # Rotate token immediately if rate limited
            if RATE_LIMIT_REGEX.search(last_error):
                source_pool.report_rate_limited(s_token, 60.0)
                target_pool.report_rate_limited(t_token, 60.0)
                continue

        if not transient or attempt > MAX_RETRIES:
            break

        backoff = min(RETRY_MAX_DELAY, RETRY_BASE_DELAY * (2 ** (attempt - 1))) + random.uniform(0, 1.0)
        logger.warning("%s transient error. Retrying in %.1fs...", s_repo, backoff)
        if STOP.wait(backoff):
            break

    # Evaluation
    if return_code != 0:
        logger.error("FAILED: %s -> %s | %s", s_repo, t_repo, last_error)
        return append_result_row(job, {
            "status": "FAILED",
            "attempts": attempts,
            "return_code": return_code,
            "duration_seconds": round(time.monotonic() - started, 2),
            "details": last_error,
        })

    # Verification
    if not VERIFY_SECRETS:
        return append_result_row(job, {
            "status": "SUCCESS_UNVERIFIED",
            "attempts": attempts,
            "return_code": return_code,
            "duration_seconds": round(time.monotonic() - started, 2),
            "details": "CLI exit code 0; verification disabled.",
        })

    v_state, s_cnt, t_cnt, missing, detail = verify_migrated_secrets(s_repo, t_repo, source_pool, target_pool)
    v_status = "SUCCESS" if v_state == "VERIFIED" else ("SUCCESS_UNVERIFIED" if v_state == "UNAVAILABLE" else "VERIFY_FAILED")

    if v_status == "VERIFY_FAILED":
        logger.error("VERIFY_FAILED: %s -> %s | missing: %s", s_repo, t_repo, ";".join(missing))

    return append_result_row(job, {
        "status": v_status,
        "attempts": attempts,
        "return_code": return_code,
        "duration_seconds": round(time.monotonic() - started, 2),
        "source_secret_count": "" if s_cnt is None else s_cnt,
        "target_secret_count": "" if t_cnt is None else t_cnt,
        "missing_secrets": ";".join(missing),
        "details": detail,
    })


# ============================================================
# CONTINUOUS WORKER ENGINE (NO BATCH STALLS)
# ============================================================

def run_orchestration(jobs: list, source_pool: CredentialPool, target_pool: CredentialPool):
    stats = Counter()
    total = len(jobs)
    if total == 0:
        logger.info("No pending migrations to run.")
        return stats, False

    queue = iter(jobs)
    in_flight = {}
    completed = 0
    interrupted = False
    started = time.monotonic()
    last_flush = time.monotonic()

    def process_wrapper(job):
        try:
            return execute_migration_job(job, source_pool, target_pool)
        except Exception as exc:
            logger.exception("Unhandled error migrating %s: %s", job["source_repo"], exc)
            return append_result_row(job, {"status": "FAILED", "details": redact(str(exc))})

    executor = ThreadPoolExecutor(max_workers=MAX_WORKERS, thread_name_prefix="migrator")

    try:
        try:
            while True:
                while not STOP.is_set() and len(in_flight) < MAX_WORKERS:
                    job = next(queue, None)
                    if job is None:
                        break
                    in_flight[executor.submit(process_wrapper, job)] = job

                if not in_flight:
                    break

                done, _ = wait(list(in_flight), timeout=1.0, return_when=FIRST_COMPLETED)
                for fut in done:
                    in_flight.pop(fut)
                    row = fut.result()
                    if row is None:
                        stats["NOT_STARTED"] += 1
                        continue

                    stats[row["status"]] += 1
                    completed += 1

                    # Periodic checkpoint flush
                    if time.monotonic() - last_flush > 30.0 or (completed % 25 == 0):
                        flush_checkpoint()
                        last_flush = time.monotonic()

                    elapsed = time.monotonic() - started
                    rem = total - completed - stats["NOT_STARTED"]
                    eta_min = (elapsed / completed * rem) / 60 if completed else 0.0
                    logger.info(
                        "Progress: %.1f%% | %s/%s | OK: %s | Problems: %s | ETA: %.1f min",
                        (completed / total) * 100, completed, total,
                        stats["SUCCESS"] + stats["SUCCESS_UNVERIFIED"] + stats["DRY_RUN"],
                        stats["FAILED"] + stats["VERIFY_FAILED"] + stats["PRECHECK_FAILED"],
                        eta_min,
                    )

        except KeyboardInterrupt:
            interrupted = True
            STOP.set()
            logger.warning("Interrupt received. Stopping new jobs. Waiting for %s in-flight jobs (Ctrl-C again to kill)...", len(in_flight))
            try:
                while in_flight:
                    done, _ = wait(list(in_flight), timeout=1.0, return_when=FIRST_COMPLETED)
                    for fut in done:
                        in_flight.pop(fut)
            except KeyboardInterrupt:
                logger.warning("Second interrupt: killing active CLI subprocesses.")
                with ACTIVE_LOCK:
                    for p in list(ACTIVE_PROCESSES):
                        try:
                            p.terminate()
                        except OSError:
                            pass
    finally:
        executor.shutdown(wait=True)
        flush_checkpoint()

    stats["NOT_STARTED"] += sum(1 for _ in queue)
    return stats, interrupted


# ============================================================
# SUMMARY & REPORTING
# ============================================================

def write_summary_report(started_at, started_clock, all_jobs, invalid, skipped_comp, skipped_fail, selected, stats, interrupted):
    ok_count = stats["SUCCESS"] + stats["SUCCESS_UNVERIFIED"] + stats["DRY_RUN"]
    with CHECKPOINT_LOCK:
        total_completed = sum(1 for v in CHECKPOINT_CACHE.values() if v.get("status") in ("SUCCESS", "SUCCESS_UNVERIFIED"))

    row = {
        "run_id": RUN_ID,
        "started_at": started_at,
        "finished_at": now(),
        "duration_minutes": round((time.monotonic() - started_clock) / 60, 2),
        "mode": MODE,
        "source_org": SOURCE_ORG,
        "target_org": TARGET_ORG,
        "dry_run": DRY_RUN,
        "input_mappings": len(all_jobs),
        "invalid_or_duplicate_rows": len(invalid),
        "skipped_already_completed": skipped_comp,
        "skipped_failed_by_config": skipped_fail,
        "selected_this_run": selected,
        "succeeded_verified": stats["SUCCESS"],
        "succeeded_unverified": stats["SUCCESS_UNVERIFIED"],
        "dry_run_ok": stats["DRY_RUN"],
        "verify_failed": stats["VERIFY_FAILED"],
        "precheck_failed": stats["PRECHECK_FAILED"],
        "failed": stats["FAILED"],
        "dry_run_failed": stats["DRY_RUN_FAILED"],
        "not_started": stats["NOT_STARTED"],
        "interrupted": interrupted,
        "success_percentage_this_run": round(ok_count / selected * 100, 2) if selected else 0,
        "overall_completed": total_completed,
        "overall_outstanding": max(0, len(all_jobs) - total_completed),
    }

    with CSV_LOCK:
        write_header = not SUMMARY_CSV.exists() or SUMMARY_CSV.stat().st_size == 0
        with SUMMARY_CSV.open("a", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=SUMMARY_FIELDS, extrasaction="ignore")
            if write_header:
                writer.writeheader()
            writer.writerow(row)

    return row


# ============================================================
# MAIN ENTRYPOINT
# ============================================================

def main():
    started_at = now()
    started_clock = time.monotonic()

    try:
        source_pool, target_pool = setup_credential_pools()
        validate_environment(source_pool, target_pool)

        if ORG_TO_ORG:
            all_jobs = [{"source_repo": ORG_SOURCE_REPO, "target_repo": ORG_SOURCE_REPO}]
            invalid = []
        else:
            all_jobs, invalid = load_repositories()

        for inv in invalid:
            append_result_row(
                {"source_repo": inv["source_repo"], "target_repo": inv["target_repo"]},
                {"status": "SKIPPED", "details": inv["reason"]}
            )

        pending, skipped_comp, skipped_fail = init_checkpoint_and_filter(all_jobs)
        logger.info(
            "Jobs: %s total | %s skipped completed | %s skipped failed | %s pending this run",
            len(all_jobs), skipped_comp, skipped_fail, len(pending)
        )

        stats, interrupted = run_orchestration(pending, source_pool, target_pool)
        flush_checkpoint()

        summary = write_summary_report(
            started_at, started_clock, all_jobs, invalid,
            skipped_comp, skipped_fail, len(pending),
            stats, interrupted
        )

        logger.info("=" * 60)
        logger.info("RUN %s", "INTERRUPTED" if interrupted else "COMPLETED")
        logger.info("Selected: %s | Verified: %s | Unverified: %s", len(pending), stats["SUCCESS"], stats["SUCCESS_UNVERIFIED"])
        logger.info("Failed: %s | Verify Failed: %s | Precheck Failed: %s", stats["FAILED"], stats["VERIFY_FAILED"], stats["PRECHECK_FAILED"])
        logger.info("Overall: %s completed, %s outstanding", summary["overall_completed"], summary["overall_outstanding"])
        logger.info("Reports: %s | %s", RESULT_CSV, CHECKPOINT_CSV)

        if interrupted:
            return 130
        failed_count = stats["FAILED"] + stats["VERIFY_FAILED"] + stats["PRECHECK_FAILED"] + stats["DRY_RUN_FAILED"]
        return 1 if failed_count else 0

    except KeyboardInterrupt:
        logger.warning("Interrupted by user. Progress saved.")
        return 130
    except Exception:
        logger.exception("Fatal orchestration error.")
        return 2


if __name__ == "__main__":
    sys.exit(main())