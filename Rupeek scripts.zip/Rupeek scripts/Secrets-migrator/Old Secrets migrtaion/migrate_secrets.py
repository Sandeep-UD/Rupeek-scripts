#!/usr/bin/env python3
"""
Bulk GitHub secrets migration orchestrator.

Modes:
  1. Repository-to-repository secrets migration
  2. Organization-to-organization secrets migration

Requirements:
  Python 3.10+
  pip install python-dotenv

Prerequisites:
  GitHub CLI installed and authenticated/available
  gh-secrets-migrator extension installed
"""

import concurrent.futures
import csv
import logging
import os
import re
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

from dotenv import load_dotenv


BASE_DIR = Path(__file__).resolve().parent
ENV_FILE = BASE_DIR / ".env"
INPUT_CSV = BASE_DIR / "repos.csv"
OUTPUT_CSV = BASE_DIR / "migration_results.csv"
ERROR_LOG = BASE_DIR / "migration_errors.log"

load_dotenv(ENV_FILE)

SOURCE_PAT = os.getenv("SOURCE_PAT", "").strip()
TARGET_PAT = os.getenv("TARGET_PAT", "").strip()
SOURCE_ORG = os.getenv("SOURCE_ORG", "").strip()
TARGET_ORG = os.getenv("TARGET_ORG", "").strip()
ORG_SOURCE_REPO = os.getenv("ORG_SOURCE_REPO", ".github").strip()

ORG_TO_ORG = os.getenv("ORG_TO_ORG", "false").lower() == "true"
SKIP_OVERWRITE = os.getenv("SKIP_OVERWRITE", "true").lower() == "true"
DRY_RUN = os.getenv("DRY_RUN", "true").lower() == "true"

SOURCE_ENDPOINT = os.getenv(
    "SOURCE_ENDPOINT", "https://api.github.com"
).strip()
TARGET_ENDPOINT = os.getenv(
    "TARGET_ENDPOINT", "https://api.github.com"
).strip()

DELAY_SECONDS = max(0, int(os.getenv("DELAY_SECONDS", "2")))
MAX_RETRIES = max(0, int(os.getenv("MAX_RETRIES", "3")))
MAX_WORKERS = max(1, int(os.getenv("MAX_WORKERS", "1")))

RESULT_FIELDS = [
    "timestamp",
    "mode",
    "source_org",
    "source_repo",
    "target_org",
    "target_repo",
    "status",
    "attempts",
    "return_code",
    "duration_seconds",
    "details",
]

# Never log tokens or token-bearing command arguments.
logger = logging.getLogger("secrets_migration")
logger.setLevel(logging.INFO)
logger.handlers.clear()

formatter = logging.Formatter(
    "%(asctime)s | %(levelname)s | %(message)s"
)

file_handler = logging.FileHandler(ERROR_LOG, encoding="utf-8")
file_handler.setFormatter(formatter)
file_handler.setLevel(logging.ERROR)

console_handler = logging.StreamHandler(sys.stdout)
console_handler.setFormatter(formatter)
console_handler.setLevel(logging.INFO)

logger.addHandler(file_handler)
logger.addHandler(console_handler)


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def validate_configuration():
    """Validate required settings and CLI availability."""

    missing = []

    if not SOURCE_PAT:
        missing.append("SOURCE_PAT")

    if not TARGET_PAT:
        missing.append("TARGET_PAT")

    if not SOURCE_ORG:
        missing.append("SOURCE_ORG")

    if not TARGET_ORG:
        missing.append("TARGET_ORG")

    if ORG_TO_ORG and not ORG_SOURCE_REPO:
        missing.append("ORG_SOURCE_REPO")

    if missing:
        raise ValueError(
            "Missing required .env settings: " + ", ".join(missing)
        )

    if not ORG_TO_ORG and not INPUT_CSV.is_file():
        raise FileNotFoundError(f"Input CSV not found: {INPUT_CSV}")

    # Validate GitHub CLI availability.
    result = subprocess.run(
        ["gh", "--version"],
        capture_output=True,
        text=True,
        timeout=15,
        check=False,
    )

    if result.returncode != 0:
        raise RuntimeError("GitHub CLI is not available.")

    result = subprocess.run(
        ["gh", "secrets-migrator", "--help"],
        capture_output=True,
        text=True,
        timeout=30,
        check=False,
    )

    if result.returncode != 0:
        raise RuntimeError(
            "gh secrets-migrator is unavailable. "
            "Install the extension and verify its --help output."
        )

    help_text = result.stdout + result.stderr

    required_flags = [
        "--source-org",
        "--source-repo",
        "--target-org",
        "--source-pat",
        "--target-pat",
    ]

    # These checks prevent silently using a different CLI interface.
    for flag in required_flags:
        if flag not in help_text:
            raise RuntimeError(
                f"The installed extension help does not advertise {flag}. "
                "Check the installed extension/version before proceeding."
            )

    if ORG_TO_ORG and "--org-to-org" not in help_text:
        raise RuntimeError(
            "The installed extension does not advertise --org-to-org."
        )

    logger.info("Configuration validated.")
    logger.info("Mode: %s", "org-to-org" if ORG_TO_ORG else "repo-to-repo")
    logger.info("Dry run: %s", DRY_RUN)


def load_repo_rows():
    """Stream repository mappings and validate each row."""

    seen = set()

    with INPUT_CSV.open(
        "r", encoding="utf-8-sig", newline=""
    ) as csv_file:
        reader = csv.DictReader(csv_file)

        required = {"source_repo", "target_repo"}
        headers = set(reader.fieldnames or [])

        if not required.issubset(headers):
            raise ValueError(
                "repos.csv must contain source_repo,target_repo headers."
            )

        for line_number, row in enumerate(reader, start=2):
            source_repo = (row.get("source_repo") or "").strip()
            target_repo = (row.get("target_repo") or "").strip()

            if not source_repo and not target_repo:
                continue

            if not source_repo or not target_repo:
                yield {
                    "line_number": line_number,
                    "source_repo": source_repo,
                    "target_repo": target_repo,
                    "invalid": "Missing source_repo or target_repo",
                }
                continue

            # Avoid accidentally running the same mapping twice.
            mapping = (source_repo.lower(), target_repo.lower())

            if mapping in seen:
                yield {
                    "line_number": line_number,
                    "source_repo": source_repo,
                    "target_repo": target_repo,
                    "invalid": "Duplicate repository mapping",
                }
                continue

            seen.add(mapping)

            yield {
                "line_number": line_number,
                "source_repo": source_repo,
                "target_repo": target_repo,
                "invalid": "",
            }


def build_command(source_repo, target_repo=None):
    """Build the CLI command without placing PATs in command arguments."""

    command = [
        "gh",
        "secrets-migrator",
        "--source-org", SOURCE_ORG,
        "--source-repo", source_repo,
        "--target-org", TARGET_ORG,
        "--source-endpoint", SOURCE_ENDPOINT,
        "--target-endpoint", TARGET_ENDPOINT,
    ]

    if target_repo:
        command.extend(["--target-repo", target_repo])

    if ORG_TO_ORG:
        command.append("--org-to-org")

    if SKIP_OVERWRITE:
        command.append("--skip-overwrite")

    command.append("--verbose")

    return command


def run_migration(source_repo, target_repo=None):
    """Run a migration and retry transient failures."""

    command = build_command(source_repo, target_repo)

    # The extension supports PAT environment variables. This avoids
    # exposing credentials in the subprocess command-line arguments.
    child_env = os.environ.copy()
    child_env["SOURCE_PAT"] = SOURCE_PAT
    child_env["TARGET_PAT"] = TARGET_PAT

    # Prevent inherited shared credentials from overriding expectations.
    child_env.pop("GITHUB_TOKEN", None)
    child_env.pop("GH_SOURCE_PAT", None)
    child_env.pop("GH_PAT", None)

    if DRY_RUN:
        logger.info(
            "[DRY RUN] Would migrate %s/%s -> %s/%s",
            SOURCE_ORG,
            source_repo,
            TARGET_ORG,
            target_repo or source_repo,
        )

        return {
            "status": "DRY_RUN",
            "attempts": 0,
            "return_code": "",
            "duration_seconds": 0,
            "details": "Command validated; migration not executed",
        }

    started = time.monotonic()
    last_code = ""
    last_error = ""

    # Match transient conditions only; permanent permission errors
    # should be reported instead of retried repeatedly.
    transient_patterns = re.compile(
        r"rate.?limit|secondary rate|abuse detection|"
        r"HTTP.?429|HTTP.?500|HTTP.?502|HTTP.?503|HTTP.?504|"
        r"timed?\s*out|temporarily unavailable|"
        r"connection reset|connection aborted|"
        r"TLS handshake|server error",
        re.IGNORECASE,
    )

    for attempt in range(1, MAX_RETRIES + 2):
        try:
            logger.info(
                "Attempt %s/%s: %s/%s -> %s/%s",
                attempt,
                MAX_RETRIES + 1,
                SOURCE_ORG,
                source_repo,
                TARGET_ORG,
                target_repo or source_repo,
            )

            result = subprocess.run(
                command,
                env=child_env,
                capture_output=True,
                text=True,
                timeout=None,
                check=False,
            )

            last_code = result.returncode

            if result.returncode == 0:
                duration = round(time.monotonic() - started, 2)
                logger.info(
                    "Migration command completed successfully for %s.",
                    source_repo,
                )

                return {
                    "status": "SUCCESS",
                    "attempts": attempt,
                    "return_code": last_code,
                    "duration_seconds": duration,
                    "details": "CLI returned exit code 0; verify target secrets",
                }

            # Scrub credentials if a CLI happens to echo them.
            last_error = result.stderr or result.stdout or "Unknown CLI error"

            for token in (SOURCE_PAT, TARGET_PAT):
                if token:
                    last_error = last_error.replace(token, "[REDACTED]")

            # Keep error reports manageable.
            last_error = last_error[-3000:]

            retryable = bool(transient_patterns.search(last_error))

            if not retryable or attempt > MAX_RETRIES:
                break

            wait_seconds = min(300, DELAY_SECONDS * (2 ** (attempt - 1)))

            logger.warning(
                "Transient CLI failure. Retrying in %s seconds.",
                wait_seconds,
            )
            time.sleep(wait_seconds)

        except OSError as exc:
            last_error = str(exc)
            last_code = ""

            if attempt > MAX_RETRIES:
                break

            wait_seconds = min(300, DELAY_SECONDS * (2 ** (attempt - 1)))
            logger.warning(
                "Process execution error. Retrying in %s seconds.",
                wait_seconds,
            )
            time.sleep(wait_seconds)

    duration = round(time.monotonic() - started, 2)

    logger.error(
        "Migration failed: %s/%s -> %s/%s | %s",
        SOURCE_ORG,
        source_repo,
        TARGET_ORG,
        target_repo or source_repo,
        last_error,
    )

    return {
        "status": "FAILED",
        "attempts": attempt,
        "return_code": last_code,
        "duration_seconds": duration,
        "details": last_error,
    }


_csv_lock = threading.Lock()


def append_result(result):
    """Append each result immediately to the CSV report."""

    # Serialize writes since multiple worker threads may call this concurrently.
    with _csv_lock:
        write_header = not OUTPUT_CSV.exists() or OUTPUT_CSV.stat().st_size == 0

        with OUTPUT_CSV.open(
            "a", encoding="utf-8-sig", newline=""
        ) as csv_file:
            writer = csv.DictWriter(
                csv_file,
                fieldnames=RESULT_FIELDS,
                extrasaction="ignore",
            )

            if write_header:
                writer.writeheader()

            writer.writerow(result)


def migrate_one(source_repo, target_repo=None):
    result = run_migration(source_repo, target_repo)

    row = {
        "timestamp": timestamp(),
        "mode": "org-to-org" if ORG_TO_ORG else "repo-to-repo",
        "source_org": SOURCE_ORG,
        "source_repo": source_repo,
        "target_org": TARGET_ORG,
        "target_repo": target_repo or source_repo,
        **result,
    }

    append_result(row)
    return result["status"]


def safe_migrate_one(source_repo, target_repo=None):
    """Wrap migrate_one so a worker-thread exception can't crash the pool."""

    try:
        return migrate_one(source_repo, target_repo)
    except Exception as exc:
        logger.exception(
            "Unhandled error migrating %s: %s", source_repo, exc
        )
        return "FAILED"


def main():
    try:
        validate_configuration()
    except Exception as exc:
        logger.error("Configuration error: %s", exc)
        return 2

    total = 0
    succeeded = 0
    failed = 0
    skipped = 0

    try:
        if ORG_TO_ORG:
            # Exactly one organization-level migration, not one per repo.
            total = 1
            status = migrate_one(ORG_SOURCE_REPO)

            if status in ("SUCCESS", "DRY_RUN"):
                succeeded += 1
            else:
                failed += 1

        else:
            rows = list(load_repo_rows())
            total = len(rows)
            valid_rows = []

            for row in rows:
                source_repo = row["source_repo"]
                target_repo = row["target_repo"]

                if row["invalid"]:
                    skipped += 1

                    error = (
                        f"CSV line {row['line_number']}: {row['invalid']}"
                    )
                    logger.error(error)

                    append_result({
                        "timestamp": timestamp(),
                        "mode": "repo-to-repo",
                        "source_org": SOURCE_ORG,
                        "source_repo": source_repo,
                        "target_org": TARGET_ORG,
                        "target_repo": target_repo,
                        "status": "SKIPPED",
                        "attempts": 0,
                        "return_code": "",
                        "duration_seconds": 0,
                        "details": row["invalid"],
                    })
                    continue

                valid_rows.append(row)

            if MAX_WORKERS > 1:
                logger.info(
                    "Running up to %s migrations in parallel.", MAX_WORKERS
                )

                with concurrent.futures.ThreadPoolExecutor(
                    max_workers=MAX_WORKERS
                ) as executor:
                    futures = []

                    for row in valid_rows:
                        futures.append(
                            executor.submit(
                                safe_migrate_one,
                                row["source_repo"],
                                row["target_repo"],
                            )
                        )

                        # Stagger submissions so the API isn't hit with a burst.
                        if DELAY_SECONDS:
                            time.sleep(DELAY_SECONDS)

                    for future in concurrent.futures.as_completed(futures):
                        status = future.result()

                        if status in ("SUCCESS", "DRY_RUN"):
                            succeeded += 1
                        else:
                            failed += 1
            else:
                for row in valid_rows:
                    status = migrate_one(row["source_repo"], row["target_repo"])

                    if status in ("SUCCESS", "DRY_RUN"):
                        succeeded += 1
                    else:
                        failed += 1

                    if DELAY_SECONDS:
                        time.sleep(DELAY_SECONDS)

    except Exception as exc:
        logger.exception("Unexpected orchestration error: %s", exc)
        return 2

    logger.info("=" * 60)
    logger.info("Migration run completed.")
    logger.info("Total: %s", total)
    logger.info("Successful / dry-run: %s", succeeded)
    logger.info("Failed: %s", failed)
    logger.info("Skipped: %s", skipped)
    logger.info("Results: %s", OUTPUT_CSV)
    logger.info("Errors: %s", ERROR_LOG)

    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())