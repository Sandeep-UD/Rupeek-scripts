# GitHub Secrets Migration

Bulk orchestrator for migrating GitHub Actions secrets between repositories or organizations using the `gh-secrets-migrator` GitHub CLI extension.

## Features

- **Repo-to-repo mode**: migrates secrets for a list of repository mappings defined in `repos.csv`.
- **Org-to-org mode**: migrates organization-level secrets in a single run.
- **Parallel migrations** via `MAX_WORKERS` to speed up large batches of repos.
- Retries transient failures (rate limits, timeouts, 5xx errors) with exponential backoff.
- Appends per-repo results to `migration_results.csv` as it goes, so progress is never lost.
- Logs errors to `migration_errors.log` and redacts PATs from any captured output.
- Supports a dry-run mode to validate configuration before performing real migrations.

## Requirements

- Python 3.10+
- [GitHub CLI](https://cli.github.com/) installed and authenticated
- `gh-secrets-migrator` extension installed (`gh extension install ...`)
- Python dependency:
  ```
  pip install python-dotenv
  ```

## Setup

1. Create a `.env` file in this folder with the following variables:

   | Variable | Required | Default | Description |
   |---|---|---|---|
   | `SOURCE_PAT` | Yes | — | Personal access token for the source org/repos |
   | `TARGET_PAT` | Yes | — | Personal access token for the target org/repos |
   | `SOURCE_ORG` | Yes | — | Source GitHub organization |
   | `TARGET_ORG` | Yes | — | Target GitHub organization |
   | `ORG_TO_ORG` | No | `false` | Set `true` to migrate org-level secrets instead of per-repo |
   | `ORG_SOURCE_REPO` | Only if `ORG_TO_ORG=true` | `.github` | Source repo used by the CLI for org-to-org migration |
   | `SKIP_OVERWRITE` | No | `true` | Skip secrets that already exist on the target |
   | `DRY_RUN` | No | `true` | Validate configuration and commands without running migrations |
   | `SOURCE_ENDPOINT` | No | `https://api.github.com` | API endpoint for the source (useful for GHES) |
   | `TARGET_ENDPOINT` | No | `https://api.github.com` | API endpoint for the target (useful for GHES) |
   | `DELAY_SECONDS` | No | `2` | Delay between migrations/submissions and base retry backoff |
   | `MAX_RETRIES` | No | `3` | Max retry attempts for transient CLI failures |
   | `MAX_WORKERS` | No | `1` | Number of repo migrations to run in parallel (repo-to-repo mode only) |

2. For repo-to-repo mode, list the repositories to migrate in `repos.csv`:

   ```csv
   source_repo,target_repo
   secrets-test,secrets-test
   test-secrets,test-secrets
   test-script,test-script
   ```

## Usage

Run a dry run first to confirm configuration is valid:

```powershell
# with DRY_RUN=true in .env
py .\migrate_secrets.py
```

Once the dry run looks correct, set `DRY_RUN=false` in `.env` and run again to perform the actual migration:

```powershell
py .\migrate_secrets.py
```

## Output

- `migration_results.csv` — one row per migration attempt (timestamp, mode, source/target org/repo, status, attempts, return code, duration, details).
- `migration_errors.log` — error-level log entries for failed/skipped migrations.

## Scaling to large repo lists (1000+)

- By default (`MAX_WORKERS=1`) migrations run one at a time. Observed durations are roughly 20–90s per repo, so 1000 repos sequentially can take **12+ hours**.
- Set `MAX_WORKERS` to a value greater than `1` (e.g. `5`–`10`) in `.env` to migrate multiple repos concurrently via a thread pool, cutting total run time roughly by a factor of the worker count.
- `DELAY_SECONDS` still applies when `MAX_WORKERS > 1`, but it staggers *submission* of new jobs rather than pausing between every migration, so it won't fully serialize work.
- Writes to `migration_results.csv` are thread-safe, so results from parallel workers won't interleave or corrupt the file.
- Start conservatively (e.g. `MAX_WORKERS=5`) and increase gradually — running many `gh secrets-migrator` processes at once can trip GitHub's secondary rate limits, and the underlying CLI may not be fully safe for high concurrency.
- Validate a small batch first before scaling up to the full 1000+ repo list, and spot-check target secrets (`gh secret list -R <org>/<repo>`) after large parallel runs.
- For very large migrations, consider running the org-level secrets migration (`ORG_TO_ORG=true`) separately from the bulk repo-level pass, since org secrets only need to move once.

## Notes

- PATs are passed to the CLI via environment variables, never as command-line arguments, and are redacted from any logged output.
- Duplicate or incomplete rows in `repos.csv` are skipped and recorded with status `SKIPPED`.
- The script exits with code `0` on full success, `1` if any migration failed, and `2` on configuration/unexpected errors.
