import os
import sys
import argparse
import logging
import csv
import json
from datetime import datetime
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
from github import Github, GithubException
from dotenv import load_dotenv


# Load environment variables from .env file
load_dotenv()


# --- Shared Configuration from Environment Variables ---
SOURCE_ORG = os.getenv("GH_ORG")
TARGET_ORG = os.getenv("TARGET_GH_ORG")
SOURCE_TOKEN = os.getenv("GH_PAT")
TARGET_TOKEN = os.getenv("TARGET_GH_PAT")
REPOSITORIES_CSV = os.getenv("REPOSITORIES_CSV", "repositories.csv")
WEBHOOKS_EXPORT_FILE = os.getenv("WEBHOOKS_EXPORT_FILE", "exported_webhooks.json")
LOG_FILE = os.getenv("LOG_FILE", "webhook_migration.log")
CSV_REPORT_FILE = os.getenv("CSV_REPORT_FILE", "webhook_migration_report.csv")


def _with_org_prefix(file_name):
    """Prefixes output files so org-level runs do not overwrite repo-level outputs."""
    directory, basename = os.path.split(file_name)
    return os.path.join(directory, f"org_{basename}") if directory else f"org_{basename}"


ORG_WEBHOOKS_EXPORT_FILE = _with_org_prefix(WEBHOOKS_EXPORT_FILE)
ORG_LOG_FILE = _with_org_prefix(LOG_FILE)
ORG_CSV_REPORT_FILE = _with_org_prefix(CSV_REPORT_FILE)


def setup_logging():
    """Configures logging to both console and a file."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(ORG_LOG_FILE),
            logging.StreamHandler(sys.stdout),
        ],
    )


class GitHubOrgWebhookMigrator:
    """
    Exports/imports organization-level webhooks between source and target orgs.
    Uses the same .env and repositories.csv as the repository-level migrator.
    """

    def __init__(self):
        self._validate_env()
        self.source_org = SOURCE_ORG
        self.target_org = TARGET_ORG
        self.migration_results = []
        self.repo_mappings = self.read_repositories_from_csv()
        self._authenticate()

    def _validate_env(self):
        if not all([SOURCE_ORG, TARGET_ORG, SOURCE_TOKEN, TARGET_TOKEN]):
            missing_vars = []
            if not SOURCE_ORG:
                missing_vars.append("GH_ORG")
            if not TARGET_ORG:
                missing_vars.append("TARGET_GH_ORG")
            if not SOURCE_TOKEN:
                missing_vars.append("GH_PAT")
            if not TARGET_TOKEN:
                missing_vars.append("TARGET_GH_PAT")

            logging.error(f"Missing required environment variables: {', '.join(missing_vars)}")
            logging.error("Please check your .env file and ensure all required variables are set.")
            sys.exit(1)

    def _authenticate(self):
        try:
            self.source_github_api = Github(SOURCE_TOKEN)
            user = self.source_github_api.get_user()
            user.login
            logging.info("Source GitHub authentication successful")
        except GithubException as e:
            if e.status == 401:
                logging.error("Source GitHub authentication failed: Invalid or expired token")
                logging.error("Please check your GH_PAT in the .env file")
            else:
                logging.error(f"Source GitHub authentication failed: {e}")
            sys.exit(1)
        except Exception as e:
            logging.error(f"Source GitHub authentication error: {e}")
            sys.exit(1)

        try:
            self.target_github_api = Github(TARGET_TOKEN)
            user = self.target_github_api.get_user()
            user.login
            logging.info("Target GitHub authentication successful")
        except GithubException as e:
            if e.status == 401:
                logging.error("Target GitHub authentication failed: Invalid or expired token")
                logging.error("Please check your TARGET_GH_PAT in the .env file")
            else:
                logging.error(f"Target GitHub authentication failed: {e}")
            sys.exit(1)
        except Exception as e:
            logging.error(f"Target GitHub authentication error: {e}")
            sys.exit(1)

    def read_repositories_from_csv(self):
        """
        Reads source_repo,target_repo mappings from repositories.csv.
        For org webhook migration, these mappings are used to adjust webhook URLs.
        """
        mappings = {}

        if not os.path.exists(REPOSITORIES_CSV):
            logging.warning(
                f"CSV file not found: {REPOSITORIES_CSV}. Continuing without URL repo-name mapping."
            )
            return mappings

        try:
            with open(REPOSITORIES_CSV, "r", newline="", encoding="utf-8") as csvfile:
                reader = csv.DictReader(csvfile)

                required_columns = {"source_repo", "target_repo"}
                if not reader.fieldnames or not required_columns.issubset(reader.fieldnames):
                    logging.warning(
                        "repositories.csv does not contain source_repo,target_repo. "
                        "Continuing without URL repo-name mapping."
                    )
                    return mappings

                for row in reader:
                    source_repo = (row.get("source_repo") or "").strip()
                    target_repo = (row.get("target_repo") or "").strip()
                    if source_repo and target_repo:
                        mappings[source_repo] = target_repo

            logging.info(f"Loaded {len(mappings)} repo mapping(s) from {REPOSITORIES_CSV}")
            return mappings
        except Exception as e:
            logging.warning(
                f"Failed to read CSV file {REPOSITORIES_CSV}: {e}. Continuing without URL repo-name mapping."
            )
            return mappings

    def _transform_webhook_url(self, url):
        """
        Rewrites URL path/query using org and repo mappings when possible.
        This allows endpoints containing source org/repo identifiers to be updated.
        """
        if not url:
            return url

        try:
            parts = urlsplit(url)

            # Rewrite path segments for org and repo names.
            path_segments = parts.path.split("/")
            rewritten_segments = []
            for segment in path_segments:
                if segment == self.source_org:
                    rewritten_segments.append(self.target_org)
                elif segment in self.repo_mappings:
                    rewritten_segments.append(self.repo_mappings[segment])
                else:
                    rewritten_segments.append(segment)
            new_path = "/".join(rewritten_segments)

            # Rewrite query values where exact source identifiers are present.
            query_items = parse_qsl(parts.query, keep_blank_values=True)
            rewritten_query = []
            for key, value in query_items:
                if value == self.source_org:
                    rewritten_query.append((key, self.target_org))
                elif value in self.repo_mappings:
                    rewritten_query.append((key, self.repo_mappings[value]))
                else:
                    rewritten_query.append((key, value))
            new_query = urlencode(rewritten_query, doseq=True)

            return urlunsplit((parts.scheme, parts.netloc, new_path, new_query, parts.fragment))
        except Exception:
            # If URL parsing fails, keep original URL to avoid accidental corruption.
            return url

    def _get_org(self, github_api, org_name):
        try:
            logging.info(f"Fetching organization: {org_name}")
            org = github_api.get_organization(org_name)
            logging.info(f"Organization found: {org_name}")
            return org
        except GithubException as e:
            logging.error(f"Could not access organization: {org_name}. Error: {e}")
            return None

    def export_webhooks(self):
        """Exports active organization-level webhooks from source org."""
        logging.info("Starting organization webhook export process...")

        source_org_obj = self._get_org(self.source_github_api, self.source_org)
        if source_org_obj is None:
            return

        try:
            hooks = list(source_org_obj.get_hooks())
            logging.info(f"Found {len(hooks)} organization webhook(s) in source org.")
        except GithubException as e:
            logging.error(f"Failed to fetch organization webhooks: {e}")
            return

        exported_hooks = []
        for hook in hooks:
            if not hook.active:
                logging.info(f"Skipped inactive org webhook: {hook.config.get('url')}")
                continue

            webhook_info = {
                "url": hook.config.get("url"),
                "content_type": hook.config.get("content_type", "json"),
                "insecure_ssl": hook.config.get("insecure_ssl", "0"),
                "events": hook.events,
                "active": hook.active,
            }
            exported_hooks.append(webhook_info)
            logging.info(f"Exported org webhook: {webhook_info['url']}")

        exported_data = {
            "export_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "source_org": self.source_org,
            "target_org": self.target_org,
            "repositories_csv": REPOSITORIES_CSV,
            "repo_mapping_count": len(self.repo_mappings),
            "organization_webhooks": exported_hooks,
        }

        try:
            with open(ORG_WEBHOOKS_EXPORT_FILE, "w", encoding="utf-8") as f:
                json.dump(exported_data, f, indent=2)
            logging.info(f"Organization webhooks exported to {ORG_WEBHOOKS_EXPORT_FILE}")
            logging.info(f"Total active org webhooks exported: {len(exported_hooks)}")
        except Exception as e:
            logging.error(f"Failed to save organization webhook export: {e}")

    def import_webhooks(self):
        """Imports organization-level webhooks into target org."""
        logging.info("Starting organization webhook import process...")

        if not os.path.exists(ORG_WEBHOOKS_EXPORT_FILE):
            logging.error(f"Export file not found: {ORG_WEBHOOKS_EXPORT_FILE}")
            logging.error("Please run 'python migrate_org_webhooks.py export' first.")
            return

        try:
            with open(ORG_WEBHOOKS_EXPORT_FILE, "r", encoding="utf-8") as f:
                exported_data = json.load(f)
        except Exception as e:
            logging.error(f"Failed to read export file: {e}")
            return

        source_hooks = exported_data.get("organization_webhooks", [])
        logging.info(f"Import file created on: {exported_data.get('export_date', 'Unknown')}")

        if not source_hooks:
            logging.info("No organization webhooks found in export file.")
            self.generate_csv_report()
            return

        target_org_obj = self._get_org(self.target_github_api, self.target_org)
        if target_org_obj is None:
            self._add_migration_result(
                "N/A",
                "N/A",
                "FAILED",
                "Could not access target organization",
                "N/A",
            )
            self.generate_csv_report()
            return

        try:
            existing_target_hooks = {h.config.get("url") for h in target_org_obj.get_hooks()}
        except GithubException as e:
            logging.error(f"Failed to read target organization webhooks: {e}")
            self.generate_csv_report()
            return

        logging.info(f"Importing {len(source_hooks)} organization webhook(s) to {self.target_org}")
        for webhook in source_hooks:
            original_url = webhook.get("url")
            migrated_url = self._transform_webhook_url(original_url)

            if migrated_url in existing_target_hooks:
                msg = "Webhook already exists in target organization"
                logging.warning(f"{msg}: {migrated_url}")
                self._add_migration_result(original_url, migrated_url, "SKIPPED", msg, webhook.get("events"))
                continue

            new_config = {
                "url": migrated_url,
                "content_type": webhook.get("content_type", "json"),
                "insecure_ssl": webhook.get("insecure_ssl", "0"),
            }

            try:
                target_org_obj.create_hook(
                    name="web",
                    config=new_config,
                    events=webhook.get("events", []),
                    active=webhook.get("active", True),
                )
                logging.info(f"Successfully imported org webhook: {migrated_url}")
                self._add_migration_result(original_url, migrated_url, "SUCCESS", "", webhook.get("events"))
            except GithubException as e:
                logging.error(f"Failed to import org webhook {migrated_url}: {e}")
                self._add_migration_result(original_url, migrated_url, "FAILED", str(e), webhook.get("events"))

        self.generate_csv_report()
        logging.info("Organization webhook import process finished.")

    def _add_migration_result(self, source_url, target_url, status, reason, events):
        self.migration_results.append(
            {
                "migration_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "source_org": self.source_org,
                "target_org": self.target_org,
                "source_webhook_url": source_url,
                "target_webhook_url": target_url,
                "events": events,
                "status": status,
                "reason": reason,
            }
        )

    def generate_csv_report(self):
        logging.info(f"Generating organization migration report at {ORG_CSV_REPORT_FILE}")

        fieldnames = [
            "migration_date",
            "source_org",
            "target_org",
            "source_webhook_url",
            "target_webhook_url",
            "events",
            "status",
            "reason",
        ]

        try:
            with open(ORG_CSV_REPORT_FILE, "w", newline="", encoding="utf-8") as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                writer.writeheader()

                if not self.migration_results:
                    writer.writerow(
                        {
                            "migration_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            "source_org": self.source_org,
                            "target_org": self.target_org,
                            "source_webhook_url": "N/A",
                            "target_webhook_url": "N/A",
                            "events": "N/A",
                            "status": "NO_MIGRATION_PERFORMED",
                            "reason": "No organization webhooks processed",
                        }
                    )
                else:
                    for result in self.migration_results:
                        events_str = ", ".join(result["events"]) if isinstance(result["events"], list) else str(result["events"])
                        writer.writerow(
                            {
                                "migration_date": result["migration_date"],
                                "source_org": result["source_org"],
                                "target_org": result["target_org"],
                                "source_webhook_url": result["source_webhook_url"],
                                "target_webhook_url": result["target_webhook_url"],
                                "events": events_str,
                                "status": result["status"],
                                "reason": result["reason"],
                            }
                        )

            logging.info("Organization migration CSV report generation complete.")
        except Exception as e:
            logging.error(f"Failed to generate organization migration CSV report: {e}")


def main():
    setup_logging()

    parser = argparse.ArgumentParser(
        description=(
            "Export and import GitHub organization-level webhooks using the same .env "
            "and repositories.csv used by migrate_webhooks.py"
        ),
        epilog=(
            "Examples:\n"
            "  python migrate_org_webhooks.py export   # Export org-level webhooks\n"
            "  python migrate_org_webhooks.py import   # Import org-level webhooks\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "command",
        choices=["export", "import"],
        help="Command to execute: export org webhooks or import org webhooks",
    )

    args = parser.parse_args()

    if not os.path.exists(".env"):
        logging.error(".env file not found. Please create a .env file with required variables.")
        logging.error("Required variables: GH_PAT, GH_ORG, TARGET_GH_PAT, TARGET_GH_ORG")
        sys.exit(1)

    migrator = GitHubOrgWebhookMigrator()

    if args.command == "export":
        logging.info("=== Starting Organization Webhook Export Process ===")
        migrator.export_webhooks()
    elif args.command == "import":
        logging.info("=== Starting Organization Webhook Import Process ===")
        migrator.import_webhooks()


if __name__ == "__main__":
    main()
