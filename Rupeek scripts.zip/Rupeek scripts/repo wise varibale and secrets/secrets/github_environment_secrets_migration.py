#!/usr/bin/env python3
"""Migrate GitHub Actions environment secrets for repositories listed in repos.csv."""

import csv
import logging
from typing import Dict, List, Optional, Set, Tuple
from urllib.parse import quote

import requests

from github_secrets_migration import GitHubSecretsMigrator


class GitHubEnvironmentSecretsMigrator(GitHubSecretsMigrator):
    """Migrate environment secrets without changing environment protection rules."""

    def __init__(self) -> None:
        super().__init__()
        self.environment_public_key_cache: Dict[Tuple[str, str, str], Dict] = {}
        self.target_environment_cache: Dict[Tuple[str, str], bool] = {}
        self.target_secret_cache: Dict[Tuple[str, str], Optional[Set[str]]] = {}

    def _repository_path(self, org: str, repository: str) -> str:
        return f'{quote(org, safe="")}/{quote(repository, safe="")}'

    def _environment_url(self, org: str, repository: str, environment: str) -> str:
        session = self.target_session if org == self.TARGET_ORGANIZATION else self.source_session
        base_url = self._get_base_url_for_session(session)
        return (
            f'{base_url}/repos/{self._repository_path(org, repository)}/environments/'
            f'{quote(environment, safe="")}'
        )

    def get_environments(
        self, org: str, repository: str, session: requests.Session
    ) -> List[Dict]:
        base_url = self._get_base_url_for_session(session)
        url = f'{base_url}/repos/{self._repository_path(org, repository)}/environments'
        return self._get_paginated_data(session, url)

    def get_environment_secrets(
        self, org: str, repository: str, environment: str, session: requests.Session
    ) -> List[Dict]:
        base_url = self._get_base_url_for_session(session)
        url = (
            f'{base_url}/repos/{self._repository_path(org, repository)}/environments/'
            f'{quote(environment, safe="")}/secrets'
        )
        return self._get_paginated_data(session, url)

    def get_environment_public_key(
        self, repository: str, environment: str
    ) -> Optional[Dict]:
        cache_key = (self.TARGET_ORGANIZATION, repository, environment)
        if cache_key in self.environment_public_key_cache:
            return self.environment_public_key_cache[cache_key]

        url = f'{self._environment_url(self.TARGET_ORGANIZATION, repository, environment)}/secrets/public-key'
        response = self._make_request(self.target_session, 'GET', url)
        if response.status_code != 200:
            self.logger.error(
                'Failed to get public key for target environment %s/%s: HTTP %s',
                repository, environment, response.status_code
            )
            return None

        try:
            key = response.json()
        except ValueError as error:
            self.logger.error('Failed to parse public key for %s/%s: %s', repository, environment, error)
            return None
        self.environment_public_key_cache[cache_key] = key
        return key

    def ensure_target_environment(self, repository: str, environment: str) -> bool:
        cache_key = (repository, environment)
        if cache_key in self.target_environment_cache:
            return self.target_environment_cache[cache_key]

        url = self._environment_url(
            self.TARGET_ORGANIZATION, repository, environment
        )
        response = self._make_request(self.target_session, 'GET', url)
        if response.status_code == 200:
            self.logger.info(
                'Target environment %s/%s already exists; leaving it unchanged',
                repository, environment
            )
            self.target_environment_cache[cache_key] = True
            return True
        if response.status_code != 404:
            self.logger.error(
                'Could not verify target environment %s/%s: HTTP %s',
                repository, environment, response.status_code
            )
            self.target_environment_cache[cache_key] = False
            return False

        response = self._make_request(self.target_session, 'PUT', url, json={})
        if response.status_code in (200, 201):
            self.logger.info('Created target environment %s/%s', repository, environment)
            self.target_environment_cache[cache_key] = True
            return True

        try:
            detail = response.json().get('message', 'Unknown error')
        except (ValueError, AttributeError):
            detail = response.text
        self.logger.error(
            'Failed to create target environment %s/%s: HTTP %s - %s',
            repository, environment, response.status_code, detail
        )
        self.target_environment_cache[cache_key] = False
        return False

    def fetch_environment_secrets_for_migration(self) -> List[Dict]:
        secrets = []
        for repository in self.read_repositories_from_csv():
            self.logger.info('Fetching environment secrets for repository: %s', repository)
            source_environments = self.get_environments(
                self.SOURCE_ORGANIZATION, repository, self.source_session
            )

            for environment in source_environments:
                if not isinstance(environment, dict) or not environment.get('name'):
                    continue
                environment_name = environment['name']
                if not self.ensure_target_environment(repository, environment_name):
                    continue

                for secret in self.get_environment_secrets(
                    self.SOURCE_ORGANIZATION,
                    repository,
                    environment_name,
                    self.source_session
                ):
                    if not isinstance(secret, dict) or not secret.get('name'):
                        continue
                    secrets.append({
                        'scope': 'environment',
                        'repository': repository,
                        'environment': environment_name,
                        'name': secret['name'],
                        'value': '[ENCRYPTED_SECRET_VALUE]',
                        'created_at': secret.get('created_at', ''),
                        'updated_at': secret.get('updated_at', '')
                    })

        return secrets

    def _target_environment_secrets(
        self, repository: str, environment: str
    ) -> Optional[Set[str]]:
        cache_key = (repository, environment)
        if cache_key not in self.target_secret_cache:
            url = (
                f'{self._environment_url(self.TARGET_ORGANIZATION, repository, environment)}'
                '/secrets'
            )
            response = self._make_request(
                self.target_session, 'GET', url, params={'per_page': 1}
            )
            if response.status_code != 200:
                self.logger.error(
                    'Cannot verify existing secrets for target environment %s/%s: HTTP %s; skipping writes',
                    repository, environment, response.status_code
                )
                self.target_secret_cache[cache_key] = None
                return None

            secrets = self.get_environment_secrets(
                self.TARGET_ORGANIZATION, repository, environment, self.target_session
            )
            self.target_secret_cache[cache_key] = {
                secret['name']
                for secret in secrets
                if isinstance(secret, dict) and secret.get('name')
            }
        return self.target_secret_cache[cache_key]

    def create_environment_secret(
        self, repository: str, environment: str, name: str, value: str
    ) -> Optional[bool]:
        if not self.ensure_target_environment(repository, environment):
            return False

        existing_names = self._target_environment_secrets(repository, environment)
        if existing_names is None:
            return False
        if name in existing_names:
            self.logger.info(
                'Environment secret %s/%s/%s already exists; skipping',
                repository, environment, name
            )
            return None

        public_key_info = self.get_environment_public_key(repository, environment)
        if not public_key_info:
            return False

        if value == '[ENCRYPTED_SECRET_VALUE]' or not value.strip():
            value = 'PLACEHOLDER_VALUE_SET_MANUALLY'

        try:
            encrypted_value = self.encrypt_secret(value, public_key_info['key'])
        except Exception as error:
            self.logger.error('Failed to encrypt environment secret %s: %s', name, error)
            return False

        url = (
            f'{self._environment_url(self.TARGET_ORGANIZATION, repository, environment)}'
            f'/secrets/{quote(name, safe="")}'
        )
        response = self._make_request(
            self.target_session,
            'PUT',
            url,
            json={
                'encrypted_value': encrypted_value,
                'key_id': public_key_info['key_id']
            }
        )
        if response.status_code in (201, 204):
            existing_names.add(name)
            self.logger.info(
                'Created environment secret: %s/%s/%s [PLACEHOLDER]',
                repository, environment, name
            )
            return True

        try:
            detail = response.json().get('message', 'Unknown error')
        except (ValueError, AttributeError):
            detail = response.text
        self.logger.error(
            'Failed to create environment secret %s/%s/%s: HTTP %s - %s',
            repository, environment, name, response.status_code, detail
        )
        return False

    def export_environment_secrets(self, secrets: List[Dict], filename: str) -> None:
        fields = [
            'scope', 'repository', 'environment', 'name', 'value', 'created_at', 'updated_at'
        ]
        with open(filename, 'w', newline='', encoding='utf-8') as output:
            writer = csv.DictWriter(output, fieldnames=fields)
            writer.writeheader()
            writer.writerows(secrets)

    def migrate_environment_secrets(self, secrets: List[Dict]) -> Tuple[int, int, int]:
        succeeded = 0
        failed = 0
        skipped = 0
        for secret in secrets:
            if secret.get('scope') != 'environment' or not all(
                secret.get(field) for field in ('repository', 'environment', 'name')
            ):
                self.logger.error('Invalid environment secret row; skipping')
                failed += 1
                continue

            result = self.create_environment_secret(
                secret['repository'],
                secret['environment'],
                secret['name'],
                secret.get('value', '[ENCRYPTED_SECRET_VALUE]')
            )
            if result is True:
                succeeded += 1
            elif result is None:
                skipped += 1
            else:
                failed += 1
        return succeeded, failed, skipped

    def run_complete_environment_migration(self) -> None:
        self.logger.info(
            'Starting GitHub environment secrets migration (Export + Migrate with Placeholders)'
        )
        secrets = self.fetch_environment_secrets_for_migration()
        if not secrets:
            self.logger.warning('No environment secrets found to migrate')
            return

        filename = 'github_environment_secrets_export.csv'
        self.export_environment_secrets(secrets, filename)
        succeeded, failed, skipped = self.migrate_environment_secrets(secrets)
        self.logger.info(
            'Environment secret migration completed. Success: %s, Errors: %s, Skipped: %s',
            succeeded, failed, skipped
        )
        self.logger.info('Secrets structure exported to: %s', filename)
        self.logger.info('Placeholder secrets must be updated with real values in GitHub')


def main() -> int:
    try:
        GitHubEnvironmentSecretsMigrator().run_complete_environment_migration()
    except Exception as error:
        logging.error('Environment secret migration failed: %s', error)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())