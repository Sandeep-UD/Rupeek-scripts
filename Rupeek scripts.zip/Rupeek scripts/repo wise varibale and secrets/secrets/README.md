# GitHub Actions Secrets Migration Tool

This Python script helps you migrate GitHub Actions repository-level secrets from a source organization to a target organization. It migrates **only repository-level secrets** from repositories specified in a CSV file and recreates the secret structure in the target organization.

**Important**: This tool **does not migrate organization-level secrets** - only repository-level ones from the specified repositories.

## 🚀 Quick Start

The simplest way to migrate your GitHub secrets:

```bash
# Install dependencies
pip install -r requirements.txt

# Create repos.csv file with repositories to migrate
# Configure your .env file with tokens and organization names
# Edit .env file with your actual values

# Run the migration
python github_secrets_migration.py
```

This script performs a repository-level migration: exports secret metadata from specified repositories, creates all secrets in target organization repositories with placeholder values, and generates a CSV file for reference.

To migrate organization-level secrets instead, run:

```bash
python github_org_secrets_migration.py
```

This uses the same `.env` and `repos.csv`. Existing organization secrets in the target are skipped automatically.

To migrate environment-level secrets for repositories listed in `repos.csv`, run:

```bash
python github_environment_secrets_migration.py
```

The script exports metadata to `github_environment_secrets_export.csv`, then creates missing secrets in same-named target environments using encrypted placeholder values. GitHub does not expose source secret values, so replace the placeholders with real values in the target after migration. If a target environment is missing, the script creates it with default settings; existing environments and their protection rules are left unchanged. Existing environment secrets are skipped.

## ⚠️ Important Security Notice

**GitHub API Security Limitation**: Secret values cannot be retrieved via the GitHub API for security reasons. This tool provides multiple approaches:

- **Default**: Create secret structure with placeholders, then manually set values via GitHub UI
- **Alternative**: Export structure, manually enter values in CSV, then migrate from CSV

## Features

- ✅ Fetches **repository-level secret metadata only** from specified repositories
- ✅ **Repository selection via CSV file** - migrate only specified repositories
- ❌ **Organization-level secrets are skipped** - not migrated
- ✅ Creates secret structure with placeholder values (recommended)
- ✅ Supports manual value entry via CSV for advanced use cases
- ✅ Exports secret structure to CSV format for reference/backup
- ✅ Recreates secrets in target organization repositories with proper encryption
- ✅ Comprehensive logging with file and console output
- ✅ GitHub API rate limit handling with automatic backoff
- ✅ Pagination support for large datasets
- ✅ Error handling and retry mechanisms
- ✅ Environment-based configuration
- ✅ Proper secret encryption using GitHub's public key API
- ✅ Skips existing secrets to prevent overwrites

## Prerequisites

- Python 3.7 or higher
- GitHub Personal Access Tokens for both source and target organizations
- Required permissions for the PATs:
  - **Source PAT**: `repo`, `admin:org`, `read:org`, `read:repo_security`
  - **Target PAT**: `repo`, `admin:org`, `write:org`, `write:repo_security`
- **Repository CSV file** (see Repository Selection section below)

## Repository Selection

The script requires a `repos.csv` file in this directory to specify which repositories to migrate.

### CSV Format

Create a `repos.csv` file in the `secrets/` directory with the following format:

```csv
repository_name
repo1
repo2
repo3
my-awesome-repo
```

**Note**: The CSV file should have a header row with `repository_name` and list one repository name per row. Place this file in the same directory as the migration script (`secrets/repos.csv`).

## Setup

1. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Configure environment variables:**
   Create a `.env` file in the same directory:
   ```env
   SOURCE_GITHUB_TOKEN=your_source_github_token_here
   TARGET_GITHUB_TOKEN=your_target_github_token_here
   SOURCE_ORGANIZATION=your_source_organization
   TARGET_ORGANIZATION=your_target_organization
   SOURCE_API_URL=https://api.github.com
   TARGET_API_URL=https://api.github.com
   ```

`SOURCE_API_URL` and `TARGET_API_URL` are optional:
- For GitHub.com, use `https://api.github.com` (or leave defaults in place).
- For GHES/data residency, use your instance API endpoints (for example `https://<your-host>/api/v3`).

## Usage

### Default Migration (Complete Workflow)

1. **Create your repository list:**
   Create a `repos.csv` file in this directory listing the repositories you want to migrate.

2. **Run the migration script:**
   ```bash
   python github_secrets_migration.py
   ```

This executes the [`run_complete_migration`](github_secrets_migration.py) method which:
1. Reads repository list from `repos.csv`
2. Exports secret metadata from specified repositories only (skips organization-level secrets)
3. Creates all secrets in target organization repositories with placeholder values
4. Generates `github_secrets_export.csv` for reference
5. Skips secrets that already exist in the target organization

### Alternative Usage Modes

You can modify the [`main`](github_secrets_migration.py) function to use different modes:

#### Export Only Mode
```python
def main():
    migrator = GitHubSecretsMigrator()
    migrator.run_export_only()
    return 0
```

#### Migrate from CSV Mode
```python
def main():
    migrator = GitHubSecretsMigrator()
    migrator.run_migration_from_csv("github_secrets_export.csv", create_placeholder=True)
    return 0
```

#### Migrate Only with Actual Values
```python
def main():
    migrator = GitHubSecretsMigrator()
    migrator.run_migration_from_csv("my_secrets_with_values.csv", create_placeholder=False)
    return 0
```

## Available Methods

The [`GitHubSecretsMigrator`](github_secrets_migration.py) class provides these main methods:

- [`run_complete_migration()`](github_secrets_migration.py): Export + migrate with placeholders (default)
- [`run_export_only()`](github_secrets_migration.py): Only export secret structure to CSV
- [`run_migration_from_csv(csv_filename, create_placeholder=True)`](github_secrets_migration.py): Migrate from prepared CSV file

## Examples

### Standard usage (default):
```bash
python github_secrets_migration.py
```

### Organization secrets migration:
```bash
python github_org_secrets_migration.py
```

### With setup:
```bash
# Install dependencies
pip install -r requirements.txt

# Run migration
python github_secrets_migration.py
```

## Workflow Recommendations

### Default Workflow (Recommended)
1. **Setup**: Install dependencies with `pip install -r requirements.txt` (one time only)
2. **Configure**: Edit `.env` file with your tokens and organizations
3. **Migrate**: `python github_secrets_migration.py`
4. **Update Values**: Use GitHub UI to set actual secret values for placeholder secrets
5. **Verify**: Test your workflows to ensure secrets work correctly

### Advanced Workflow (Manual Value Entry)
1. **Export**: Modify script to call `run_export_only()`
2. **Edit CSV**: Manually enter actual secret values in the generated CSV
3. **Migrate**: Modify script to call `run_migration_from_csv()` with `create_placeholder=False`

## CSV File Format

The CSV file generated by [`export_secrets_to_csv`](github_secrets_migration.py) contains:

| Column | Description |
|--------|-------------|
| `scope` | Either "organization" or "repository" |
| `repository` | Repository name (only for repository-scoped secrets) |
| `name` | Secret name |
| `value` | Secret value (`[ENCRYPTED_SECRET_VALUE]` for placeholders) |
| `visibility` | For org secrets: "all", "private", or "selected" |
| `selected_repositories` | Comma-separated list of repository names (for selected visibility) |
| `created_at` | Creation timestamp (informational) |
| `updated_at` | Last update timestamp (informational) |

## Security Features

1. **Proper Encryption**: Uses GitHub's public key API and NaCl encryption via [`encrypt_secret`](github_secrets_migration.py)
2. **Placeholder Support**: Creates secrets with safe placeholder values "PLACEHOLDER_VALUE_SET_MANUALLY"
3. **No Value Logging**: Secret values are never logged or printed
4. **Secure Transport**: All API communications use HTTPS
5. **Token Validation**: Validates required environment variables via [`_validate_config`](github_secrets_migration.py)
6. **Existing Secret Detection**: Checks and skips existing secrets to prevent overwrites

## Data Residency / API Endpoint

- The script supports separate API endpoints for source and target via `SOURCE_API_URL` and `TARGET_API_URL`.
- This allows migrations between different GitHub environments (for example GitHub.com -> GHES).

## Error Handling

The script includes comprehensive error handling for:
- Missing or invalid authentication tokens
- Rate limiting (automatic backoff and retry via [`_handle_rate_limit`](github_secrets_migration.py))
- Network connectivity issues (retry strategy in [`_create_session`](github_secrets_migration.py))
- Invalid repository or organization names
- Missing target repositories
- Encryption failures

## Logging

All operations are logged via [`_setup_logging`](github_secrets_migration.py) to:
- Console output (INFO level and above)
- `github_secrets_migration.log` file (detailed logging)

Log entries include timestamps, operation details, and error information.

## Visibility Settings

### Organization Secrets
- **all**: Available to all repositories in the organization
- **private**: Available only to private repositories  
- **selected**: Available to specific repositories (handled by [`get_target_repository_ids`](github_secrets_migration.py))

### Repository Secrets
- No visibility setting (always scoped to the specific repository)

## How Placeholder Values Work

When using the default migration or `create_placeholder=True`:

1. **Placeholder Creation**: Secrets are created with the value "PLACEHOLDER_VALUE_SET_MANUALLY"
2. **Structure Preservation**: All metadata (names, visibility, repositories) is preserved
3. **Manual Update Required**: You must manually update the actual values via GitHub UI
4. **Security**: Placeholder values are clearly identifiable and don't expose sensitive data

## Key Classes and Methods

### Main Class
- [`GitHubSecretsMigrator`](github_secrets_migration.py): Main class handling all migration operations

### Core Methods
- [`fetch_all_secrets()`](github_secrets_migration.py): Retrieves all secrets from source organization
- [`get_organization_secrets()`](github_secrets_migration.py): Gets org-level secrets with visibility info
- [`get_repository_secrets()`](github_secrets_migration.py): Gets repo-level secrets
- [`create_organization_secret()`](github_secrets_migration.py): Creates org secrets with proper visibility
- [`create_repository_secret()`](github_secrets_migration.py): Creates repo secrets
- [`encrypt_secret()`](github_secrets_migration.py): Handles secret encryption using GitHub's public key

### Utility Methods
- [`_make_request()`](github_secrets_migration.py): HTTP requests with rate limit handling
- [`_get_paginated_data()`](github_secrets_migration.py): Handles GitHub API pagination
- [`build_target_repo_mapping()`](github_secrets_migration.py): Maps repository names to IDs

## Post-Migration Steps

After running the migration:

1. **Review Logs**: Check `github_secrets_migration.log` for any errors
2. **Verify Structure**: Confirm all secrets were created in target organization
3. **Update Values**: 
   - For placeholder secrets: Update via GitHub UI (Settings → Secrets and variables → Actions)
   - For actual value secrets: Verify they work correctly
4. **Test**: Run a test workflow to ensure secrets are accessible
5. **Cleanup**: Securely delete any CSV files containing actual secret values

## Troubleshooting

### Common Issues

1. **"No access to secrets"**: Ensure your PAT has the required `read:repo_security` and `write:repo_security` permissions

2. **"Repository not found"**: The target organization may not have a repository with the same name, or your PAT lacks access

3. **"Rate limit exceeded"**: The script automatically handles rate limiting via [`_handle_rate_limit`](github_secrets_migration.py)

4. **"Encryption failed"**: Ensure PyNaCl is properly installed: `pip install PyNaCl`

5. **"Placeholder values in production"**: Remember to update placeholder secrets with actual values after migration

6. **"Secret already exists"**: The script skips existing secrets - check logs for details

### Debug Mode

For detailed debugging, modify the logging level in [`_setup_logging`](github_secrets_migration.py):
```python
logging.basicConfig(level=logging.DEBUG, ...)
```

## Security Best Practices

1. **Secure Storage**: Never commit `.env` files or CSV files with actual secret values to version control
2. **Access Control**: Use PATs with minimum required permissions
3. **Cleanup**: Delete CSV files with actual secret values after migration
4. **Audit**: Review the export CSV before migration to ensure only intended secrets are migrated
5. **Testing**: Test with a small subset of secrets first
6. **Placeholder Management**: Regularly audit and update placeholder secrets
7. **Documentation**: Keep track of which secrets need manual value updates

## Limitations

1. **Secret Values**: Cannot retrieve existing secret values via GitHub API (security feature)
2. **Repository Mapping**: Target repositories must exist with the same names
3. **Environment Variables**: Cannot migrate repository environment-specific secrets
4. **Overwrite Protection**: Existing secrets are skipped to prevent accidental overwrites

## Dependencies

From [requirements.txt](requirements.txt):
- `requests==2.31.0`: HTTP library for GitHub API calls
- `urllib3==2.0.7`: HTTP client library
- `python-dotenv==1.0.0`: Environment variable management
- `PyNaCl==1.5.0`: Cryptography library for secret encryption

## License

This tool is provided as-is for educational and migration purposes. Please ensure compliance with your organization's security policies before use.