#!/usr/bin/env python3
import os
from typing import Dict, List

from github_secrets_migration import GitHubSecretsMigrator


class GitHubOrgSecretsMigrator(GitHubSecretsMigrator):
    """GitHub Actions organization-level secrets migration tool."""

    def fetch_organization_secrets_for_migration(self) -> List[Dict]:
        """Fetch organization-level secrets and shape them for migration/export."""
        all_secrets: List[Dict] = []

        # Reuse the same repos.csv used by the repo-level script.
        # This list is used to limit selected-visibility org secrets.
        allowed_repositories = set(self.read_repositories_from_csv())

        self.logger.info("Fetching organization-level secrets only")
        org_secrets = self.get_organization_secrets(self.SOURCE_ORGANIZATION, self.source_session)

        for secret in org_secrets:
            if not isinstance(secret, dict):
                self.logger.error(f"Org secret is not a dict: {type(secret)} - {secret}")
                continue

            visibility = secret.get("visibility", "all")
            selected_repositories = []

            if visibility == "selected":
                source_selected = secret.get("selected_repository_names", [])
                if not isinstance(source_selected, list):
                    source_selected = []

                selected_repositories = [
                    repo_name for repo_name in source_selected if repo_name in allowed_repositories
                ]

                if source_selected and not selected_repositories:
                    self.logger.warning(
                        "Secret '%s' has selected visibility but none of its source repositories are present in repos.csv",
                        secret.get("name", "UNKNOWN"),
                    )

            all_secrets.append(
                {
                    "scope": "organization",
                    "repository": "",
                    "name": secret.get("name", ""),
                    "value": secret.get("value", "[ENCRYPTED_SECRET_VALUE]"),
                    "visibility": visibility,
                    "selected_repositories": ",".join(selected_repositories),
                    "created_at": secret.get("created_at", ""),
                    "updated_at": secret.get("updated_at", ""),
                }
            )

        self.logger.info(f"Prepared {len(all_secrets)} organization secrets for migration")
        return all_secrets

    def run_complete_org_migration(self) -> None:
        """Export and migrate organization-level secrets with placeholder values."""
        self.logger.info(
            "Starting GitHub organization secrets migration (Export + Migrate with Placeholders)"
        )

        secrets_data = self.fetch_organization_secrets_for_migration()
        if not secrets_data:
            self.logger.warning("No organization secrets found to migrate")
            return

        csv_filename = "github_org_secrets_export.csv"
        self.export_secrets_to_csv(secrets_data, csv_filename)

        success_count, error_count, skipped_count = self.migrate_secrets(
            secrets_data, create_placeholder=True
        )

        self.logger.info("Organization secrets migration completed")
        self.logger.info(f"Total org secrets processed: {len(secrets_data)}")
        self.logger.info(f"Successfully migrated: {success_count}")
        self.logger.info(f"Errors: {error_count}")
        self.logger.info(f"Skipped: {skipped_count}")
        self.logger.info(f"Secrets structure exported to: {csv_filename}")
        self.logger.info("NOTE: Secrets created with placeholder values - update them manually in GitHub UI")


def main() -> int:
    """Main entry point."""
    try:
        migrator = GitHubOrgSecretsMigrator()
        migrator.run_complete_org_migration()
    except Exception as e:
        print(f"Error: {e}")
        return 1
    return 0


if __name__ == "__main__":
    exit(main())
