# GitHub Actions Variables Migration Tool

This directory contains two Python scripts for migrating GitHub Actions variables from a source organization to a target organization:

| Script | Purpose |
|--------|---------|
| `github_variables_migration.py` | Migrates **repository-level variables** from repositories listed in `repos.csv` |
| `github_org_variables_migration.py` | Migrates **organization-level variables** (extends the base migrator) |
| `github_environment_variables_migration.py` | Migrates **environment-level variables** from repositories listed in `repos.csv` |

Both scripts share the same `.env` configuration and `repos.csv` file.

## Features

### Repository-Level Migration (`github_variables_migration.py`)
- ✅ Fetches repository-level variables from repositories listed in `repos.csv`
- ✅ Creates variables in the target organization; **updates** them if they already exist (409)
- ✅ Exports variables to `github_variables_export.csv` for backup/review
- ✅ Comprehensive logging with file and console output

### Organization-Level Migration (`github_org_variables_migration.py`)
- ✅ Fetches all organization-level variables from the source organization
- ✅ Recreates them in the target organization
- ✅ **Skips** existing organization variables — never overwrites them
- ✅ Supports all visibility types: `all`, `private`, and `selected`
- ✅ Uses `repos.csv` to filter repositories for `selected`-visibility variables
- ✅ Exports organization variables to `github_org_variables_export.csv`

### Environment-Level Migration (`github_environment_variables_migration.py`)
- ✅ Fetches environment variables for repositories listed in `repos.csv`
- ✅ Creates missing target environments and leaves existing environments unchanged
- ✅ Creates missing variables and updates existing variables
- ✅ Exports environment variables to `github_environment_variables_export.csv`
- ✅ Leaves environment protection and deployment rules unchanged

### Shared Features
- ✅ GitHub API rate limit handling with automatic backoff
- ✅ Pagination support for large datasets
- ✅ Retry mechanisms for transient HTTP errors (429, 500–504)
- ✅ Environment-based configuration (`.env` file)

## Prerequisites

- Python 3.7 or higher
- GitHub Personal Access Tokens for both source and target organizations
- Required permissions for the PATs:
  - **Source PAT**: `repo`, `admin:org`, `read:org`
  - **Target PAT**: `repo`, `admin:org`, `write:org`
- A `repos.csv` file (see Repository Selection section below)

## Repository Selection (`repos.csv`)

Both scripts use a `repos.csv` file in this directory, but for different purposes:

| Script | How `repos.csv` is used |
|--------|------------------------|
| `github_variables_migration.py` | Determines **which repositories** to migrate variables from |
| `github_org_variables_migration.py` | Filters which repositories appear in `selected`-visibility org variables |
| `github_environment_variables_migration.py` | Determines which repositories' environment variables to migrate |

### CSV Format

```csv
repository_name
repo1
repo2
repo3
my-awesome-repo
```

The file must have a `repository_name` header and one repository name per row. Place it in the same directory as the scripts.

## Setup

1. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Create environment configuration:**
   Create a `.env` file in the same directory as the script:
   ```env
   SOURCE_GITHUB_TOKEN=your_source_github_token_here
   TARGET_GITHUB_TOKEN=your_target_github_token_here
   SOURCE_ORGANIZATION=your_source_organization
   TARGET_ORGANIZATION=your_target_organization
   SOURCE_API_URL=https://api.github.com
   TARGET_API_URL=https://api.github.com
   ```

`SOURCE_API_URL` and `TARGET_API_URL` are optional:
- For GitHub.com, use `https://api.github.com` (or leave defaults in place).
- For GHES/data residency, use your instance API endpoints (for example `https://<your-host>/api/v3`).

## Usage

1. **Create your `repos.csv`** file in this directory (see Repository Selection above).

2. **Migrate repository-level variables:**
   ```bash
   python github_variables_migration.py
   ```
   Reads repositories from `repos.csv`, fetches their variables from the source org, and creates/updates them in the target org.

3. **Migrate organization-level variables:**
   ```bash
   python github_org_variables_migration.py
   ```
   Fetches all org-level variables from the source org and creates them in the target org. Uses `repos.csv` only to filter repositories for `selected`-visibility variables. **Existing org variables in the target are skipped — not updated.**

4. **Migrate environment-level variables:**
   ```bash
   python github_environment_variables_migration.py
   ```
   Reads repositories from `repos.csv`, fetches their environment variables, and creates or updates them in same-named target environments. Missing target environments are created with default settings; existing environments and their protection rules are left unchanged.

## What Each Script Does

### `github_variables_migration.py`
1. Validates environment variables
2. Reads the repository list from `repos.csv`
3. Fetches repository-level variables for each listed repository
4. Exports variables to `github_variables_export.csv`
5. Creates variables in the target org; updates them if they already exist

### `github_org_variables_migration.py`
1. Validates environment variables
2. Fetches all organization-level variables from the source org
3. For `selected`-visibility variables, filters selected repositories against `repos.csv`
4. Exports variables to `github_org_variables_export.csv`
5. Creates variables in the target org; **skips any that already exist**

### `github_environment_variables_migration.py`
1. Validates environment variables and reads the repository list from `repos.csv`
2. Finds source environments, creates missing target environments, and leaves existing ones unchanged
3. Fetches environment variables from the source repositories
4. Exports variables to `github_environment_variables_export.csv`
5. Creates missing target variables and updates variables that already exist

## Output Files

| File | Generated by | Description |
|------|-------------|-------------|
| `github_variables_export.csv` | `github_variables_migration.py` | Repository-level variables backup |
| `github_org_variables_export.csv` | `github_org_variables_migration.py` | Organization-level variables backup |
| `github_environment_variables_export.csv` | `github_environment_variables_migration.py` | Environment-level variables backup |
| `github_variable_migration.log` | Both scripts | Detailed migration log |

## CSV Format

The exported CSV contains the following columns:

| Column | Description |
|--------|-------------|
| scope | `organization` or `repository` |
| repository | Repository name (empty for org-level variables) |
| name | Variable name |
| value | Variable value |
| visibility | Visibility setting for org variables (`all`, `private`, `selected`) |
| selected_repositories | Comma-separated list of repository names (for `selected` visibility) |
| created_at | When the variable was created |
| updated_at | When the variable was last updated |

## Organization Variable Visibility Support

The script fully supports GitHub organization variable visibility settings:

### Visibility Types
- **`all`** - Variable is available to all repositories in the organization
- **`private`** - Variable is only available to private repositories  
- **`selected`** - Variable is only available to specific selected repositories

### How Repository Visibility Works

1. **Detection**: The script uses [`get_organization_variable_details`](github_variables_migration.py) to detect visibility settings
2. **Repository Mapping**: For `selected` visibility, [`get_variable_selected_repositories`](github_variables_migration.py) fetches the list of repositories
3. **Target Mapping**: [`build_target_repo_mapping`](github_variables_migration.py) maps source repository names to target repository IDs
4. **Recreation**: Variables are recreated with the same visibility settings using [`create_organization_variable`](github_variables_migration.py)

### Repository Mapping Features

- **Automatic Mapping**: [`build_target_repo_mapping`](github_variables_migration.py) builds a cache of target organization repositories
- **Missing Repository Handling**: If repositories don't exist in target org, logs warnings and falls back to `private` visibility
- **Efficient Lookup**: Repository mapping is cached for better performance

## Rate Limiting

The script automatically handles GitHub API rate limits:

- **Monitoring**: [`_handle_rate_limit`](github_variables_migration.py) monitors remaining API calls
- **Automatic Waiting**: Waits when rate limit is approached (< 10 calls remaining)
- **Retry Strategy**: Implements exponential backoff for HTTP errors (429, 500-504)
- **Detailed Logging**: Logs rate limit status and wait times

## Data Residency / API Endpoint

- The script supports separate API endpoints for source and target via `SOURCE_API_URL` and `TARGET_API_URL`.
- This allows migrations between different GitHub environments (for example GitHub.com -> GHES).

## Error Handling

- **Configuration Validation**: [`_validate_config`](github_variables_migration.py) checks required environment variables at startup
- **Repository-level conflicts (409)**: Variable is **updated** via PATCH
- **Organization-level conflicts (409)**: Variable is **skipped** (logged as skipped, not an error)
- **Race-condition safety**: `github_org_variables_migration.py` checks existence before creating and treats a 409 response as a skip
- **Missing target repositories**: Falls back to `private` visibility with a warning
- **Graceful API errors**: Logs specific GitHub API error messages and continues
- **Migration summary**: Counts of successful, failed, and skipped operations are logged at the end

## Security Notes

- Keep your `.env` file secure and never commit it to version control
- Use tokens with minimal required permissions
- Consider using GitHub Apps for better security in production environments
- The script logs variable names but values are only stored in the CSV export
- Variable values are transmitted securely via GitHub's HTTPS API

## Troubleshooting

### Common Issues

1. **"Missing required environment variables"**
   - Check that your `.env` file exists and contains all required variables
   - Ensure variable names match exactly: `SOURCE_GITHUB_TOKEN`, `TARGET_GITHUB_TOKEN`, `SOURCE_ORGANIZATION`, `TARGET_ORGANIZATION`
   
2. **"403 Forbidden" errors**
   - Verify your PAT has the required permissions (`repo`, `admin:org`)
   - Check that the organizations exist and you have access
   
3. **"Rate limit exceeded"**
   - The script handles this automatically with [`_handle_rate_limit`](github_variables_migration.py)
   - Large organizations may take longer due to automatic waiting
   
4. **"Repository not found" warnings**
   - Some repositories may be private, archived, or renamed
   - Check the logs for specific repository names
   - Variables will fallback to `private` visibility if no valid repositories found

### Debug Mode

To enable more detailed logging, modify the logging level in [`_setup_logging`](github_variables_migration.py):

```python
logging.basicConfig(level=logging.DEBUG, ...)
```

## Script Architecture

### Key Classes and Methods

- **[`GitHubVariablesMigrator`](github_variables_migration.py)**: Main class handling the migration process
- **[`get_organization_variables`](github_variables_migration.py)**: Fetches org-level variables with visibility
- **[`get_repository_variables`](github_variables_migration.py)**: Fetches repo-level variables
- **[`create_organization_variable`](github_variables_migration.py)**: Creates org variables with visibility settings
- **[`create_repository_variable`](github_variables_migration.py)**: Creates repo-level variables
- **[`_get_paginated_data`](github_variables_migration.py)**: Handles GitHub API pagination
- **[`run_migration`](github_variables_migration.py)**: Main migration workflow

### HTTP Session Management

- **Retry Strategy**: 3 retries with exponential backoff
- **Custom Headers**: Proper GitHub API headers with User-Agent
- **Authentication**: Token-based authentication for both source and target

## Limitations

- Repository-level variables require the repository to exist in the target organization
- Encrypted secrets are not supported (use GitHub's secrets API separately)
- Variables are migrated with their current values (no encryption in transit beyond HTTPS)
- Large organizations may take significant time due to rate limiting

## Example Migration Flow

1. **Initialization**: Load environment variables and setup sessions
2. **Fetch**: Get all variables from source organization
3. **Export**: Save to [`github_variables_export.csv`](github_variables_export.csv)
4. **Map**: Build repository mapping for target organization
5. **Migrate**: Create/update variables in target organization
6. **Summary**: Log final counts and completion status

Based on your [`github_variables_export.csv`](github_variables_export.csv), the script successfully handles:
- Organization variables with `selected` visibility
- Repository variables from multiple repositories
- Proper CSV formatting with all required columns

## Contributing

Feel free to submit issues and enhancement requests! The script is designed to be extensible and maintainable.

## Recent Updates

- ✅ Full organization variable visibility support (`all`, `private`, `selected`)
- ✅ Repository mapping and automatic fallback handling
- ✅ Enhanced error handling with automatic updates for existing variables
- ✅ Comprehensive CSV export with visibility information
- ✅ Improved logging and