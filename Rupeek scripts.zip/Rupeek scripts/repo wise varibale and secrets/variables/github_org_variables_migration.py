#!/usr/bin/env python3
from typing import Dict, List, Optional

from github_variables_migration import GitHubVariablesMigrator


class GitHubOrgVariablesMigrator(GitHubVariablesMigrator):
    """GitHub Actions organization-level variables migration tool."""

    def check_organization_variable_exists(self, org: str, name: str) -> bool:
        """Check if an organization variable already exists in the target organization."""
        base_url = self._get_base_url_for_session(self.target_session)
        url = f"{base_url}/orgs/{org}/actions/variables/{name}"
        response = self._make_request(self.target_session, 'GET', url)

        if response.status_code == 200:
            self.logger.info(f"Organization variable '{name}' already exists in {org} - will skip")
            return True
        if response.status_code == 404:
            self.logger.info(f"Organization variable '{name}' does not exist in {org} - will create")
            return False

        self.logger.warning(
            f"Unexpected response when checking org variable {name}: {response.status_code}"
        )
        return False

    def create_organization_variable(
        self,
        org: str,
        name: str,
        value: str,
        visibility: str,
        selected_repo_names: List[str],
        session,
    ) -> Optional[bool]:
        """Create an organization-level variable and skip if it already exists."""
        if self.check_organization_variable_exists(org, name):
            return None

        base_url = self._get_base_url_for_session(session)
        url = f"{base_url}/orgs/{org}/actions/variables"

        data = {
            'name': name,
            'value': value,
            'visibility': visibility,
        }

        if visibility == 'selected' and selected_repo_names:
            target_repo_ids = self.get_target_repository_ids(selected_repo_names)
            if target_repo_ids:
                data['selected_repository_ids'] = target_repo_ids
            else:
                self.logger.warning(
                    f"No valid repositories found for variable {name}, setting visibility to 'private'"
                )
                data['visibility'] = 'private'

        response = self._make_request(session, 'POST', url, json=data)

        if response.status_code == 201:
            visibility_info = f" (visibility: {data['visibility']}"
            if data['visibility'] == 'selected':
                visibility_info += f", repositories: {len(selected_repo_names)})"
            else:
                visibility_info += ")"
            self.logger.info(f"Created organization variable: {name}{visibility_info}")
            return True

        if response.status_code == 409:
            # Race condition-safe skip when variable appears between check and create.
            self.logger.info(f"Organization variable '{name}' already exists (409) - skipping")
            return None

        try:
            error_detail = response.json().get('message', 'Unknown error')
        except Exception:
            error_detail = response.text
        self.logger.error(
            f"Failed to create organization variable {name}: {response.status_code} - {error_detail}"
        )
        return False

    def fetch_organization_variables_for_migration(self) -> List[Dict]:
        """Fetch organization-level variables and shape them for migration/export."""
        all_variables: List[Dict] = []

        # Reuse repos.csv to limit selected-visibility org variables.
        allowed_repositories = set(self.read_repositories_from_csv())

        self.logger.info("Fetching organization-level variables only")
        org_variables = self.get_organization_variables(self.SOURCE_ORGANIZATION, self.source_session)

        for var in org_variables:
            if not isinstance(var, dict):
                self.logger.error(f"Org variable is not a dict: {type(var)} - {var}")
                continue

            visibility = var.get('visibility', 'all')
            selected_repositories = []

            if visibility == 'selected':
                source_selected = var.get('selected_repository_names', [])
                if not isinstance(source_selected, list):
                    source_selected = []

                selected_repositories = [
                    repo_name for repo_name in source_selected if repo_name in allowed_repositories
                ]

                if source_selected and not selected_repositories:
                    self.logger.warning(
                        "Variable '%s' has selected visibility but none of its source repositories are present in repos.csv",
                        var.get('name', 'UNKNOWN'),
                    )

            all_variables.append(
                {
                    'scope': 'organization',
                    'repository': '',
                    'name': var.get('name', ''),
                    'value': var.get('value', ''),
                    'visibility': visibility,
                    'selected_repositories': ','.join(selected_repositories),
                    'created_at': var.get('created_at', ''),
                    'updated_at': var.get('updated_at', ''),
                }
            )

        self.logger.info(f"Prepared {len(all_variables)} organization variables for migration")
        return all_variables

    def run_complete_org_migration(self) -> None:
        """Export and migrate organization-level variables, skipping existing ones."""
        self.logger.info(
            "Starting GitHub organization variables migration (Export + Migrate, Skip Existing)"
        )

        variables_data = self.fetch_organization_variables_for_migration()
        if not variables_data:
            self.logger.warning("No organization variables found to migrate")
            return

        csv_filename = 'github_org_variables_export.csv'
        self.export_variables_to_csv(variables_data, csv_filename)

        success_count, error_count, skipped_count = self.migrate_variables(variables_data)

        self.logger.info("Organization variables migration completed")
        self.logger.info(f"Total org variables processed: {len(variables_data)}")
        self.logger.info(f"Successfully migrated: {success_count}")
        self.logger.info(f"Errors: {error_count}")
        self.logger.info(f"Skipped: {skipped_count}")
        self.logger.info(f"Variables exported to: {csv_filename}")


def main() -> int:
    """Main entry point."""
    try:
        migrator = GitHubOrgVariablesMigrator()
        migrator.run_complete_org_migration()
    except Exception as e:
        print(f"Error: {e}")
        return 1
    return 0


if __name__ == '__main__':
    exit(main())
