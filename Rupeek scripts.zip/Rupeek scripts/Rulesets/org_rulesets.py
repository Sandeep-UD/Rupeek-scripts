import os
import json
import csv
import sys
import requests
import logging
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# --- Logging Configuration ---
def setup_logging(log_level=logging.INFO):
    """Sets up logging configuration."""
    log_format = '%(asctime)s - %(levelname)s - %(message)s'
    logging.basicConfig(
        level=log_level,
        format=log_format,
        handlers=[
            logging.FileHandler('github_org_rulesets.log'),
            logging.StreamHandler()
        ]
    )
    return logging.getLogger(__name__)

logger = setup_logging()

# --- Console Output Functions ---
def print_error(message):
    print(f"\033[91m❌ ERROR: {message}\033[0m")

def print_warning(message):
    print(f"\033[93m⚠️ WARNING: {message}\033[0m")

def print_info(message):
    print(f"\033[94mℹ️ INFO: {message}\033[0m")

def print_success(message):
    print(f"\033[92m✅ SUCCESS: {message}\033[0m")

# --- GitHub API Configuration ---
SOURCE_GITHUB_TOKEN = os.getenv("GH_PAT")
TARGET_GITHUB_TOKEN = os.getenv("TARGET_GH_PAT")
GITHUB_TOKEN = SOURCE_GITHUB_TOKEN or TARGET_GITHUB_TOKEN or os.getenv("GITHUB_TOKEN")

SOURCE_API_URL = os.getenv("SOURCE_API_URL", "https://api.github.com").strip() or "https://api.github.com"
TARGET_API_URL = os.getenv("TARGET_API_URL", "https://api.github.com").strip() or "https://api.github.com"

SOURCE_ORG = os.getenv("GH_ORG", "")
TARGET_ORG = os.getenv("TARGET_GH_ORG", "")
OUTPUT_DIR = os.getenv("OUTPUT_DIR", "exported_org_rulesets")
REPORT_FILE = os.getenv("REPORT_FILE", "org_migration_report.csv")

# Bypass actors handling configuration
ENRICH_BYPASS_ACTORS = os.getenv("ENRICH_BYPASS_ACTORS", "true").lower() == "true"
SANITIZE_BYPASS_ACTORS = os.getenv("SANITIZE_BYPASS_ACTORS", "true").lower() == "true"
REMOVE_ALL_BYPASS_ACTORS = os.getenv("REMOVE_ALL_BYPASS_ACTORS", "false").lower() == "true"

def get_headers(token):
    return {
        "Accept": "application/vnd.github.v3+json",
        "Authorization": f"token {token}",
        "X-GitHub-Api-Version": "2022-11-28"
    }

def make_api_request(method, url, token=None, **kwargs):
    headers = get_headers(token or GITHUB_TOKEN)
    try:
        logger.debug(f"Making {method} request to {url}")
        response = requests.request(method, url, headers=headers, **kwargs)
        response.raise_for_status()
        logger.debug(f"Request successful: {response.status_code}")
        return response
    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 404:
            logger.info(f"Resource not found for URL {url} (404). This may be expected.")
        else:
            logger.error(f"HTTP Error for URL {url}: {e.response.status_code} {e.response.reason}")
            logger.error(f"Response Body: {e.response.text}")
    except requests.exceptions.RequestException as e:
        logger.error(f"Request failed: {e}")
    return None

# --- Bypass Actors Management ---

def get_bypass_actor_details(actor_id: int, actor_type: str, org: str, token: str, api_url: str) -> dict:
    """Fetches detailed information about a bypass actor."""
    try:
        if actor_type == "Team":
            url = f"{api_url}/teams/{actor_id}"
            response = make_api_request("GET", url, token=token)
            if response:
                team_data = response.json()
                return {
                    "id": team_data.get("id"),
                    "slug": team_data.get("slug"),
                    "name": team_data.get("name"),
                    "description": team_data.get("description"),
                    "privacy": team_data.get("privacy", "closed"),
                    "permission": team_data.get("permission", "pull"),
                    "organization": team_data.get("organization", {}).get("login")
                }
        elif actor_type == "User":
            return {
                "id": actor_id,
                "type": "user_by_id",
                "note": "User ID stored for later resolution during import"
            }
        elif actor_type == "RepositoryRole":
            role_map = {1: "read", 2: "triage", 3: "write", 4: "maintain", 5: "admin"}
            return {
                "id": actor_id,
                "name": role_map.get(actor_id, f"role_{actor_id}"),
                "type": "repository_role"
            }
        elif actor_type == "OrganizationAdmin":
            return {"id": actor_id, "type": "organization_admin"}
    except Exception as e:
        logger.error(f"Failed to fetch {actor_type} details for ID {actor_id}: {e}")
    return None

def find_existing_team_in_target(team_details: dict, target_org: str, token: str, api_url: str) -> int:
    """Finds an existing team by slug in the target organization. Will NOT create teams."""
    team_slug = team_details.get("slug")
    if not team_slug:
        logger.error("Team slug not found in team details")
        return None

    url = f"{api_url}/orgs/{target_org}/teams/{team_slug}"
    response = make_api_request("GET", url, token=token)
    if response:
        existing_team = response.json()
        logger.info(f"Found existing team '{team_slug}' in {target_org} with ID {existing_team['id']}")
        return existing_team["id"]
    else:
        logger.warning(f"Team '{team_slug}' not found in {target_org} - will be skipped")
        return None

def enrich_bypass_actors_with_details(bypass_actors: list, org: str, token: str, api_url: str) -> list:
    """Enriches bypass actors with detailed information for later migration."""
    if not bypass_actors:
        return []

    enriched_actors = []
    for actor in bypass_actors:
        actor_id = actor.get("actor_id")
        actor_type = actor.get("actor_type")
        bypass_mode = actor.get("bypass_mode")

        actor_details = get_bypass_actor_details(actor_id, actor_type, org, token, api_url)
        enriched_actor = {
            "original_actor_id": actor_id,
            "actor_type": actor_type,
            "bypass_mode": bypass_mode,
            "details": actor_details
        }
        enriched_actors.append(enriched_actor)

        if actor_details:
            logger.info(f"Enriched {actor_type} bypass actor: {actor_details.get('name') or actor_details.get('login') or actor_id}")
        else:
            logger.warning(f"Could not enrich {actor_type} bypass actor ID {actor_id}")

    return enriched_actors

def resolve_bypass_actors_for_target(enriched_bypass_actors: list, target_org: str, token: str, api_url: str) -> list:
    """Resolves enriched bypass actors to actual actor IDs in the target organization."""
    if not enriched_bypass_actors:
        return []

    resolved_actors = []
    for enriched_actor in enriched_bypass_actors:
        actor_type = enriched_actor.get("actor_type")
        bypass_mode = enriched_actor.get("bypass_mode")
        details = enriched_actor.get("details")
        original_id = enriched_actor.get("original_actor_id")

        if not details:
            logger.warning(f"Skipping {actor_type} actor {original_id} - no details available")
            continue

        target_actor_id = None

        if actor_type == "Team":
            target_actor_id = find_existing_team_in_target(details, target_org, token, api_url)
        elif actor_type in ("User", "RepositoryRole", "OrganizationAdmin"):
            # RepositoryRole and OrganizationAdmin IDs are standard across orgs
            # User IDs are validated during ruleset creation by GitHub
            target_actor_id = original_id

        if target_actor_id:
            resolved_actors.append({
                "actor_id": target_actor_id,
                "actor_type": actor_type,
                "bypass_mode": bypass_mode
            })
            actor_name = details.get("name") or details.get("login") or details.get("slug") or target_actor_id
            logger.info(f"Resolved {actor_type} '{actor_name}' to ID {target_actor_id} in {target_org}")
        else:
            actor_name = details.get("name") or details.get("login") or details.get("slug") or original_id
            logger.warning(f"Could not resolve {actor_type} '{actor_name}' in {target_org}")

    return resolved_actors

def sanitize_bypass_actors(bypass_actors: list) -> list:
    """
    Sanitizes bypass_actors to remove invalid references.
    Behaviour is controlled by SANITIZE_BYPASS_ACTORS / REMOVE_ALL_BYPASS_ACTORS env vars.
    """
    if not bypass_actors:
        return []

    if REMOVE_ALL_BYPASS_ACTORS:
        logger.info("Removing all bypass_actors as per REMOVE_ALL_BYPASS_ACTORS configuration")
        return []

    if not SANITIZE_BYPASS_ACTORS:
        logger.info("Keeping original bypass_actors as per SANITIZE_BYPASS_ACTORS configuration")
        return bypass_actors

    sanitized = []
    for actor in bypass_actors:
        actor_type = actor.get("actor_type", "")
        actor_id = actor.get("actor_id", "")

        if actor_type == "RepositoryRole":
            sanitized.append(actor)
        elif actor_type == "OrganizationAdmin":
            sanitized.append(actor)
        elif actor_type == "Team":
            logger.warning(f"Removing bypass_actor {actor_type}:{actor_id} - teams from source org may not exist in target org")
        else:
            sanitized.append(actor)
            logger.info(f"Keeping bypass_actor {actor_type}:{actor_id} - please verify this exists in target org")

    return sanitized

# --- Core Export Logic ---

def export_org_rulesets(org: str) -> list:
    """Exports all rulesets defined at the organization level."""
    logger.info(f"Exporting organization-level rulesets from '{org}'...")
    url = f"{SOURCE_API_URL}/orgs/{org}/rulesets"
    response = make_api_request("GET", url, token=SOURCE_GITHUB_TOKEN, params={"per_page": 100})

    if not response:
        logger.error(f"Could not fetch rulesets for org '{org}'.")
        return []

    rulesets = response.json()
    if not rulesets:
        logger.info(f"No rulesets found for org '{org}'.")
        return []

    logger.info(f"Found {len(rulesets)} ruleset(s) for org '{org}'. Fetching full details...")

    detailed_rulesets = []
    for ruleset_summary in rulesets:
        detail_url = f"{SOURCE_API_URL}/orgs/{org}/rulesets/{ruleset_summary['id']}"
        detail_response = make_api_request("GET", detail_url, token=SOURCE_GITHUB_TOKEN)
        if detail_response:
            ruleset = detail_response.json()

            if ENRICH_BYPASS_ACTORS and ruleset.get("bypass_actors"):
                logger.info(f"Enriching bypass actors for ruleset '{ruleset.get('name')}'...")
                enriched = enrich_bypass_actors_with_details(
                    ruleset["bypass_actors"], org, SOURCE_GITHUB_TOKEN, SOURCE_API_URL
                )
                ruleset["original_bypass_actors"] = ruleset["bypass_actors"]
                ruleset["enriched_bypass_actors"] = enriched
            elif ruleset.get("bypass_actors"):
                logger.info(f"Bypass actor enrichment disabled for ruleset '{ruleset.get('name')}'")

            detailed_rulesets.append(ruleset)

    logger.info(f"Successfully exported {len(detailed_rulesets)} detailed ruleset(s) from '{org}'.")
    return detailed_rulesets

# --- Core Import Logic ---

def check_existing_org_rulesets(org: str, api_url: str, token: str) -> dict:
    """Returns a dict mapping ruleset name -> ruleset ID for the target org."""
    url = f"{api_url}/orgs/{org}/rulesets"
    response = make_api_request("GET", url, token=token, params={"per_page": 100})
    if not response:
        return {}

    rulesets = response.json()
    existing = {r["name"]: r["id"] for r in rulesets}
    logger.info(f"Found {len(existing)} existing org-level ruleset(s) in '{org}'")
    return existing

def import_org_rulesets(org: str, rulesets_to_create: list, source_org: str = None) -> list:
    """Imports organization-level rulesets into the target org and returns a report."""
    logger.info(f"Starting org-level ruleset import into '{org}'...")
    report_entries = []
    url = f"{TARGET_API_URL}/orgs/{org}/rulesets"

    existing_rulesets = check_existing_org_rulesets(org, TARGET_API_URL, TARGET_GITHUB_TOKEN)

    for ruleset in rulesets_to_create:
        ruleset_name = ruleset.get("name", "Unknown")
        source_info = source_org or "Unknown"

        report_entry = {
            "source_org": source_info,
            "target_org": org,
            "ruleset_name": ruleset_name,
            "source_ruleset_id": ruleset.get("id", "Unknown"),
            "enforcement": ruleset.get("enforcement", "Unknown"),
            "target": ruleset.get("target", "Unknown"),
        }

        if ruleset_name in existing_rulesets:
            logger.warning(f"Ruleset '{ruleset_name}' already exists in org '{org}' with ID {existing_rulesets[ruleset_name]}. Skipping.")
            report_entry.update({
                "migration_status": "Skipped",
                "target_ruleset_id": existing_rulesets[ruleset_name],
                "details": "Ruleset already exists in target organization",
                "bypass_actors_info": ""
            })
            report_entries.append(report_entry)
            continue

        # Resolve bypass actors
        resolved_bypass_actors = []
        bypass_actor_details = []

        if ruleset.get("enriched_bypass_actors"):
            logger.info(f"Resolving enriched bypass actors for ruleset '{ruleset_name}'...")
            resolved_bypass_actors = resolve_bypass_actors_for_target(
                ruleset["enriched_bypass_actors"], org, TARGET_GITHUB_TOKEN, TARGET_API_URL
            )
            bypass_actor_details.append(
                f"Resolved {len(resolved_bypass_actors)} from {len(ruleset['enriched_bypass_actors'])} enriched actors"
            )
        elif ruleset.get("bypass_actors"):
            logger.warning(f"No enriched bypass actors for '{ruleset_name}', falling back to sanitization")
            resolved_bypass_actors = sanitize_bypass_actors(ruleset["bypass_actors"])
            bypass_actor_details.append("Used sanitization fallback (no enriched data)")

        # Build payload - include only fields accepted by the API
        payload = {
            k: ruleset.get(k)
            for k in ["name", "target", "enforcement", "conditions", "rules"]
            if ruleset.get(k) is not None
        }
        if resolved_bypass_actors:
            payload["bypass_actors"] = resolved_bypass_actors

        logger.info(f"Creating org ruleset '{ruleset_name}' in '{org}' with {len(resolved_bypass_actors)} bypass actor(s)...")
        response = make_api_request("POST", url, token=TARGET_GITHUB_TOKEN, json=payload)

        if response and response.status_code == 201:
            created = response.json()
            logger.info(f"Ruleset '{created['name']}' created in '{org}' with ID {created['id']}")
            report_entry.update({
                "migration_status": "Success",
                "target_ruleset_id": created["id"],
                "details": "Successfully migrated to target organization",
                "bypass_actors_info": "; ".join(bypass_actor_details)
            })
        else:
            error_details = response.text if response else "Request failed. Check console for API error."
            logger.error(f"Failed to create org ruleset '{ruleset_name}' in '{org}': {error_details}")
            report_entry.update({
                "migration_status": "Failed",
                "target_ruleset_id": "N/A",
                "details": error_details,
                "bypass_actors_info": "; ".join(bypass_actor_details)
            })

        report_entries.append(report_entry)

    return report_entries

# --- File I/O ---

def save_rulesets_to_json(rulesets: list, filename: Path):
    """Saves rulesets to a JSON file."""
    logger.info(f"Saving rulesets to '{filename}'...")
    try:
        filename.parent.mkdir(parents=True, exist_ok=True)
        with open(filename, "w") as f:
            json.dump(rulesets, f, indent=4)
        logger.info(f"Successfully saved {len(rulesets)} ruleset(s) to '{filename}'.")
    except IOError as e:
        logger.error(f"Failed to write to file '{filename}': {e}")

def load_rulesets_from_json(filename: Path) -> list:
    """Loads rulesets from a JSON file."""
    logger.info(f"Loading rulesets from '{filename}'...")
    try:
        with open(filename, "r") as f:
            rulesets = json.load(f)
        logger.info(f"Successfully loaded {len(rulesets)} ruleset(s) from '{filename}'.")
        return rulesets
    except FileNotFoundError:
        logger.error(f"Input file '{filename}' not found.")
    except json.JSONDecodeError as e:
        logger.error(f"Could not decode JSON from '{filename}': {e}")
    except IOError as e:
        logger.error(f"Failed to read file '{filename}': {e}")
    return []

def save_migration_report(report: list, filename: str):
    """Saves the migration report to a CSV file."""
    if not report:
        logger.info("No data to write to migration report.")
        return

    logger.info(f"Saving migration report to '{filename}'...")
    fieldnames = [
        "source_org",
        "target_org",
        "ruleset_name",
        "source_ruleset_id",
        "target_ruleset_id",
        "enforcement",
        "target",
        "migration_status",
        "details",
        "bypass_actors_info",
    ]
    try:
        with open(filename, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(report)
        logger.info(f"Successfully saved migration report to '{filename}'.")
    except IOError as e:
        logger.error(f"Failed to write to report file '{filename}': {e}")
        print_error(f"Failed to write to report file '{filename}': {e}")

# --- Main ---

def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ("export", "import"):
        print_error("Usage: python org_rulesets.py [export|import]")
        print_info("  export - Export org-level rulesets from the source organization")
        print_info("  import - Import org-level rulesets into the target organization")
        return

    operation_mode = sys.argv[1]

    if not SOURCE_ORG:
        print_error("GH_ORG (source org) must be set in environment variables or .env file")
        return

    if operation_mode == "import" and not TARGET_ORG:
        print_error("TARGET_GH_ORG must be set in environment variables or .env file for import operations")
        return

    if not GITHUB_TOKEN:
        print_error("GitHub token not found. Set GH_PAT / TARGET_GH_PAT / GITHUB_TOKEN environment variable.")
        return

    if operation_mode == "export":
        print_info(f"Export configuration:")
        print_info(f"  Source org : {SOURCE_ORG}")
        print_info(f"  Output dir : {OUTPUT_DIR}")
        print_info(f"  ENRICH_BYPASS_ACTORS: {ENRICH_BYPASS_ACTORS}")

        rulesets = export_org_rulesets(SOURCE_ORG)
        if rulesets:
            output_path = Path(OUTPUT_DIR) / f"{SOURCE_ORG}-org-rulesets.json"
            save_rulesets_to_json(rulesets, output_path)
            print_success(f"Export completed! Saved {len(rulesets)} ruleset(s) to '{output_path}'.")
        else:
            print_warning(f"No org-level rulesets found for '{SOURCE_ORG}'.")

    elif operation_mode == "import":
        print_info(f"Import configuration:")
        print_info(f"  Source org : {SOURCE_ORG}")
        print_info(f"  Target org : {TARGET_ORG}")
        print_info(f"  ENRICH_BYPASS_ACTORS   : {ENRICH_BYPASS_ACTORS}")
        print_info(f"  SANITIZE_BYPASS_ACTORS : {SANITIZE_BYPASS_ACTORS}")
        print_info(f"  REMOVE_ALL_BYPASS_ACTORS: {REMOVE_ALL_BYPASS_ACTORS}")

        if REMOVE_ALL_BYPASS_ACTORS:
            print_warning("All bypass_actors will be removed from imported rulesets")
        elif ENRICH_BYPASS_ACTORS:
            print_info("Will use enriched bypass actor data from export")
        elif SANITIZE_BYPASS_ACTORS:
            print_info("Will fall back to sanitization (Team bypass_actors will be removed)")
        else:
            print_warning("All bypass_actors will be kept as-is (may cause import failures)")

        input_path = Path(OUTPUT_DIR) / f"{SOURCE_ORG}-org-rulesets.json"
        rulesets_to_create = load_rulesets_from_json(input_path)

        if not rulesets_to_create:
            print_error(f"No rulesets to import. Run export first or check '{input_path}'.")
            return

        report = import_org_rulesets(TARGET_ORG, rulesets_to_create, source_org=SOURCE_ORG)

        if report:
            save_migration_report(report, REPORT_FILE)
            print_success(f"Import completed! Check '{REPORT_FILE}' for detailed results.")
        else:
            print_warning("No rulesets were processed.")


if __name__ == "__main__":
    main()
