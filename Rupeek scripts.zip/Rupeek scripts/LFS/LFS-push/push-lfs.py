import csv
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import time


def load_env_variables():
    """Load environment variables from .env file."""
    env_file = Path('.env')
    if not env_file.exists():
        print("Error: .env file not found.", file=sys.stderr)
        sys.exit(1)

    with open(env_file, 'r', encoding='utf-8') as file:
        for line in file:
            line = line.strip()
            if '=' in line and not line.startswith('#'):
                key, value = line.split('=', 1)
                os.environ[key.strip()] = value.strip()


def mask_sensitive(text: str, tokens: list) -> str:
    """Mask sensitive tokens in logs and console output."""
    for token in tokens:
        if token and len(token) > 4:
            text = text.replace(token, "***TOKEN***")
    return text


def run_command(command, log_file, cwd=None, tokens=None):
    """Run a shell command and stream/log output safely."""
    tokens = tokens or []
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            cwd=cwd,
            encoding='utf-8',
            errors='replace'
        )
        raw_output = (result.stdout or "") + (result.stderr or "")
        safe_output = mask_sensitive(raw_output, tokens)

        if safe_output.strip():
            print(safe_output.strip())
            with open(log_file, 'a', encoding='utf-8') as f:
                f.write(safe_output + '\n')
        return result.returncode
    except Exception as e:
        error_msg = f"Exception running command: {str(e)}"
        print(error_msg, file=sys.stderr)
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(error_msg + '\n')
        return 1


def _remove_readonly(func, path, exc_info):
    """Windows helper to force-remove read-only files."""
    try:
        os.chmod(path, stat.S_IWRITE)
        func(path)
    except Exception:
        pass


def cleanup_directory(dir_path: Path, retries=5, delay=1):
    """Safely remove directory on Windows with retry logic."""
    if not dir_path.exists():
        return

    for attempt in range(retries):
        try:
            if os.name == 'nt':
                subprocess.run(f'attrib -R "{dir_path}\\*.*" /S /D', shell=True, capture_output=True)
            shutil.rmtree(dir_path, onerror=_remove_readonly)
            print(f"Cleaned up temporary directory: {dir_path}")
            return
        except Exception as e:
            if attempt < retries - 1:
                time.sleep(delay)
            else:
                print(f"Warning: Could not clean up {dir_path} ({e})")


def check_free_disk_space(path: Path, required_gb=120):
    """Warn if free disk space is lower than required."""
    total, used, free = shutil.disk_usage(path.anchor if path.anchor else ".")
    free_gb = free // (2**30)
    print(f"Available disk space on {path.anchor}: {free_gb} GB")
    if free_gb < required_gb:
        print(f"\033[93mWarning: Only {free_gb} GB free. Large LFS repositories may fail.\033[0m")


def main():
    load_env_variables()

    source_token = os.environ.get("Source-Access-Token") or os.environ.get("Soucre-Access-Token")
    target_token = os.environ.get("Target-Access-Token")

    if not source_token or not target_token:
        print("Error: Missing Source-Access-Token or Target-Access-Token in .env", file=sys.stderr)
        sys.exit(1)

    tokens = [source_token, target_token]
    csv_file = "repos.csv"
    if not Path(csv_file).exists():
        print(f"Error: CSV file '{csv_file}' not found.", file=sys.stderr)
        sys.exit(1)

    log_file = "lfs_migration_log.txt"
    if Path(log_file).exists():
        Path(log_file).unlink()

    check_free_disk_space(Path("."))

    with open(csv_file, 'r', newline='', encoding='utf-8') as file:
        repos = list(csv.DictReader(file))

    for repo in repos:
        source_org = repo["Source-Org"].strip()
        target_org = repo["Target-Org"].strip()
        repo_name = repo["reponame"].strip()

        print(f"\n\033[96m=== Migrating LFS for: {source_org}/{repo_name} -> {target_org}/{repo_name} ===\033[0m")
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(f"\n=== Migrating LFS: {repo_name} ===\n")

        bare_repo_dir = Path(f"{repo_name}.git")
        source_url = f"https://{source_token}@github.com/{source_org}/{repo_name}.git"
        target_url = f"https://{target_token}@github.com/{target_org}/{repo_name}.git"

        # 1. Bare Mirror Clone (Resume if already present from a previous run)
        if not bare_repo_dir.exists():
            print("1. Cloning bare mirror metadata...")
            clone_cmd = f'git clone --mirror "{source_url}" "{bare_repo_dir}"'
            if run_command(clone_cmd, log_file, tokens=tokens) != 0:
                print(f"\033[91mFailed to clone metadata for {repo_name}\033[0m", file=sys.stderr)
                cleanup_directory(bare_repo_dir)
                continue
        else:
            print("Existing bare repository directory detected. Resuming without re-cloning...")

        try:
            # 2. Configure Git LFS settings to prevent timeout on large uploads
            print("Configuring robust Git LFS transfer settings...")
            # 0 = disable activity timeout completely (avoids TCP read/write i/o timeouts)
            run_command("git config lfs.activitytimeout 0", log_file, cwd=bare_repo_dir, tokens=tokens)
            run_command("git config lfs.dialtimeout 300", log_file, cwd=bare_repo_dir, tokens=tokens)
            run_command("git config lfs.tlstimeout 300", log_file, cwd=bare_repo_dir, tokens=tokens)
            run_command("git config lfs.transfer.maxretries 10", log_file, cwd=bare_repo_dir, tokens=tokens)
            # Lower concurrency to avoid saturating network and dropping sockets
            run_command("git config lfs.concurrenttransfers 2", log_file, cwd=bare_repo_dir, tokens=tokens)
            run_command("git config http.postBuffer 1048576000", log_file, cwd=bare_repo_dir, tokens=tokens)

            # 3. Fetch all LFS objects from source
            print("2. Fetching all LFS objects from source...")
            fetch_cmd = "git lfs fetch --all origin"
            if run_command(fetch_cmd, log_file, cwd=bare_repo_dir, tokens=tokens) != 0:
                print(f"\033[91mError: Git LFS fetch failed for {repo_name}. Keeping directory to resume later.\033[0m", file=sys.stderr)
                with open(log_file, 'a', encoding='utf-8') as f:
                    f.write(f"FAILED: LFS fetch failed for {repo_name}\n")
                continue

            # 4. Add Target Remote (ignore error if already exists from resume)
            print("3. Adding target remote...")
            run_command(f'git remote add target "{target_url}"', log_file, cwd=bare_repo_dir, tokens=tokens)

            # 5. Push all LFS objects to Target with Automatic Resuming / Retries
            max_push_retries = 5
            push_success = False

            for attempt in range(1, max_push_retries + 1):
                print(f"4. Pushing LFS objects to target (Attempt {attempt}/{max_push_retries})...")
                lfs_push_cmd = "git lfs push --all target"
                exit_code = run_command(lfs_push_cmd, log_file, cwd=bare_repo_dir, tokens=tokens)

                if exit_code == 0:
                    push_success = True
                    break
                else:
                    if attempt < max_push_retries:
                        wait_seconds = 15
                        print(f"\033[93mPush attempt {attempt} encountered a network timeout. Waiting {wait_seconds}s before resuming... (Git LFS will skip already uploaded files)\033[0m")
                        time.sleep(wait_seconds)

            if push_success:
                print(f"\033[92mSuccessfully migrated all LFS objects for: {repo_name}\033[0m")
                with open(log_file, 'a', encoding='utf-8') as f:
                    f.write(f"SUCCESS: LFS migrated for {repo_name}\n")
                # ONLY delete directory when push is 100% complete
                cleanup_directory(bare_repo_dir)
            else:
                print(f"\033[91mError: LFS push failed after {max_push_retries} attempts for {repo_name}.\033[0m", file=sys.stderr)
                print(f"\033[93mNotice: Preserving {bare_repo_dir} so you can run the script again and resume without re-downloading 6+ GB!\033[0m")
                with open(log_file, 'a', encoding='utf-8') as f:
                    f.write(f"FAILED: LFS push failed after retries for {repo_name}\n")

        except Exception as e:
            print(f"\033[91mError processing {repo_name}: {e}\033[0m", file=sys.stderr)

    print(f"\n\033[93mLFS migration process finished. See {log_file} for details.\033[0m")


if __name__ == "__main__":
    main()