# Fetch GitHub LFS Usage

This script checks all repositories in an organization to identify which ones are using Git Large File Storage (LFS) and exports the results to CSV.

## Prerequisites

- Python 3.x
- Required packages: `requests`, `python-dotenv`, `pandas`

Install dependencies:
```bash
pip install requests python-dotenv pandas
```

## Setup

Create a `.env` file with the following variables:
```
# Single token (fallback)
GH_PAT=your_github_personal_access_token

# Multiple tokens (comma-separated). If set, this takes precedence over GH_PAT.
GH_PATS=token1,token2,token3

GH_ORG=your_organization_name
TARGET_API_URL=https://api.github.com
```

Token precedence:
- If `GH_PATS` is set and contains one or more tokens, the script uses that token pool.
- If `GH_PATS` is empty, the script falls back to `GH_PAT`.
- Tokens in `GH_PATS` should be comma-separated on one line.

`TARGET_API_URL` is optional:
- For GitHub.com, use `https://api.github.com` (or leave it unset to use the default).
- For GHES/data residency, set it to your target API base URL (for example `https://api.<your-host>`).

## Usage

Run the script:
```bash
python lfs_usage.py
```

The script will:
1. Fetch all repositories in the organization
2. Check each branch in every repository for `.gitattributes` file
3. Detect if LFS is enabled (looks for `filter=lfs` in `.gitattributes`)
4. Display results in console and export to CSV

## Features

- ✅ Scans all repositories in the organization
- ✅ Checks all branches in each repository
- ✅ Detects LFS usage via `.gitattributes` file
- ✅ Handles pagination automatically
- ✅ Automatic rate limit handling
- ✅ Supports multiple tokens with automatic rotation on rate limit
- ✅ Progress reporting with periodic pauses
- ✅ Exports results to CSV with organization name

## CSV Input Format (Optional)

The script can optionally filter repositories using `repos.csv`:
```csv
reponame
repo-name-1
repo-name-2
```

If `repos.csv` exists and contains repository names, only those repositories will be scanned. If the file is empty or missing, all organization repositories are processed.

## Output

The script generates `{ORG_NAME}_lfs_usage.csv` with the following columns:

| Column | Description |
|--------|-------------|
| `Repository` | Repository name |
| `Sample_Branches` | Comma-separated list of sample branches (up to 5) |
| `Using_LFS` | "Yes" if LFS is detected, "No" otherwise |

## Token Permissions

The GitHub Personal Access Token must have:
- `repo` scope - Repository access to read contents

If using `GH_PATS`, each token in the list should have the same required scopes.

## How LFS Detection Works

The script checks for Git LFS by:
1. Looking for `.gitattributes` file in each branch
2. Checking if the file contains `filter=lfs` directive
3. Marking repository as "Using LFS" if found in any branch

### Example `.gitattributes` with LFS:
```
*.psd filter=lfs diff=lfs merge=lfs -text
*.zip filter=lfs diff=lfs merge=lfs -text
*.mp4 filter=lfs diff=lfs merge=lfs -text
```

## Example Output

Console output:
```
Checking LFS usage for repositories in the organization: my-org
==========================================================================================
Repository                     | Branches                                 | Using LFS
------------------------------------------------------------------------------------------
frontend-app                   | main, develop, feature/ui                | No
design-assets                  | main                                     | Yes
video-library                  | main, production                         | Yes
backend-api                    | main, staging, development               | No
mobile-app                     | main, ios-release, android-release       | No
Processed 100 repositories, waiting for 10 seconds...
==========================================================================================
LFS check completed.
Results saved to my-org_lfs_usage.csv
```

## Sample CSV Output

```csv
Repository,Sample_Branches,Using_LFS
frontend-app,"main, develop, feature/ui",No
design-assets,main,Yes
video-library,"main, production",Yes
backend-api,"main, staging, development",No
mobile-app,"main, ios-release, android-release",No
```

## Use Cases

- **LFS audit**: Identify which repositories use LFS
- **Storage planning**: Estimate LFS storage requirements
- **Migration planning**: Plan LFS configuration for new repositories
- **Cost analysis**: Track LFS usage for billing purposes
- **Compliance**: Document large file storage usage
- **Cleanup**: Identify repositories that should (or shouldn't) use LFS

## Important Notes

### Data Residency / API Endpoint
- The script supports `TARGET_API_URL` from `.env`.
- This allows running against GitHub.com or a custom GHES/data residency API endpoint.

### LFS Detection Method
- Only detects LFS if `.gitattributes` file exists
- Checks all branches to ensure comprehensive coverage
- Repositories using LFS without `.gitattributes` won't be detected

### Rate Limiting
- Script includes automatic rate limit handling
- If `GH_PATS` is configured, script rotates to the next token when one token is rate-limited
- If all tokens are rate-limited, script waits for reset and then retries
- Pauses every 100 repositories for 10 seconds
- Includes 1-second delay between API calls
- Will automatically wait when rate limits are reached

### Performance
- Large organizations may take considerable time
- Script processes all branches in all repositories
- Progress updates shown every 100 repositories

## Troubleshooting

### False Negatives
- Repository uses LFS but not detected
- Verify `.gitattributes` file exists in repository
- Check if LFS tracking was set up correctly
- File might be in subdirectory (script only checks root)

### Permission Errors
- Ensure token has `repo` scope
- Verify access to all organization repositories
- Check token hasn't expired

### Rate Limiting
- Script automatically handles rate limits
- May pause multiple times for large organizations
- Check console for "waiting" messages

### Slow Execution
- Normal for large organizations with many repos/branches
- Each branch requires a separate API call
- Consider running during off-peak hours

### Data Residency / API URL Issues
- Verify `TARGET_API_URL` is correct and reachable from your machine
- Ensure the URL includes `https://`
- For GitHub.com, use `https://api.github.com`

## Git LFS Overview

### What is Git LFS?
Git Large File Storage (LFS) replaces large files with text pointers inside Git, while storing the file contents on a remote server.

### Common LFS Use Cases:
- **Design files**: PSD, Sketch, Figma files
- **Media files**: Videos, audio files, high-res images
- **Binary assets**: Game assets, 3D models
- **Build artifacts**: Compiled binaries, archives
- **Data files**: Large datasets, database dumps

### LFS Benefits:
- Reduces repository clone size
- Improves Git performance
- Handles large binary files efficiently
- Version control for large assets

## Related Tools

This tool is part of a suite of LFS management utilities:
- **Fetch LFS** (this script): Audits which repositories use LFS
- **LFS-push**: Migrates LFS objects between source and target organizations

Both tools are typically used together: first identify LFS repositories with Fetch LFS, then migrate them with LFS-push.

## Related Information

- Git LFS: https://git-lfs.github.com/
- GitHub LFS: https://docs.github.com/en/repositories/working-with-files/managing-large-files
- LFS billing: https://docs.github.com/en/billing/managing-billing-for-git-large-file-storage

## Rate Limits

- GitHub API limit: 5,000 requests/hour for authenticated users
- Script includes built-in delays and rate limit handling
- Large organizations may require multiple hours to complete
- Each repository and branch requires separate API calls

## Storage Considerations

After identifying LFS repositories:
- Review LFS bandwidth and storage limits
- Plan for LFS costs if using paid storage
- Consider cleaning up unnecessary LFS files
- Optimize LFS tracking patterns in `.gitattributes`
