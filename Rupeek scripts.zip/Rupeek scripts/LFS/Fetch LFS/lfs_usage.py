import base64
from datetime import datetime
import json
import logging
import os
import time
from dotenv import load_dotenv
import pandas as pd
import requests

# Setup logging
log_dir = "logs"
os.makedirs(log_dir, exist_ok=True)

log_file = os.path.join(log_dir, f"lfs_usage_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler(log_file),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Load config
load_dotenv()
ORG_NAME = os.getenv("GH_ORG", "").strip()
TARGET_API_URL = os.getenv("TARGET_API_URL", "https://api.github.com").strip().rstrip("/")
STATE_FILE = f"{ORG_NAME}_progress.json"

raw_tokens = os.getenv("GH_PATS", "").strip()
if raw_tokens:
    TOKENS = [t.strip() for t in raw_tokens.split(",") if t.strip()]
else:
    single = os.getenv("GH_PAT", "").strip()
    TOKENS = [single] if single else []


class TokenManager:
    """Manages token rotation and rate-limit backoff across multiple tokens."""
    def __init__(self, tokens):
        self.tokens = tokens
        self.idx = 0
        self.reset_times = {t: 0 for t in tokens}

    def current_token(self):
        if not self.tokens:
            raise ValueError("No GitHub token available. Set GH_PAT or GH_PATS.")
        return self.tokens[self.idx]

    def mark_exhausted(self, reset_time):
        self.reset_times[self.current_token()] = reset_time

    def rotate_or_wait(self):
        """Rotate to an available token or sleep until the earliest reset time."""
        now = time.time()
        # Check if another token has remaining quota
        for _ in range(len(self.tokens)):
            self.idx = (self.idx + 1) % len(self.tokens)
            if now >= self.reset_times[self.current_token()]:
                logger.info(f"Switched to token {self.idx + 1}/{len(self.tokens)}")
                return

        # If all tokens are exhausted, wait for the earliest reset
        earliest_reset = min(self.reset_times.values())
        wait_seconds = max(1, int(earliest_reset - now) + 2)
        logger.warning(f"All tokens rate-limited. Waiting {wait_seconds} seconds...")
        time.sleep(wait_seconds)


token_mgr = TokenManager(TOKENS)


def github_get(url):
    """GET wrapper with timeout, token rotation, and secondary rate-limit handling."""
    while True:
        token = token_mgr.current_token()
        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github.v3+json"
        }

        try:
            response = requests.get(url, headers=headers, timeout=(5, 20))
        except requests.exceptions.RequestException as e:
            logger.warning(f"Network error requesting {url}: {e}. Retrying in 5 seconds...")
            time.sleep(5)
            continue

        # Secondary / Abuse rate limit
        if response.status_code == 429 or (
            response.status_code == 403 and "secondary rate limit" in response.text.lower()
        ):
            retry_after = int(response.headers.get("Retry-After", 60))
            logger.warning(f"Secondary rate limit hit. Waiting {retry_after}s...")
            time.sleep(retry_after)
            continue

        # Primary rate limit (quota exhausted)
        if response.status_code == 403 and response.headers.get("X-RateLimit-Remaining") == "0":
            reset_time = int(response.headers.get("X-RateLimit-Reset", time.time() + 60))
            token_mgr.mark_exhausted(reset_time)
            token_mgr.rotate_or_wait()
            continue

        return response


def load_repos_from_csv(csv_file="repos.csv"):
    """Load repository names from repos.csv file.
    
    If file doesn't exist or is empty, returns an empty list (meaning process all repos).
    Expects CSV with 'reponame' or 'reponames' column.
    """
    if not os.path.exists(csv_file):
        logger.info(f"CSV file '{csv_file}' not found. Will process all repositories.")
        return []
    
    try:
        df = pd.read_csv(csv_file)
        if df.empty:
            logger.info(f"CSV file '{csv_file}' is empty. Will process all repositories.")
            return []
        
        # Try both 'reponame' and 'reponames' column names
        repo_col = None
        if "reponame" in df.columns:
            repo_col = "reponame"
        elif "reponames" in df.columns:
            repo_col = "reponames"
        else:
            logger.warning(f"CSV file '{csv_file}' does not have 'reponame' or 'reponames' column. Will process all repositories.")
            return []
        
        repo_names = df[repo_col].dropna().astype(str).str.strip().tolist()
        logger.info(f"Loaded {len(repo_names)} repository names from '{csv_file}'")
        return repo_names
    except Exception as e:
        logger.warning(f"Error reading CSV file '{csv_file}': {e}. Will process all repositories.")
        return []


def load_progress():
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, "r") as f:
                return json.load(f)
        except Exception as e:
            logger.warning(f"Could not load state file: {e}. Starting fresh.")
    return {"completed": [], "failed": [], "results": []}


def save_progress(state):
    try:
        with open(STATE_FILE, "w") as f:
            json.dump(state, f, indent=2)
    except Exception as e:
        logger.error(f"Failed to save state file: {e}")


def get_repositories(org):
    repos = []
    page = 1
    while True:
        url = f"{TARGET_API_URL}/orgs/{org}/repos?per_page=100&page={page}&type=all"
        res = github_get(url)
        if res.status_code != 200:
            logger.error(f"Failed fetching repos page {page}: {res.status_code} - {res.text}")
            break
        data = res.json()
        if not data:
            break
        repos.extend(data)
        page += 1
    return repos


def get_branches(repo_name):
    branches = []
    page = 1
    while True:
        url = f"{TARGET_API_URL}/repos/{ORG_NAME}/{repo_name}/branches?per_page=100&page={page}"
        res = github_get(url)
        if res.status_code != 200:
            break
        data = res.json()
        if not data:
            break
        branches.extend([b["name"] for b in data])
        page += 1
    return branches


def has_lfs_in_gitattributes(repo_name, ref):
    """Check if .gitattributes on the given ref contains 'filter=lfs'."""
    url = f"{TARGET_API_URL}/repos/{ORG_NAME}/{repo_name}/contents/.gitattributes?ref={ref}"
    res = github_get(url)

    if res.status_code == 200:
        try:
            content_encoded = res.json().get("content", "")
            decoded = base64.b64decode(content_encoded).decode("utf-8", errors="ignore")
            return "filter=lfs" in decoded
        except Exception as e:
            logger.warning(f"Error decoding .gitattributes for {repo_name}@{ref}: {e}")
    return False


def main():
    if not TOKENS or not ORG_NAME:
        logger.error("Please ensure GH_ORG and GH_PAT / GH_PATS are defined in your .env file.")
        return

    state = load_progress()
    completed_repos = set(state.get("completed", []))
    all_results = state.get("results", [])
    failed_repos = state.get("failed", [])

    # Load repos from CSV if available
    csv_repo_names = load_repos_from_csv("repos.csv")
    
    # Fetch all repos from GitHub
    all_repos = get_repositories(ORG_NAME)
    logger.info(f"Total repositories found in {ORG_NAME}: {len(all_repos)}")
    
    # Filter repos based on CSV if CSV had data
    if csv_repo_names:
        csv_set = set(csv_repo_names)
        repos = [repo for repo in all_repos if repo["name"] in csv_set]
        logger.info(f"Filtered to {len(repos)} repositories from repos.csv")
    else:
        repos = all_repos
        logger.info("Processing all repositories from organization")

    for idx, repo in enumerate(repos, 1):
        repo_name = repo["name"]
        if repo_name in completed_repos:
            continue

        default_branch = repo.get("default_branch", "main")
        lfs_found = False

        try:
            # 1. Quick check: check default branch first
            if has_lfs_in_gitattributes(repo_name, default_branch):
                lfs_found = True
                branches = [default_branch]
            else:
                # 2. Fallback: check remaining branches if not found on default
                branches = get_branches(repo_name)
                for b in branches:
                    if b == default_branch:
                        continue
                    if has_lfs_in_gitattributes(repo_name, b):
                        lfs_found = True
                        break

            lfs_status = "Yes" if lfs_found else "No"
            branch_str = ", ".join(branches[:5]) + ("..." if len(branches) > 5 else "")
            all_results.append([repo_name, branch_str, lfs_status])
            completed_repos.add(repo_name)

            logger.info(f"[{idx}/{len(repos)}] {repo_name}: LFS={lfs_status}")

        except Exception as e:
            logger.error(f"Error processing {repo_name}: {e}")
            failed_repos.append({"repo": repo_name, "error": str(e)})

        # Periodic state save
        save_progress({
            "completed": list(completed_repos),
            "failed": failed_repos,
            "results": all_results,
            "timestamp": datetime.now().isoformat()
        })

    # Save final CSV
    csv_file = f"{ORG_NAME}_lfs_usage.csv"
    df = pd.DataFrame(all_results, columns=["Repository", "Sample_Branches", "Using_LFS"])
    df.to_csv(csv_file, index=False)
    logger.info(f"Done! Saved results to {csv_file}")


if __name__ == "__main__":
    main()